import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
MOTOR_P = 19
MOTOR_M = 13
SW_PIN = 4

# 버튼 상태를 읽는 함수
def read_button_state(pin):
    return GPIO.input(pin)

if __name__ == "__main__":
    GPIO.setup(MOTOR_P, GPIO.OUT)
    GPIO.setup(MOTOR_M, GPIO.OUT)
    GPIO.setup(SW_PIN, GPIO.IN)

    try:
        while True:
            # 버튼 상태를 읽음
            button_state = read_button_state(SW_PIN)

            # 버튼이 눌려있는 동안
            while button_state:
                # 모터를 정지
                GPIO.output(MOTOR_P, GPIO.LOW)
                GPIO.output(MOTOR_M, GPIO.LOW)
                time.sleep(0.1)  # 버튼 상태를 주기적으로 확인하기 위해 잠시 대기
                button_state = read_button_state(SW_PIN)  # 버튼 상태 업데이트

            # 버튼이 떼어지면 모터를 구동
            GPIO.output(MOTOR_P, GPIO.HIGH)
            GPIO.output(MOTOR_M, GPIO.LOW)
            print("Motor starts rotating clockwise")
            time.sleep(1)

            # 모터를 정지
            GPIO.output(MOTOR_P, GPIO.LOW)
            GPIO.output(MOTOR_M, GPIO.LOW)
            print("Motor stops")
            time.sleep(1)

            # 버튼 상태를 다시 확인하여 역회전을 시작할지 결정
            button_state = read_button_state(SW_PIN)
            if button_state:
                # 역회전 시작
                GPIO.output(MOTOR_P, GPIO.LOW)
                GPIO.output(MOTOR_M, GPIO.HIGH)
                print("Motor starts rotating counterclockwise")
                time.sleep(1)

                # 모터를 정지
                GPIO.output(MOTOR_P, GPIO.LOW)
                GPIO.output(MOTOR_M, GPIO.LOW)
                print("Motor stops")
                time.sleep(1)

    except KeyboardInterrupt:
        GPIO.cleanup()
