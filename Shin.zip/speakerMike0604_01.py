from tkinter import *
import sounddevice as sd
import numpy as np
import scipy.io as sio
import scipy.io.wavfile
import pygame
import time
import datetime

fileNamePath = 'output.wav'
sample_rate = 44100  # 샘플레이트
seconds = 3  # 녹음시간


# 프로그램의 창을 생성하는 MainFrame 클래스
class MainFrame(Frame):
    def __init__(self, master):
        master.title('Rec Example')
        master.geometry("400x240+10+10")

        # 텍스트 출력하기
        self.label = Label(master, background="yellow",
                          text="{}초 동안 녹음을 시작합니다.\n 아래 REC 버튼을 눌러주세요.".format(seconds))
        self.label.pack(expand=1)

        self.labelResult = Label(master, background="yellow", text="-".format(seconds))
        self.labelResult.pack(expand=1)

        # 녹음 및 재생 버튼
        self.recButton = Button(master, background="RED", text="REC", command=lambda: self.onButtonClickEvent())
        self.recButton.pack(expand=1)

    # 버튼의 이벤트를 처리하는 함수
    def onButtonClickEvent(self):
        myrecording = sd.rec(int(seconds * sample_rate), samplerate=sample_rate, channels=2)
        sd.wait()  # 녹음이 끝날때까지 대기

        sio.wavfile.write(fileNamePath, sample_rate, myrecording)  # wav파일로 저장

        currentTime = datetime.datetime.now()
        self.labelResult.configure(
            text='{}\n녹음 완료!...{}'.format(currentTime, fileNamePath))


# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    root = Tk()  # 창을 띄우기 위한 객체를 선언
    mainFrame = MainFrame(root)  # 창 객체를 인자로 클래스를 생성한다
    root.mainloop()  # python의 창을 띄우고 이벤트 처리 수행 함수
    sys.exit()  # 소프트웨어를 완전히 종료한다.
