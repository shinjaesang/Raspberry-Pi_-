from tkinter import *
import RPi.GPIO as GPIO
import smbus
import time
import threading
import sys
 
# I2C 설정
bus = smbus.SMBus(1)
i2c_address = 0x48
command = 0x44
 
# GPIO 설정
GPIO.setmode(GPIO.BCM)
SERVO_PIN = 25
GPIO.setup(SERVO_PIN, GPIO.OUT)
 
servo_pwm = GPIO.PWM(SERVO_PIN, 50)
servo_pwm.start(0)
 
class MainFrame(Frame):
    def __init__(self, master):
        super().__init__(master)
        master.title('Sensor Monitoring')
        master.geometry("400x240+10+10")
   
        self.value = StringVar()
        self.value.set("가변저항 : {}%".format(str(0)))
        self.VrLabel = Label(master, background="yellow", textvariable=self.value)
        self.VrLabel.pack(side=LEFT, expand=1)
   
        self.angle_value = StringVar()
        self.angle_value.set("서보모터 각도: {}도".format(str(0)))
        self.ServoLabel = Label(master, background="yellow", textvariable=self.angle_value)
        self.ServoLabel.pack(side=LEFT, expand=1)
   
        self.t = threading.Thread(target=self.analogReadThread)
        self.t.start()
   
    def analogReadThread(self):
        while True:
            # i2c의 주소와 명령어를 전송하여 5Byte의 데이터를 읽어온다.
            adc_data = bus.read_i2c_block_data(i2c_address, command, 5)
           
            # I2C로부터 센서 값을 읽어온다. 가변저항은 1번이다.
            vr_value = adc_data[1]
           
            # 가변저항 값을 백분율로 변환
            vr_percentage = vr_value * 100 / 255
            vr_percentage = round(vr_percentage)
           
            # 서보모터 각도를 10도에서 170도 사이로 변환
            servo_angle = vr_percentage * (170 - 10) / 100 + 10
            servo_angle = round(servo_angle)
           
            # Label의 저항 값을 변경 시킨다
            self.value.set("가변저항 : {}%".format(str(vr_percentage)))
 
            self.angle_value.set("서보모터 각도: {}도".format(str(round(servo_angle))))
           
            # 서보모터 각도를 설정한다
            self.set_servo_angle(servo_angle)
           
            time.sleep(0.1)
   
    def set_servo_angle(self, angle):
        # 서보모터 각도를 duty cycle로 변환하여 설정
        duty_cycle = angle * (12.5 - 2.5) / 180 + 2.5
        servo_pwm.ChangeDutyCycle(duty_cycle)
   
if __name__ == '__main__':
    root = Tk()
    mainFrame = MainFrame(root)
    root.mainloop()
    sys.exit()