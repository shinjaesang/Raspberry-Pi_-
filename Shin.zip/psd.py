# I2C 사용을 위한 모듈 smbus
import smbus
# 지연시간 제어를 위해 time 모듈을 사용한다.
import time
import math

bus = smbus.SMBus(1)
i2c_address = 0x48

# PCF8591 칩에서 데이터를 받기위한 명령어다.
command = 0x44

# try-except 는 파이썬의 예외처리 구문으로
# 키보드로 Ctrl + C를 누를시 프로그램이 종료 된다.
try:
    while(1) :
        # VrValue = adc_data[1]
        adc_data = bus.read_i2c_block_data(i2c_address, command, 5)
        psd_val = (adc_data[4]/255.0*3.3)*3/2
        psd_val = 29.988*math.pow(psd_val, -1.173)
        psd_val = round(psd_val, 2)
        # if psd_val <8:
        #     psd_val = 0
        print("PSD : " + str(psd_val) + "cm")
        time.sleep(0.1)

# 종료 등의 키보드 인터럽트 발생시 처리 동작
except KeyboardInterrupt:
    pass