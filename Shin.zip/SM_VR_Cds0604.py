from tkinter import *
import RPi.GPIO as GPIO
import smbus
import time
import threading
import math

bus = smbus.SMBus(1)
i2c_address = 0x48
command = 0x44

class MainFrame(Frame):
    def __init__(self, master):
        super().__init__(master)
        master.title('Sensor Monitoring')
        master.geometry("400x240+10+10")
        
        # 센서 데이터를 출력할 컨테이너 프레임 생성
        sensor_frame = Frame(master)
        sensor_frame.pack(expand=True, fill=BOTH)
        
        # 가변저항의 상태를 저장하는 변수와 Label 정의
        self.vr_value = StringVar()
        self.vr_value.set("가변저항 : {}%".format(str(0)))
        self.vr_label = Label(sensor_frame, background="yellow", textvariable=self.vr_value)
        self.vr_label.pack(expand=True, fill=BOTH)
        
        # 조도센서의 상태를 저장하는 변수와 Label 정의
        self.cds_value = StringVar()
        self.cds_value.set("조도센서 : {}%".format(str(0)))
        self.cds_label = Label(sensor_frame, background="lightblue", textvariable=self.cds_value)
        self.cds_label.pack(expand=True, fill=BOTH)
        
        # GAS센서의 상태를 저장하는 변수와 Label 정의
        self.gas_value = StringVar()
        self.gas_value.set("GAS : {}".format(str(0)))
        self.gas_label = Label(sensor_frame, background="lightpink", textvariable=self.gas_value)
        self.gas_label.pack(expand=True, fill=BOTH)
        
        # PSD센서의 상태를 저장하는 변수와 Label 정의
        self.psd_value = StringVar()
        self.psd_value.set("PSD : {} cm".format(str(0)))
        self.psd_label = Label(sensor_frame, background="white", textvariable=self.psd_value)
        self.psd_label.pack(expand=True, fill=BOTH)
        
        # 스레드를 사용하여 센서 데이터를 읽는 함수 실행
        self.t = threading.Thread(target=self.analogReadThread)
        self.t.start()

    def analogReadThread(self):
        try:
            while True:
                adc_data = bus.read_i2c_block_data(i2c_address, command, 5)
                
                # 가변저항 데이터 읽기
                vr_value = adc_data[1]
                vr_value = vr_value * 100 / 255
                vr_value = round(vr_value, 2)
                self.vr_value.set("가변저항 : {}%".format(str(vr_value)))
                
                # 조도센서 데이터 읽기
                cds_value = adc_data[2]
                cds_value = cds_value * 100 / 255
                cds_value = round(cds_value, 2)
                self.cds_value.set("조도센서 : {}%".format(str(cds_value)))
                
                # GAS 센서 데이터 읽기
                gas_value = adc_data[3]
                self.gas_value.set("GAS : {}".format(str(gas_value)))
                
                # PSD 센서 데이터 읽기
                psd_value = (adc_data[4] / 255.0 * 3.3) * 3 / 2
                psd_value = 29.988 * math.pow(psd_value, -1.173)
                psd_value = round(psd_value, 2)
                self.psd_value.set("PSD : {} cm".format(str(psd_value)))
                
                time.sleep(1)
        except Exception as err:
            time.sleep(1)
            print(err)

if __name__ == '__main__':
    root = Tk()
    mainFrame = MainFrame(root)
    root.mainloop()
    sys.exit()
