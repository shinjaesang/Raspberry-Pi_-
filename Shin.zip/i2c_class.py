import smbus
import time
import math

 
class read_i2c:
    bus= None
    ic2_address = 0x48
    command = 0x44    
    def __init__(self) -> None:
        self.bus = smbus.SMBus(1)
    def vr_read(self):    
        adc_data = self.bus.read_i2c_block_data(self.ic2_address , self.command,5)
        VrValue = adc_data[1]
        VrValue = VrValue * 100 / 255
        VrValue = round(VrValue,2)
        return VrValue
   
    def psd_read(self):
        adc_data = self.bus.read_i2c_block_data(self.ic2_address , self.command,5)
        psd_val = (adc_data[4]/255.0*3.3)*3/2
        psd_val = 29.988 *math.pow(psd_val , -1.173)
        psd_val = round(psd_val , 2)
        return psd_val
   
    def cds_read(self):
        adc_data = self.bus.read_i2c_block_data(self.ic2_address , self.command,5)
        CdsValue = adc_data[2]
        CdsValue = CdsValue * 100 /255
        CdsValue = round(CdsValue,2)
        return CdsValue
 
    def gas_read(self):
        adc_data = self.bus.read_i2c_block_data(self.ic2_address , self.command,5)
        GasValue = adc_data[3]
        return GasValue
   
 
class write_i2c:
    state = 0b0000000
    bus = None
   
    def __init__(self) :
        self.bus = smbus.SMBus(1)
    def On(self, cmd):
        self.state = (self.state | cmd)
        print(self.state)
        self.bus.write_byte(0x20 , self.state)
 
    def Off(self, cmd):
        self.state = (self.state & (~cmd))
        print(self.state)
        self.bus.write_byte(0x20 , self.state)

# ================================================================

