from tkinter import *

class MainFrame(Frame):
    def __init__(self, master):
        master.title('창')

        master.geometry('320x240+10+10')

if (__name__ == '__main__'):
    root = Tk()

    mainFrame = MainFrame(root)
    mainFrame.pack() 

    root.mainloop()