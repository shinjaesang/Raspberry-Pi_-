import cv2

# MJPG-streamer를 통해 영상 스트리밍
cap = cv2.VideoCapture('http://127.0.0.1:8090/?action=stream')

# MJPG-streamer를 사용하지 않는 경우 웹캠을 직접 캡처할 수 있음
# cap = cv2.VideoCapture(0)

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break
    cv2.imshow("Example Video (press 'q' to Quit)", frame)
    # 30 프레임을 만들기 위해 한 프레임 처리 후 33ms 대기
    key = cv2.waitKey(5)
    if key == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
