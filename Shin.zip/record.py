import sounddevice as sd
import scipy.io as sio
import scipy.io.wavfile
import pygame
import time


sample_rate = 44100
seconds = 3
print("녹음 시작...")
myrecording = sd.rec(int(seconds * sample_rate), samplerate = sample_rate, channels=2)
sd.wait()
print("녹음 종료")
print("Recording Stop")
sio.wavfile.write("output.wav", sample_rate, myrecording)

time.sleep(1)

pygame.mixer.init()
p = pygame.mixer.Sound('output.wav')
p.play()
time.sleep(3)