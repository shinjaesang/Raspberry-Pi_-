from tkinter import *
import sounddevice as sd
import numpy as np
import scipy.io as sio
import scipy.io.wavfile
import pygame
import time

fileNamePath = 'output.wav'
sample_rate = 44100  # 샘플레이트
seconds = 3  # 녹음시간


class MainFrame(Frame):
    def __init__(self, master):
        master.title('Play Example')
        master.geometry("400x240+10+10")

        # 텍스트 출력하기
        self.label = Label(master, background="yellow",
                          text="아래 PLAY 버튼을 누르면 녹음된 파일을 재생합니다.".format(seconds))
        self.label.pack(expand=1)

        # 녹음 및 재생 버튼
        self.playButton = Button(master, background="RED", text="PLAY", command=lambda: self.onButtonClickEvent())
        self.playButton.pack(expand=1)

    # 버튼의 이벤트를 처리하는 함수
    def onButtonClickEvent(self):
        # 샘플레이트 및 데이터를 통해 재생 시간을 구한다
        samplerate, data = sio.wavfile.read(fileNamePath)

        # numpy 배열 형태로 변환한다
        times = np.arange(len(data)) / float(samplerate)

        # 재생시간은 해당 자료형의 가장 마지막 인덱스인 -1 을 통해 구할 수 있다
        # 반올림 및 형변환을 통해 정수형태로 구한다
        play_time = int(round(times[-1]))

        # 재생을 위한 pygame 초기화
        pygame.mixer.init()

        # 경로를 지정하여 객체를 생성하고 재생한다
        p = pygame.mixer.Sound(fileNamePath)
        p.play()

        # 위에서 구한 파일의 길이 만큼 대기한다
        time.sleep(play_time)


# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    root = Tk()  # 창을 띄우기 위한 객체를 선언
    mainFrame = MainFrame(root)  # 창 객체를 인자로 클래스를 생성한다
    root.mainloop()  # python 의 창을 띄우고 이벤트 처리 수행 함수
    sys.exit()  # 소프트웨어를 완전히 종료한다
