from tkinter import *
import RPi.GPIO as GPIO
import time
import threading

COL1 = 5
COL2 = 6
COL3 = 7
ROW1 = 8
ROW2 = 9
ROW3 = 10
ROW4 = 11

COL_LIST = [COL1, COL2, COL3]
ROW_LIST = [ROW1, ROW2, ROW3, ROW4]

class MainFrame(Frame):
    def __init__(self, master):
        master.title('Keypad GUI Example')
        master.geometry("400x240+10+10")

        GPIO.setmode(GPIO.BCM)
        GPIO.setup(COL_LIST, GPIO.OUT)
        GPIO.setup(ROW_LIST, GPIO.IN)

        GPIO.output(COL1, GPIO.LOW)
        GPIO.output(COL2, GPIO.LOW)
        GPIO.output(COL3, GPIO.LOW)

        self.value = StringVar()
        self.value.set("현재 눌린 키 ={}".format("없음"))

        self.VrLabel = Label(master, background="yellow", textvariable=self.value)
        self.VrLabel.pack(side=LEFT, expand=1)

        self.t = threading.Thread(target=self.analogReadThread)
        self.t.start()

    def analogReadThread(self):
        try:
            while True:
                keyValue = self.getKeypad()
                keyStr = ''
                print(keyValue)
                if keyValue != -1:
                    keyStr = str(keyValue)
                else:
                    keyStr = "없음"

                keyMessage = "현재 눌린 키 ={}".format(keyStr)
                self.value.set(keyMessage)

                time.sleep(0.1)
        except Exception as err:
            time.sleep(1)
            print(err)

    def setColOut(self, col_idx):
        for enableIdx in range(0, 3):
            if col_idx == enableIdx:
                GPIO.output(COL_LIST[enableIdx], GPIO.HIGH)
            else:
                GPIO.output(COL_LIST[enableIdx], GPIO.LOW)

    def getKeypad(self):
        result = -1
        for col in range(0, 3):
            self.setColOut(col)
            for row in range(0, 4):
                if GPIO.input(ROW_LIST[row]) == GPIO.HIGH:
                    result = (row * 3) + col + 1
        return result

if __name__ == '__main__':
    try:
        root = Tk()
        mainFrame = MainFrame(root)
        root.mainloop()
    finally:
        GPIO.cleanup()
