from tkinter import *
class MainFrame(Frame):
    def __init__(self, master):
        master.title('창')
        master.geometry("320x240+10+10")
        self.checkbuttonvar = IntVar()
        checkbutton = Checkbutton(master, background="orange", text="CheckButton", variable = self.checkbuttonvar)
        checkbutton.pack(side=LEFT, expand = 1)
if (__name__ == '__main__'):
    root = Tk()
    mainFrame = MainFrame(root)
    root.mainloop()