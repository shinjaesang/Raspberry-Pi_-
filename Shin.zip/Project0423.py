from i2c_class import read_i2c
from i2c_class import write_i2c
import I2C_LCD_driver
import time

# PSD 센서와 LED 객체 생성
psd_sensor = read_i2c()
led_controller = write_i2c()

textLcd = I2C_LCD_driver.lcd()

# LED 색깔 상수 정의
BLUE_LED = 0b00000100
GREEN_LED = 0b00000010
RED_LED = 0b00000001

# 학번 및 LCD 초기화
student_id = "2301110335"  # 본인의 학번으로 변경
lcd_col1_text = f"[ID:{student_id}]"
lcd_col2_text = ""

try:
    while True:
        # PSD 센서에서 거리값 읽기
        distance = psd_sensor.psd_read()
        
        # 거리값에 따라 LED 제어
        if 20 < distance <= 30:
            led_controller.On(RED_LED)
            led_controller.Off(GREEN_LED | BLUE_LED)
        elif 31 < distance <= 50:
            led_controller.On(GREEN_LED)
            led_controller.Off(RED_LED | BLUE_LED)
        elif 51 < distance < 100:
            led_controller.On(BLUE_LED)
            led_controller.Off(GREEN_LED | RED_LED)
        else:
            led_controller.On(RED_LED | GREEN_LED | BLUE_LED)
        
        # 거리값 LCD에 출력
        distance_text = f"[range: {distance} cm]"
        textLcd.lcd_display_string(lcd_col1_text, 1)  # 첫 번째 줄에 학번 출력
        textLcd.lcd_display_string(distance_text, 2)  # 두 번째 줄에 거리 값 출력

        # 0.5초 동안 대기
        time.sleep(0.5)

except KeyboardInterrupt:
    # Ctrl+C 입력시 프로그램 종료
    led_controller.Off(RED_LED | GREEN_LED | BLUE_LED)
    print("Program terminated by user")