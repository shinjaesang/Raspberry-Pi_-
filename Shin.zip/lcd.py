import I2C_LCD_driver

textLcd = I2C_LCD_driver.lcd()

textLcd.lcd_display_string("ABCDEFG", 1)
textLcd.lcd_display_string("123456", 2)