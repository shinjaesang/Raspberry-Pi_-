import socket
import sys
import threading
import time
import RPi.GPIO as GPIO
 
GPIO.setmode(GPIO.BCM)
buzzer = 12
# 4옥타브 도레미~ 5옥타브 도
SCALE = [261, 294, 330, 349, 392, 440, 493]
SCALE_STR = {'do':0, 're':1, 'mi':2, 'fa':3, 'sol':4, 'la':5, 'ti':6}
# Buzzer핀의 GPIO를 출력으로 설정
GPIO.setup(buzzer, GPIO.OUT)
pwm = GPIO.PWM(buzzer, 100)
 
class ServerSocketClass():
    def __init__(self):
        while True :
            try:
                pwm.start(100)
                pwm.ChangeDutyCycle(100)
                self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR,1)
                server_address = ('', 10000)
                print("The Server is wating. IP: {0} PORT: {1}".format(server_address[0],server_address[1]))
                self.sock.bind(server_address)
                self.sock.listen(1)
                print("Waiting for Client access..")
                self.connection, client_address = self.sock.accept()
                try:
                    print("Connection from", client_address)
                    while True:
                        data = self.connection.recv(4096)
                        if data:
                            msgStr = data.decode("utf-8")
                            removeLf = msgStr.split('\n')[0]
                            msg = removeLf.split(',')
                            # buzzer,do 형태로 들어올 시 길이는 2이다.
                            if len(msg) == 2:
                                try:
                                    # buzzer 가 아니면 동작하지 않는다.
                                    if msg[0] == "buzzer":
                                        # dutycycle 50%
                                        pwm.ChangeDutyCycle(50)
                                        # 음계 명령문을 사용해서 주파수를 가져온다.
                                        pwm.ChangeFrequency(int(SCALE[SCALE_STR[msg[1]]]))
                                        print("RECEIVE Message >> [Sensor]:{} [Value]:{}".format(msg[0],msg[1]))
                                        time.sleep(0.5)
                                except KeyError as err:
                                    print("invalid command : {}".format(err))
 
                            # dutycycle을 100% 로 만들어서 소리를 끈다.
                            pwm.ChangeDutyCycle(100)
                        else:
                            print("Disconnect")
                            break
                        time.sleep(1)
                except Exception as err:
                    # 접속을 종료한다
                    self.connection.close()
                    print(err)
 
            except Exception as err:
                print(err)
           
            finally:
                print("Closing socket END Prgorams")
                self.sock.close()
if (__name__ == '__main__'):
    try:
        ServerSocketClass = ServerSocketClass() # 창 객체를 인자로 클래스를 생성한다
    except KeyboardInterrupt:
        print("Program force quit")
        sys.exit()
    GPIO.output(buzzer,GPIO.LOW)
    GPIO.cleanup()