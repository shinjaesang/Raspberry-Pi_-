from tkinter import *
import RPi.GPIO as GPIO
import smbus
import time
import threading

bus = smbus.SMBus(1)
i2c_address = 0x48
command = 0x44

# GPIO 설정
GPIO.setmode(GPIO.BCM)
SERVO_PIN = 25
GPIO.setup(SERVO_PIN, GPIO.OUT)
servo_pwm = GPIO.PWM(SERVO_PIN, 50)
servo_pwm.start(0)

class MainFrame(Frame):
    def __init__(self, master):
        super().__init__(master)
        master.title('Variable Resistor & Servo Motor Example')
        master.geometry("400x240+10+10")
        self.value = StringVar()
        self.value.set("가변저항 : {}%".format(str(0)))
        self.VrLabel = Label(master, background="yellow", textvariable=self.value)
        self.VrLabel.pack(side=LEFT, expand=1)
        self.angleLabel = Label(master, background="lightblue", text="서보 각도 : {}°".format(str(0)))
        self.angleLabel.pack(side=LEFT, expand=1)
        self.t = threading.Thread(target=self.analogReadThread)
        self.t.start()

    def analogReadThread(self):
        try:
            while True:
                adc_data = bus.read_i2c_block_data(i2c_address, command, 5)
                VrValue = adc_data[1]
                VrValue = VrValue * 100 / 255
                VrValue = round(VrValue, 2)
                self.value.set("가변저항 : {}%".format(str(VrValue)))

                # 서보 각도 계산 및 출력
                angle = VrValue * 160 / 100 + 10
                angle = max(min(angle, 170), 10)  # 10도부터 170도까지 제한
                self.angleLabel.config(text="서보모터 각도 : {}°".format(str(round(angle, 2))))

                # 서보 모터 각도 제어
                duty_cycle = (angle / 18) + 2.5
                servo_pwm.ChangeDutyCycle(duty_cycle)
                time.sleep(0.5)
        except Exception as err:
            time.sleep(1)
            print(err)

if __name__ == '__main__':
    root = Tk()
    mainFrame = MainFrame(root)
    root.mainloop()
    GPIO.cleanup()
