import cv2

# 비디오 스트림 URL
url = "http://127.0.0.1:8090/?action=stream"

# 비디오 스트림 열기
cap = cv2.VideoCapture(url)

if not cap.isOpened():
    print("Error: 비디오 스트림을 열 수 없습니다.")
else:
    while True:
        # 프레임을 하나씩 읽기
        ret, frame = cap.read()

        if not ret:
            print("Error: 프레임을 읽을 수 없습니다.")
            break

        # 프레임 표시
        cv2.imshow('Video Stream', frame)

        # 'q' 키를 누르면 비디오 스트림 종료
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # 모든 작업이 끝나면 캡처 해제
    cap.release()
    cv2.destroyAllWindows()
