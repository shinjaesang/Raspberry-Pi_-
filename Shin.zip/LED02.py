import smbus
import time
 
RED_LED   = 0b00000001
GREEN_LED = 0b00000010
BLUE_LED  = 0b00000100
 
# bus = smbus.SMBus(1)
# state = 0b00000001

# while True:
#     if state == 0x08:
#         state = RED_LED | GREEN_LED | BLUE_LED
#         bus.write_byte(0x20, state)
#         time.sleep(0.5)
#         state = 0x01
#     bus.write_byte(0x20, state)
#     time.sleep(0.5)
#     state = state << 1


bus = smbus.SMBus(1)
# state = BLUE_LED

while True:
    if state == 0x0:
        state = BLUE_LED
        bus.write_byte(0x20, state)
        time.sleep(0.5)
        state = state >>1