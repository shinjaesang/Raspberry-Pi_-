import socket
import sys
import threading
import time
import I2C_LCD_driver

# I2C_LCD_Driver 모듈을 사용하는 예제
textLcd = I2C_LCD_driver.lcd()
textLcd.lcd_clear()
class ServerSocketClass():

    def __init__(self):
        while True :
            try:
                pwm.start(100)
                pwm.ChangeDutyCycle(100)
                self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR,1)
                server_address = ('', 10000)
                print("The Server is wating. IP: {0} PORT: {1}".format(server_address[0],server_address[1]))
                self.sock.bind(server_address)
                self.sock.listen(1)
                print("Waiting for Client access..")
                self.connection, client_address = self.sock.accept()
                try:
                    print("Connection from", client_address)
                    while True:
                        data = self.connection.recv(4096)
                        if data:
                            msgStr = data.decode("utf-8")
                            removeLf = msgStr.split('\n')[0]
                            msg = removeLf.split(',’)
                                if len(msg) == 3:
                                    # textlcd 가 아니면 동작하지 않는다.
                                    if msg[0] == "textlcd":
                                        line = int(msg[1])
                                        if line >= 1 and line <= 2:
                                            textLcd.lcd_display_string(" ", line)
                                            # 16자 이내 아스키코드, 1은 첫 번째 줄이고 2는 두 번째 줄이다
                                            textLcd.lcd_display_string(msg[2], line)
                                            print(" line:{} / message:{}".format(msg[1],msg[2]))
                                            self.connection.sendall("OK.".encode('utf-8'))
                                        else:
                                            self.connection.sendall("fail!".encode('utf-8')))
                                else:
                                    print("Disconnect")
                                    break
                                time.sleep(1)
                        except Exception as err:
                            # 접속을 종료한다
                            self.connection.close()
                            print(err)
                    except Exception as err:
                        print(err)
                    finally:
                        print("Closing socket END Prgorams")
                        self.sock.close()
if (__name__ == '__main__'):
    try:
        ServerSocketClass = ServerSocketClass() # 창 객체를 인자로 클래스를 생성한다
    except KeyboardInterrupt:
        print("Program force quit")
        sys.exit()
    GPIO.output(buzzer,GPIO.LOW)
    GPIO.cleanup()
