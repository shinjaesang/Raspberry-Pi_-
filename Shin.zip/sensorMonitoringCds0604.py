from tkinter import *
import RPi.GPIO as GPIO
import smbus
import time
import threading

bus = smbus.SMBus(1)
i2c_address = 0x48
command = 0x44

class MainFrame(Frame):
    # MainFrame 클래스의 생성자.
    # self는 객체의 인스턴스를 의미하며, master는 부모 객체를 의미한다. 여기서는 Tk를 의미한다.
    def __init__(self, master):
        super().__init__(master)
        master.title('LightSensor(CdS) Monitoring')
        master.geometry("400x240+10+10")
        # 조도센서의 textvariable 옵션에 사용될 상태를 저장하는 변수 리스트
        self.value = StringVar()
        # Label은 textvariable 옵션을 통해 넘긴 변수(value)로 데이터를 변경한다
        self.value.set("조도센서 : {}%".format(str(0)))
        # 조도센서의 상태를 표시할 Label 위젯의 객체 정의한다
        self.cds_label = Label(master, background="yellow", textvariable=self.value)
        self.cds_label.pack(side=LEFT, expand=1)
        # 실시간으로 상태를 변경시키는 analogReadThread 동작 시키기 위한 스레드 생성
        self.t = threading.Thread(target=self.analogReadThread)
        self.t.start()

    def analogReadThread(self):
        try:
            while True:
                # i2c의 주소와 명령어를 전송하여 5Byte의 데이터를 읽어온다.
                # 맨 앞의 dummy data(index 0번 데이터)를 제외하고 뒤 4Byte가 4개의 ADC 포트 데이터이다.
                adc_data = bus.read_i2c_block_data(i2c_address, command, 5)
                # I2C로부터 센서 값을 읽어온다. CdS 센서는 2번이다.
                cds_value = adc_data[2]
                cds_value = cds_value * 100 / 255
                cds_value = round(cds_value, 2)
                # Label의 값을 변경 시킨다
                self.value.set("조도센서 : {}%".format(str(cds_value)))
        except Exception as err:
            time.sleep(1)
            print(err)

# 프로그램의 메인에 해당하는 최상위 구문
if __name__ == '__main__':
    root = Tk()  # 창을 띄우기 위한 객체를 선언
    mainFrame = MainFrame(root)  # 창 객체를 인자로 클래스를 생성한다
    root.mainloop()  # python의 창을 띄우고 이벤트 처리 수행 함수
    sys.exit()  # 소프트웨어를 완전히 종료한다.
