from tkinter import *
import I2C_LCD_driver

class MainFrame(Frame):
    def __init__(self, master):
        master.title('TextLCD Control Example')
        master.geometry("400x240+10+10")
        self.mylcd = I2C_LCD_driver.lcd()
        self.entryMessage_Line1 = StringVar()
        self.entryMessage_Line1.set('')
        self.entryMessage_Line2 = StringVar()
        self.entryMessage_Line2.set('')

        # Text LCD 첫 번째 라인
        entry_Line1 = Entry(master, background="magenta",textvariable=self.entryMessage_Line1)
        entry_Line1.pack(expand=1)
        sendButton1 = Button(master, background="cyan", text="Line-1 작성",command=lambda:self.onButtonClickEvent(0))
        sendButton1.pack(expand=1)

        # Text LCD의 두 번째 라인
        entry_Line2 = Entry(master, background="magenta", textvariable=self.entryMessage_Line2)
        entry_Line2.pack(expand=1)
        sendButton2 = Button(master, background="cyan", text="Line-2 작성", command=lambda:self.onButtonClickEvent(1))
        sendButton2.pack(expand=1)

    def onButtonClickEvent(self, pin):
        text = ''
        if (pin == 0) :
            text = self.entryMessage_Line1.get()
            self.mylcd.lcd_display_string(text, 1)
        elif (pin == 1) :
            text = self.entryMessage_Line2.get()
            self.mylcd.lcd_display_string(text, 2)
if (__name__ == '__main__'):
    root = Tk()
    mainFrame = MainFrame(root)
    root.mainloop()
    sys.exit()