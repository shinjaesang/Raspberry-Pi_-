import Adafruit_DHT
import time

sensor = Adafruit_DHT.DHT11

pin = 27

if __name__ == "__main__":
    while(True):
        humidity, temperature = Adafruit_DHT.read(sensor, pin)
        if humidity is not None and temperature is not None:
            print('')
            print('Temp={}°C Humidity={}%'.format(temperature, humidity))
            # print(f'Temp={temperature}°C Humidity={humidity}%')
        else:
            print('.',end='')

        time.sleep(1.0)