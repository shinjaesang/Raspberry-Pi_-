import RPi.GPIO as GPIO
import time

# GPIO의 모드를 BCM으로 설정한다(GPIO번호 사용)
GPIO.setmode(GPIO.BCM)

COL1 = 5
COL2 = 6
COL3 = 7
ROW1 = 8
ROW2 = 9
ROW3 = 10
ROW4 = 11

COL_LIST = [COL1, COL2, COL3]
ROW_LIST = [ROW1, ROW2, ROW3, ROW4]

if __name__ == "__main__":
	# COL1, COL2, COL3 핀을 OUTPUT 으로 설정한다.
	GPIO.setup(COL_LIST, GPIO.OUT)
	GPIO.setup(ROW_LIST, GPIO.IN)

	# 출력을 초기화한다.
	GPIO.output(COL1, GPIO.LOW)
	GPIO.output(COL2, GPIO.LOW)
	GPIO.output(COL3, GPIO.LOW)

	try:
		while True:
			result = -1
			print('┌────────────(열,행=결과)─────────────┐')
			for col in range(0, 3):
				print('    '+str(col) + '│', end='')
				# 열의 수 만큼 순회하며 현재 검사할 열을 선택한다. 
				for enableIdx in range(0, 3):
					if col == enableIdx:
						GPIO.output(COL_LIST[enableIdx], GPIO.HIGH)
					else:
						GPIO.output(COL_LIST[enableIdx], GPIO.LOW)
				# 선택열 활성화 상태에서 눌린 키가 어떤 것인지 감지한다.
				for row in range(0, 4):
					print('({0},{1}={2})'.format(str(col),str(row),str(GPIO.input(ROW_LIST[row]))),end='')
					if row == 3:
						print('')
			print('└─────────────────────────────────────┘')
			time.sleep(0.1)

	# 키보드 인터럽트, 에러 등으로 소스가 종료될 경우 GPIO를 초기화한 후 종료한다.
	finally:
		GPIO.cleanup()
