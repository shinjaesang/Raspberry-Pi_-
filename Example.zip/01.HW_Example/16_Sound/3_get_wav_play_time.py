import numpy as np
import scipy.io as sio
import scipy.io.wavfile

fileNamePath = 'output.wav'
samplerate, data = sio.wavfile.read(fileNamePath)
times = np.arange(len(data))/float(samplerate)
print("file '{}' play time = {}".format(fileNamePath,int(round(times[-1]))))