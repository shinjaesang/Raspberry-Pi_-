import numpy as np
import scipy.io as sio
import scipy.io.wavfile
import pygame
import time

fileNamePath = 'output.wav'

# 샘플레이트 및 데이터를 통해 재생 시간을 구한다.
samplerate, data = sio.wavfile.read(fileNamePath)

# numpy 배열 형태로 변환한다.
times = np.arange(len(data))/float(samplerate)

# 재생시간은 해당 자료형의 가장 마지막 인덱스인 -1을 통해 구할 수 있다.
# 반올림 및 형변환을 통해 정수형태로 구한다.
play_time = int(round(times[-1]))

# 재생을 위한 pygame 초기화
pygame.mixer.init()

# 경로를 지정하여 객체를 생성하고 재생한다.
p = pygame.mixer.Sound(fileNamePath)
p.play()

# 위에서 구한 파일의 길이 만큼 대기한다.
time.sleep(play_time)


