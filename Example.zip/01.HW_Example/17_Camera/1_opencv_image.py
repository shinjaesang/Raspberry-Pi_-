import cv2

frame = cv2.imread('example.jpg', 1)
cv2.imshow('example Image', frame)
cv2.waitKey(0)
cv2.destroyAllWindows()