# GPIO 제어를 위해 RPi.GPIO 모듈을 사용한다. 라즈베리파이 기본 모듈이다.
import RPi.GPIO as GPIO
# 지연시간 제어를 위해 time 모듈을 사용한다.
import time

# BCM 핀맵을 사용한다
GPIO.setmode(GPIO.BCM)

buzzer = 12

# 4옥타브 도레미~ 5옥타브 도
SCALE = [261, 294, 330, 349, 392, 440, 493, 523]


# Buzzer핀의 GPIO를 출력으로 설정
GPIO.setup(buzzer, GPIO.OUT) 

pwm = GPIO.PWM(buzzer, 100)

# try-except 는 파이썬의 예외처리 구문으로 
# 키보드로 Ctrl + C를 누를시 프로그램이 종료 된다.
try:
    # pwm 시작
    pwm.start(100) 
    # dutycycle 50%
    pwm.ChangeDutyCycle(50) 

    for i in SCALE:
      pwm.ChangeFrequency(i) #주파수 변경   
      time.sleep(0.5)
      
    # Buzzer를 끈다
    pwm.ChangeDutyCycle(100) 
    print("OFF")

# 종료 등의 키보드 인터럽트 발생시 처리 동작
except KeyboardInterrupt:
        # Buzzer를 끈다
        GPIO.output(buzzer,GPIO.LOW)
        # GPIO를 초기화한다
        GPIO.cleanup()