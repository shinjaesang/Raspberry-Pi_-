import RPi.GPIO as GPIO
import time

# GPIO의 모드를 BCM으로 설정한다(GPIO번호 사용)
GPIO.setmode(GPIO.BCM)

# 모터와 연결된 GPIO 번호를 변수에 저장한다.
MOTOR_P = 19
MOTOR_M = 13

if __name__ == "__main__":

    # MOTOR_P, MOTOR_M 핀을 OUTPUT 으로 설정한다.
    GPIO.setup(MOTOR_P, GPIO.OUT)
    GPIO.setup(MOTOR_M, GPIO.OUT)

    # 반복하여 모터를 정방향 -> 정지 -> 역방향 -> 정지 순서로 제어한다.
    try:
        while(True):

            # 정방향으로 모터를 회전한다.
            GPIO.output(MOTOR_M, GPIO.LOW)
            GPIO.output(MOTOR_P, GPIO.HIGH)

            # 1초간 정방향 출력을 유지한다.
            time.sleep(1)

            # 모터를 정지한다.
            GPIO.output(MOTOR_M, GPIO.LOW)
            GPIO.output(MOTOR_P, GPIO.LOW)

            # 1초간 정지상태를 유지한다.
            time.sleep(1)

            # 역방향으로 모터를 회전한다.
            GPIO.output(MOTOR_M, GPIO.HIGH)
            GPIO.output(MOTOR_P, GPIO.LOW)

            # 1초간 역방향 출력을 유지한다.
            time.sleep(1)

            # 모터를 정지한다.
            GPIO.output(MOTOR_M, GPIO.LOW)
            GPIO.output(MOTOR_P, GPIO.LOW)

            # 1초간 정지상태를 유지한다.
            time.sleep(1)

    # 키보드 인터럽트, 에러 등으로 소스가 종료될 경우 GPIO를 초기화한 후 종료한다.
    finally:
        GPIO.cleanup()
