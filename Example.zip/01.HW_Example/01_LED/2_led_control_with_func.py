import smbus
import time

# LED 제어 비트
RED_LED   = 0b00000001
GREEN_LED = 0b00000010
BLUE_LED  = 0b00000100

state = None
bus = None

##########################
#      LED 제어 함수
##########################
# i2c를 사용하기 위해 smbus 모듈을 초기화한다.
def ledInit():
    global state
    global bus
    state = 0b00000000
    bus = smbus.SMBus(1)

def ledOn(cmd):
    global state
    # LED는 bit로 제어되기 때문에 논리 연산자를 사용한다. 
    # |는 OR를 의미한다.
    state = (state | cmd) 
    bus.write_byte(0x20, state)   
    
def ledOff(cmd):
    global state
    # LED는 bit로 제어되기 때문에 논리 연산자를 사용한다. 
    # not cmd 를 만들고 state와 and하여 원하는 비트만 OFF시킨다.
    state = (state & (~cmd)) 
    bus.write_byte(0x20, state)

ledInit()

ledOn(RED_LED)
time.sleep(0.5)
ledOn(GREEN_LED)
time.sleep(0.5)
ledOn(BLUE_LED)
time.sleep(0.5)

ledOff(RED_LED)
time.sleep(0.5)
ledOff(GREEN_LED)
time.sleep(0.5)
ledOff(BLUE_LED)
time.sleep(0.5)

ledOn(RED_LED)
ledOn(GREEN_LED)
ledOn(BLUE_LED)
time.sleep(1)

ledOff(RED_LED)
ledOff(GREEN_LED)
ledOff(BLUE_LED)
time.sleep(1)


