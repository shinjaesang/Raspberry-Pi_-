/*******************************
 *  개별 H/W 제어/센서 예제
*******************************/

 * 본 예제는 각 제에 디바이스와 센서 및 모듈 등 디바이스에 대한 값을 가져오거나 제어하는 예제들입니다.
 * Python 기반이며 각각의 예제는 Terminal 과 Thonny Python IDE에서 수행 가능합니다.

1_LED
2_Relay
3_DC_Motor
4_Push_Switch
5_Passive_Buzzer
6_Servo
7_TempHumi
8_TextLCD
9_KeyPad
10_Ultrasonic
11_Step_Motor
12_VR
13_LightSensor
14_GAS
15_PSD
16_Sound
17_Camera