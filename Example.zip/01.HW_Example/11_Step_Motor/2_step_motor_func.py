import RPi.GPIO as GPIO
import time

# 스텝모터와 연결된 GPIO 번호를 변수에 저장한다.
STEP_IN1 = 16
STEP_IN2 = 20
STEP_IN3 = 21
STEP_IN4 = 26

pinsArray = [STEP_IN1,STEP_IN2,STEP_IN3,STEP_IN4] 

# 풀 스탭 구동 (1상 여자 방식)
signal_full = [
          [GPIO.HIGH, GPIO.LOW, GPIO.LOW, GPIO.LOW],
          [GPIO.LOW, GPIO.HIGH, GPIO.LOW, GPIO.LOW],
          [GPIO.LOW, GPIO.LOW, GPIO.HIGH, GPIO.LOW],
          [GPIO.LOW, GPIO.LOW, GPIO.LOW, GPIO.HIGH]
          ]

# 1스탭의 사이클
FULL_STEP = len(pinsArray)
ROTATE_360_STEP = 512 # FULL_STEP으로 512스탭
MOTOR_SPEED = 100 # 0~100

# 스태핑모터 상태에 대한 변수 (global 변수)
state = 'STOP'

def Run_Steps(isCwDirection,stepvalue,speed):
    global state
    if speed >= 100:
        speed = 100
    
    if speed != 0:
        speedValue = 0.2/speed
    else:
        speedValue = 0

    if isCwDirection:
        state = "CW"
    else:
        state = 'CCW'

    for i in range(0,stepvalue):
        # 정방향
        if isCwDirection == True:
            for step_idx in range(FULL_STEP):
                if state != 'CW' :
                    break
                sendSignal(step_idx)
                time.sleep(speedValue)
        else:
            for step_idx in reversed(range(FULL_STEP)):
                if state != 'CCW' :
                    break
                sendSignal(step_idx)
                time.sleep(speedValue)

# 스탭에 따라 시그널을 발생시킨다.
def sendSignal(step_idx) :
    for idx in range(4):
        GPIO.output(pinsArray[idx], signal_full[step_idx][idx])

if __name__ == "__main__":

    # BCM 핀맵을 사용한다
    GPIO.setmode(GPIO.BCM)
    for p_index in pinsArray:
        GPIO.setup(p_index, GPIO.OUT)
        GPIO.output(p_index, GPIO.LOW)

    # 반복하여 모터를 정방향 -> 정지 -> 역방향 -> 정지 순서로 제어한다.
    try:
        # Run_Steps(정방향여부(true/false),이동스텝수(한 바퀴 = 512),모터속도(1~100))

        # 정방향 
        Run_Steps(True,ROTATE_360_STEP,MOTOR_SPEED)
        
        # stop
        for p_index in pinsArray:
            GPIO.output(p_index, GPIO.LOW)
        time.sleep(1)

        # 역방향
        Run_Steps(False,ROTATE_360_STEP,MOTOR_SPEED)

    # 키보드 인터럽트, 에러 등으로 소스가 종료될 경우 GPIO를 초기화한 후 종료한다.
    finally:
        GPIO.cleanup()
