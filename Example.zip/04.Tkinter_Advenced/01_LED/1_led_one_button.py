from tkinter import *
import RPi.GPIO as GPIO
import time
import smbus

# LED 제어 비트
RED_LED   = 0b00000001
GREEN_LED = 0b00000010
BLUE_LED  = 0b00000100

# 프로그램의 창을 생성하는 MainFrame 클래스
class MainFrame(Frame):

    # MainFrame 클래스의 생성자.
    # self는 객체의 인스턴스를 의미하며, master는 부모 객체를 의미한다. 여기서는 Tk를 의미한다.
    def __init__(self, master):
        master.title('LED Control Example')

        # 윈도우 크기 및 좌표를 속성으로 한다.
        master.geometry("400x240+10+10")

        # 빨간 LED ON 
        redLedOnButton = Button(master, background="RED", text= "RED LED ON", command=lambda:self.onButtonClickEvent(0))
        redLedOnButton.pack(side=LEFT, expand = 1)

        # 빨간 LED OFF
        redLedOffButton = Button(master, background="RED", text= "RED LED OFF", command=lambda:self.onButtonClickEvent(1))
        redLedOffButton.pack(side=LEFT, expand = 1)

        self.ledInit()

    # 버튼의 이벤트를 처리하는 함수
    def onButtonClickEvent(self,pin):
        # 인자에 따른 이벤트를 지정한다.
        if(pin == 0) :
            self.ledOn(RED_LED)

        elif(pin == 1) :
            self.ledOff(RED_LED)

    ##########################
    #      LED 제어 함수
    ##########################
    # i2c를 사용하기 위해 smbus 모듈을 초기화한다.
    def ledInit(self):
        self.state = 0b00000000
        self.bus = smbus.SMBus(1)

    def ledOn(self,cmd):
        # LED는 bit로 제어되기 때문에 논리 연산자를 사용한다. 
        # |는 OR를 의미한다.
        self.state = (self.state | cmd) 
        self.bus.write_byte(0x20, self.state)   
        
    def ledOff(self,cmd):
        # LED는 bit로 제어되기 때문에 논리 연산자를 사용한다. 
        # not cmd 를 만들고 state와 and하여 원하는 비트만 OFF시킨다.
        self.state = (self.state & (~cmd)) 
        self.bus.write_byte(0x20, self.state)

# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    root = Tk()                 # 창을 띄우기 위한 객체를 선언
    mainFrame = MainFrame(root) # 창 객체를 인자로 클래스를 생성한다
    root.mainloop()             # python의 창을 띄우고 이벤트 처리 수행 함수
    sys.exit()                  # 소프트웨어를 완전히 종료한다.