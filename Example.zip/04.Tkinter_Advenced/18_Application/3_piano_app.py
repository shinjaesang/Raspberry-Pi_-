from tkinter import *
import RPi.GPIO as GPIO
import time

# Buzzer 핀에 대한 정의
buzzer = 12

# 4옥타브 도레미~ 5옥타브 도
TONE_SCALE = [261, 294, 330, 349, 392, 440, 493, 523]
SEMITONE_SCALE = [277, 311, 369, 415, 466]

# 프로그램의 창을 생성하는 MainFrame 클래스
class MainFrame(Frame):
    
    # MainFrame 클래스의 생성자.
    # self는 객체의 인스턴스를 의미하며, master는 부모 객체를 의미한다. 여기서는 Tk를 의미한다.
    def __init__(self, master):
        master.title('Piano App')

        # 윈도우 크기 및 좌표를 속성으로 한다.
        master.geometry("420x240+10+10")

        self.gpio_buzzer_init()

        # 건반
        tone_do = Button(master, background="WHITE", command=lambda:self.onButtonToneEvent(0))
        tone_do.place(x=10,y=20, width=50, height=200)
        
        tone_re = Button(master, background="WHITE", command=lambda:self.onButtonToneEvent(1))
        tone_re.place(x=60,y=20, width=50, height=200)

        tone_mi = Button(master, background="WHITE", command=lambda:self.onButtonToneEvent(2))
        tone_mi.place(x=110,y=20, width=50, height=200)

        tone_fa = Button(master, background="WHITE",command=lambda:self.onButtonToneEvent(3))
        tone_fa.place(x=160,y=20, width=50, height=200)

        tone_sol = Button(master, background="WHITE",command=lambda:self.onButtonToneEvent(4))
        tone_sol.place(x=210,y=20, width=50, height=200)

        tone_la = Button(master, background="WHITE",command=lambda:self.onButtonToneEvent(5))
        tone_la.place(x=260,y=20, width=50, height=200)

        tone_ti = Button(master, background="WHITE", command=lambda:self.onButtonToneEvent(6))
        tone_ti.place(x=310,y=20, width=50, height=200)

        tone_do = Button(master, background="WHITE", command=lambda:self.onButtonToneEvent(7))
        tone_do.place(x=360,y=20, width=50, height=200)

        # 반음 건반
        semitoneKey_do = Button(master, background="BLACK", command=lambda:self.onButtonSemitoneEvent(0))
        semitoneKey_do.place(x=40,y=21, width=35, height=130)

        semitoneKey_re = Button(master, background="BLACK",command=lambda:self.onButtonSemitoneEvent(1))
        semitoneKey_re.place(x=92,y=21, width=35, height=130)

        semitoneKey_fa = Button(master, background="BLACK", command=lambda:self.onButtonSemitoneEvent(2))
        semitoneKey_fa.place(x=190,y=21, width=35, height=130)

        semitoneKey_sol = Button(master, background="BLACK", command=lambda:self.onButtonSemitoneEvent(3))
        semitoneKey_sol.place(x=242,y=21, width=35, height=130)

        semitoneKey_la = Button(master, background="BLACK", command=lambda:self.onButtonSemitoneEvent(4))
        semitoneKey_la.place(x=295,y=21, width=35, height=130)

    #############
    # 건반
    #############
    def onButtonToneEvent(self,tone):
        self.pwm.ChangeDutyCycle(50) 
        self.pwm.ChangeFrequency(TONE_SCALE[tone]) 
        time.sleep(0.1)
        self.pwm.ChangeDutyCycle(100)  

    #############
    # 반음 건반
    #############
    def onButtonSemitoneEvent(self,tone):
        self.pwm.ChangeDutyCycle(50) 
        self.pwm.ChangeFrequency(SEMITONE_SCALE[tone]) 
        time.sleep(0.1)
        self.pwm.ChangeDutyCycle(100)  

    # GPIO를 사용하기전 초기화하는 함수
    def gpio_buzzer_init(self):
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(buzzer,GPIO.OUT)
        GPIO.output(buzzer,GPIO.LOW)    
        self.pwm = GPIO.PWM(buzzer, TONE_SCALE[0])
        # pwm 시작
        self.pwm.start(100) 

    # 프로그램 종료시 호출하여 GPIO를 cleanup 한다.
    def gpio_buzzer_cleanup(self):
        GPIO.output(buzzer,GPIO.LOW)
        GPIO.cleanup()

# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    root = Tk()                    # 창을 띄우기 위한 객체를 선언
    mainFrame = MainFrame(root)    # 창 객체를 인자로 클래스를 생성한다
    root.mainloop()                # python의 창을 띄우고 이벤트 처리 수행 함수
    mainFrame.gpio_buzzer_cleanup()          # 프로그램 종료 후 GPIO를 cleanup 한다
    sys.exit()                     # 소프트웨어를 완전히 종료한다.
