# 다음의 모듈을 필히 설치한다.
# $sudo apt-get install python3-smbus
# $sudo adduser pi i2c
from tkinter import *
import RPi.GPIO as GPIO
import smbus
import time
import threading
import math

# smbus 모듈을 통해 i2c 모듈에 연결된 AD 모듈을 읽어온다
bus = smbus.SMBus(1)

# 연결된 i2c 모듈의 채널은 0x48이다
i2c_address = 0x48

# PCF8591 칩에서 데이터를 받기위한 명령어다.
command = 0x44

# 프로그램의 창을 생성하는 MainFrame 클래스
class MainFrame(Frame):
    
    # MainFrame 클래스의 생성자.
    # self는 객체의 인스턴스를 의미하며, master는 부모 객체를 의미한다. 여기서는 Tk를 의미한다.
    def __init__(self, master):
        master.title('PSD Monitoring Example')

        # 윈도우 크기 및 좌표를 속성으로 한다.
        master.geometry("400x240+10+10")

        # PDS센서의 textvariable 옵션에 사용될 상태를 저장하는 변수 리스트
        self.value = StringVar()

        # Label은 textvariable 옵션을 통해 넘긴 변수(value)로 데이터를 변경한다
        self.value.set("PSD : {}".format(str(0)))

        # PDS센서의 상태를 표시할 Label 위젯의 객체 정의한다
        self.psd_label = Label(master,background="yellow", textvariable = self.value)
        self.psd_label.pack(side = LEFT, expand = 1)

        # 실시간으로 상태를 변경시키는 analogReadThread 동작 시키기 위한 스레드 생성
        self.t = threading.Thread(target=self.analogReadThread)
        self.t.start()

    # PSD센서를 이용해 조도 값을 측정하는 스레드
    def analogReadThread(self) :
        try :
            while(True):
                # i2c의 주소와 명령어를 전송하여 5Byte의 데이터를 읽어온다.
                # 맨 앞의 dummy data(index 0번 데이터)를 제외하고 뒤 4Byte가 4개의 ADC 포트 데이터이다.
                adc_data = bus.read_i2c_block_data(i2c_address, command, 5)

                # I2C로 부터 센서 값을 읽어온다 PSD 센서는 4번이다.
                # adc 칩에 입력되는 전압을 계산한 후 => (adc_data[4] / 255.0 * 3.3)
                # 전압 분배 저항 통과 하기 전의 전압을 계산한다.  => * 3 / 2
                psd_value = (adc_data[4] / 255.0 * 3.3) * 3 / 2
                psd_value = 29.988 * math.pow(psd_value , -1.173)

                psd_value = round(psd_value, 2)

                # Label의 값을 변경 시킨다
                self.value.set("PSD : {} cm".format(str(psd_value)))
                time.sleep(0.1)

        except Exception as err: 
            time.sleep(1)
            print(err)

# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    root = Tk()                 # 창을 띄우기 위한 객체를 선언
    mainFrame = MainFrame(root) # 창 객체를 인자로 클래스를 생성한다
    root.mainloop()             # python의 창을 띄우고 이벤트 처리 수행 함수
    sys.exit()                  # 소프트웨어를 완전히 종료한다.