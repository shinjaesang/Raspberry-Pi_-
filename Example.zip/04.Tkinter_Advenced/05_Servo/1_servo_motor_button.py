from tkinter import *
import RPi.GPIO as GPIO
import time
import threading

# 서보모터 핀
SERVO_PIN = 25

# 프로그램의 창을 생성하는 MainFrame 클래스
class MainFrame(Frame):

    SERVO_ANGLE = 90

    # MainFrame 클래스의 생성자.
    # self는 객체의 인스턴스를 의미하며, master는 부모 객체를 의미한다. 여기서는 Tk를 의미한다.
    def __init__(self, master):
        master.title('Servo Motor Control Example')

        # 윈도우 크기 및 좌표를 속성으로 한다.
        master.geometry("400x240+10+10")
        self.gpio_servo_init()
        
        self.servo_pwm = GPIO.PWM(SERVO_PIN,50) # 50Hz, 20ms 간격을 의미
        self.servo_pwm.start(0)
    
        # 버튼 객체의 리스트
        button = []

        button.append( Button(master, background="cyan", text= "◀", command=lambda:self.onButtonClickEvent(0)) )
        button[0].pack(side=LEFT, expand = 1)

        button.append( Button(master, background="cyan", text= "●", command=lambda:self.onButtonClickEvent(1)) )
        button[1].pack(side=LEFT, expand = 1)

        button.append( Button(master, background="cyan", text= "▶", command=lambda:self.onButtonClickEvent(2)) )
        button[2].pack(side=LEFT, expand = 1)

        self.servo_pwm.ChangeDutyCycle(0)

    # 버튼의 이벤트를 처리하는 함수
    def onButtonClickEvent(self,pin):

        # ◀ 왼쪽으로 이동
        if(pin == 0) :
            if(self.SERVO_ANGLE > 10):
                self.SERVO_ANGLE = self.SERVO_ANGLE - 5
            else :
                self.SERVO_ANGLE = 10
            self.setAngle(self.SERVO_ANGLE)

        # ● 초기화 버튼
        elif(pin == 1) :
            # 1~90도까지 서보모터를 이동 시킨다
            for i in range(1, 90) :
                self.SERVO_ANGLE = i
                self.setAngle(self.SERVO_ANGLE)

        # ▶ 오른쪽으로 이동
        elif(pin == 2) :
            if(self.SERVO_ANGLE < 170):
                self.SERVO_ANGLE = self.SERVO_ANGLE + 5
            else:
                self.SERVO_ANGLE = 170
            self.setAngle(self.SERVO_ANGLE)

        # 버튼 클릭 이후 100ms 정도의 텀을 둔다
        time.sleep(0.1)

        # 이동 후 듀티비는 0으로 만들어 서보모터의 토크를 해제한다.
        # 이는 오동작을 방지하기 위함
        self.servo_pwm.ChangeDutyCycle(0)
        print("X = %d" % (self.SERVO_ANGLE))

    # 서보모터의 각도를 조정한다
    # 18을 나눈 후 2.5를 더한다. 
    # 2% ~ 12.5%를 DutyCycle로 잡고 제어할때 대략적인 각도 계산 값임.
    def setAngle(self,angle):
        duty = (angle / 18) + 2.5
        self.servo_pwm.ChangeDutyCycle(duty)
        time.sleep(0.001)    
    
    # GPIO를 사용하기전 초기화하는 함수
    def gpio_servo_init(self):
        # BCM 핀맵을 사용한다
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(SERVO_PIN,GPIO.OUT)

# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    root = Tk()                 # 창을 띄우기 위한 객체를 선언
    mainFrame = MainFrame(root) # 창 객체를 인자로 클래스를 생성한다
    root.mainloop()             # python의 창을 띄우고 이벤트 처리 수행 함수
    GPIO.cleanup()              # 창 종료 후 GPIO를 초기화한다.
    sys.exit()                  # 소프트웨어를 완전히 종료한다.