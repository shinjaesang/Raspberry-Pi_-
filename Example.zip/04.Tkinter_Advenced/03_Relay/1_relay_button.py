from tkinter import *
import RPi.GPIO as GPIO
import time
import smbus

# 제어 비트
RELAY_1   = 0b00010000
RELAY_2   = 0b00100000

# 프로그램의 창을 생성하는 MainFrame 클래스
class MainFrame(Frame):

    # MainFrame 클래스의 생성자.
    # self는 객체의 인스턴스를 의미하며, master는 부모 객체를 의미한다. 여기서는 Tk를 의미한다.
    def __init__(self, master):
        master.title('Relay Control Example')

        # 윈도우 크기 및 좌표를 속성으로 한다.
        master.geometry("400x240+10+10")

        # Relay-1에 대한 엔트리 설정    
        relay_1 = Entry(master, background="magenta")
        relay_1.pack(expand = 1)

        # Relay-1 ON
        relay1OnButton = Button(relay_1, background="RED", text= "Relay-1 ON", command=lambda:self.onButtonClickEvent(0))
        relay1OnButton.pack(side = LEFT)

        # Relay-1 OFF
        relay1OffButton = Button(relay_1, background="gray", text= "Relay-1 OFF", command=lambda:self.onButtonClickEvent(1))
        relay1OffButton.pack(side = LEFT)

        # Relay-2에 대한 엔트리 설정
        relay_2 = Entry(master, background="magenta")
        relay_2.pack(expand = 1)

        # Relay-2 ON
        relay2OnButton = Button(relay_2, background="RED", text= "Relay-2 ON", command=lambda:self.onButtonClickEvent(2))
        relay2OnButton.pack(side = LEFT)

        # Relay-2 OFF
        relay2OffButton = Button(relay_2, background="gray", text= "Relay-2 OFF", command=lambda:self.onButtonClickEvent(3))
        relay2OffButton.pack(side = LEFT)

        self.relayInit()

    # 버튼의 이벤트를 처리하는 함수
    def onButtonClickEvent(self,pin):
        # 인자에 따른 이벤트를 지정한다.
        if(pin == 0) :
            self.relayOn(RELAY_1)

        elif(pin == 1) :
            self.relayOff(RELAY_1)

        elif(pin == 2) :
            self.relayOn(RELAY_2)

        elif(pin == 3) :
            self.relayOff(RELAY_2)

    ##########################
    #     Relay 제어 함수
    ##########################
    # i2c를 사용하기 위해 smbus 모듈을 초기화한다.
    def relayInit(self):
        self.state = 0b00000000
        self.bus = smbus.SMBus(1)

    def relayOn(self,cmd):
        # Relay는 bit로 제어되기 때문에 논리 연산자를 사용한다. 
        # |는 OR를 의미한다.
        self.state = (self.state | cmd) 
        self.bus.write_byte(0x20, self.state)   
        
    def relayOff(self,cmd):
        # Relay는 bit로 제어되기 때문에 논리 연산자를 사용한다. 
        # not cmd 를 만들고 state와 and하여 원하는 비트만 OFF시킨다.
        self.state = (self.state & (~cmd)) 
        self.bus.write_byte(0x20, self.state)

# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    root = Tk()                 # 창을 띄우기 위한 객체를 선언
    mainFrame = MainFrame(root) # 창 객체를 인자로 클래스를 생성한다
    root.mainloop()             # python의 창을 띄우고 이벤트 처리 수행 함수
    sys.exit()                  # 소프트웨어를 완전히 종료한다.