# OpenCV : 영상처리 모듈, python3용
#   - 빌드 혹은 패키지 파일 설치
# Pillow : 이미지 처리 모듈 
#   -  pip3 install pillow 혹은 sudo apt-get install python3-pip
from tkinter import *
from PIL import Image, ImageTk, ImageFilter
import RPi.GPIO as GPIO
import time
import threading
import cv2

# 프로그램의 창을 생성하는 MainFrame 클래스
class MainFrame(Frame):
    
    # MainFrame 클래스의 생성자.
    # self는 객체의 인스턴스를 의미하며, master는 부모 객체를 의미한다. 여기서는 Tk를 의미한다.
    def __init__(self, master):
        master.title('Camera')

        # 윈도우 크기 및 좌표를 속성으로 한다.
        master.geometry("400x240+10+10")

        # 영상이 출력되는 Frame.
        opencvFrame = Frame(master)
        # 상단에 표시해야 하므로 side 는 TOP 이고, 상하 여백은 10으로 한다.
        opencvFrame.pack(side = TOP, pady = 10)

        self.lmain = Label(opencvFrame)
        self.lmain.pack()

        # 카메라 이미지 읽어오기 및, 영상 출력 스레드 함수 호출
        self.cap = cv2.VideoCapture('http://127.0.0.1:8090/?action=stream')
        self.show_frame()

    # 영상  출력을 위한 함수로, after 명령을 통해 지속적으로 호출한다.
    def show_frame(self):
        # 카메라의 프레임을 읽어온다
        ret, frame = self.cap.read()
        # 카메라의 화면을 뒤집어 준다.
        # 1 수평 0 수직 -1 수평+수직
        frame = cv2.flip(frame, 2)
        # 컬러 전환 함수
        processImage = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        # 이미지를 줄인다
        processImage = cv2.resize(processImage, (320, 240))
        # 이미지 버퍼를 만드는 함수
        processImage = Image.fromarray(processImage)
        # Tkinter 에서 처리할 수 있는 이미지로 변환한다 (PhotoImage 클래스)
        processImage = ImageTk.PhotoImage(image=processImage)

        # lmain.processImage = processImage 구문은 참조를 증가시켜 가비지 컬렉션이 삭제하지 않게 한다.
        self.lmain.processImage = processImage
        # Label 위젯에 이미지를 출력한다
        self.lmain.configure(image=processImage)
        # 밀리초마다 두번째 파라미터의 함수를 호출하는 콜백 함수
        self.lmain.after(1, self.show_frame) 

# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    root = Tk()                 # 창을 띄우기 위한 객체를 선언
    mainFrame = MainFrame(root) # 창 객체를 인자로 클래스를 생성한다
    root.mainloop()             # python의 창을 띄우고 이벤트 처리 수행 함수
    sys.exit()                  # 소프트웨어를 완전히 종료한다.