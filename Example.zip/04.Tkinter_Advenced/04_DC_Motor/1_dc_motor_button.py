from tkinter import *
import RPi.GPIO as GPIO
import time
import threading

MOTOR_P = 19
MOTOR_M = 13

state = ""

# 프로그램의 창을 생성하는 MainFrame 클래스
class MainFrame(Frame):

    # MainFrame 클래스의 생성자.
    # self는 객체의 인스턴스를 의미하며, master는 부모 객체를 의미한다. 여기서는 Tk를 의미한다.
    def __init__(self, master):
        master.title('DC Motor Control Example')

        # 윈도우 크기 및 좌표를 속성으로 한다.
        master.geometry("400x240+10+10")
                
        dcmotorthread = threading.Thread(target=self.dc_motor_thread)
        dcmotorthread.start()

        # 버튼 객체의 리스트
        button = []
        
        button.append( Button(master, background="cyan", text= "Clockwise ↻", command=lambda:self.onButtonClickEvent(0)) )
        button[0].pack(side=LEFT, expand = 1)

        button.append( Button(master, background="cyan", text= "STOP", command=lambda:self.onButtonClickEvent(1)) )
        button[1].pack(side=LEFT, expand = 1)

        button.append( Button(master, background="cyan", text= "Count Clockwise ↺", command=lambda:self.onButtonClickEvent(2)) )
        button[2].pack(side=LEFT, expand = 1)

    # 버튼의 이벤트를 처리하는 함수
    def onButtonClickEvent(self,pin):
        # 정보를 담고 있는 전역변수를 변경하려면 global 키워드를 사용한다
        global state

        # 인자에 따른 이벤트를 지정한다.
        # CW 시계 방향 STOP 정지 CCW 반 시계 방향
        if(pin == 0) :
            state = 'CW'

        elif(pin == 1) :
            state = 'STOP'

        elif(pin == 2) :
            state = 'CCW'

    # 아래 함수가 스레드로 주기적으로 구동되며 상태에 따른 동작을 수행한다.
    def dc_motor_thread(self) :
        try :
            while(True):
                if state == 'CW' :
                    GPIO.output(MOTOR_P,GPIO.HIGH)
                    GPIO.output(MOTOR_M,GPIO.LOW)
                    
                elif state == 'STOP':
                    GPIO.output(MOTOR_P,GPIO.LOW)
                    GPIO.output(MOTOR_M,GPIO.LOW)

                elif state == 'CCW':
                    GPIO.output(MOTOR_P,GPIO.LOW)
                    GPIO.output(MOTOR_M,GPIO.HIGH)
                time.sleep(0.1)
        except : 
            time.sleep(1)

# GPIO를 사용하기전 초기화하는 함수
def gpio_dcMotor_init():
    # BCM 핀맵을 사용한다
    GPIO.setmode(GPIO.BCM)
    # DC 모터의를 출력으로 설정한다
    GPIO.setup(MOTOR_P,GPIO.OUT)
    GPIO.setup(MOTOR_M,GPIO.OUT)
    # DC 모터의 출력을 LOW로 한다
    GPIO.output(MOTOR_P, GPIO.LOW)
    GPIO.output(MOTOR_M, GPIO.LOW)


# 프로그램 종료전 GPIO를 초기화한다.
def gpio_dcMotor_cleanup():
    # DC 모터의 출력을 LOW로 한다
    GPIO.output(MOTOR_P, GPIO.LOW)
    GPIO.output(MOTOR_M, GPIO.LOW)
    GPIO.cleanup()

# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    gpio_dcMotor_init()
    root = Tk()                 # 창을 띄우기 위한 객체를 선언
    mainFrame = MainFrame(root) # 창 객체를 인자로 클래스를 생성한다
    root.mainloop()             # python의 창을 띄우고 이벤트 처리 수행 함수
    gpio_dcMotor_cleanup()      # 창 종료 후 GPIO를 초기화한다.
    sys.exit()                  # 소프트웨어를 완전히 종료한다.