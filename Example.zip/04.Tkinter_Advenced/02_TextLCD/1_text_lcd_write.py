from tkinter import *
import I2C_LCD_driver # LCD를 사용하기 위한 모듈
import time
import threading


# 프로그램의 창을 생성하는 MainFrame 클래스
class MainFrame(Frame):

    # MainFrame 클래스의 생성자.
    # self는 객체의 인스턴스를 의미하며, master는 부모 객체를 의미한다. 여기서는 Tk를 의미한다.
    def __init__(self, master):
        master.title('TextLCD Control Example')

        # 윈도우 크기 및 좌표를 속성으로 한다.
        master.geometry("400x240+10+10")
        
        self.mylcd = I2C_LCD_driver.lcd()

        self.entryMessage_Line1 = StringVar()
        self.entryMessage_Line1.set('Text LCD-1')

        # Text LCD의 첫 번째 라인의 메세지를 작성하는 엔트리 생성하기
        entry_Line1 = Entry(master, background="magenta", textvariable=self.entryMessage_Line1)
        # TextLCD의 첫 번째 라인에 메세지를 보내는 버튼 생성하기
        sendButton1 = Button(master, background="cyan", text="Line-1 작성", command=lambda:self.onButtonClickEvent())

        # pack() 함수를 사용해서 위젯을 배치한다.
        # expand 옵션은 master에 의해 제공되는 공간을 모두 사용할지 여부를 결정한다.
        entry_Line1.pack(expand=1)
        sendButton1.pack(expand=1)

        # 버튼의 이벤트를 처리하는 함수
    def onButtonClickEvent(self):
        text = ''
    
        # textvariable 옵션으로 지정된 변수 entryMessage의 값을 읽어 text에 저장한다
        text = self.entryMessage_Line1.get()
        self.mylcd.lcd_display_string(text, 1)
        
        print(text)
        

# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    root = Tk()                 # 창을 띄우기 위한 객체를 선언
    mainFrame = MainFrame(root) # 창 객체를 인자로 클래스를 생성한다
    root.mainloop()             # python의 창을 띄우고 이벤트 처리 수행 함수
    sys.exit()                  # 소프트웨어를 완전히 종료한다.