/****************************
 * 실시간 차트 그래프 생성 (라인 차트는 다 비슷하기 때문에 함수 하나로 통합하고, 차트 이름(sType)에 따라 모양이 달라지게 만듬.)
 * 추후, 필요하다 싶으면 ____Init 함수를 분리할 예정
 * sEId : 차트를 넣을 대상 Element의 ID
 * sType : 차트 종류
 ****************************/
function bb_RealTimeChartInit(sEId, sType="line"){
    var oChart = bb.generate({
        bindto: sEId,
        data: {
            type: sType,
            x: "Time",
            xFormat: "%H:%M:%S",
            rows: []
        },
        transition: {
            duration: 0
        },
        point: {
            r: 3.0,
            focus: {
                expand: {
                    enabled: true
                }
            }
        },
        tooltip: {
            show: true
        },
        grid: {
            x: {
                show: true
            },
            y: {
                show: true
            }
        },
        axis: {
            x: {
                type: "timeseries",
                tick: {
                    format: "%H:%M:%S"
                },
                label: {
                    text: "Time",
                    position: "outer-center"
                }
            },
            y: {
                label: {
                    text: "Value",
                    position: "outer-middle"
                },
                min: 0
            }
        }
    });

    return oChart;
}
/****************************
 * 실시간 차트 그래프 데이터를 로드하고, 실시간으로 표시됨
 * oChart : 차트 객체
 * nPosition : 대상 대시보드
 ****************************/
function bb_RealTimeLoadData(oChart, node_ids){
    var row = [[]]; //billboard.js 차트의 데이터
    var divide = 1; //그래프상의 한 마디당 시간간격(초단위)
    var limit = 10; //최대 뽑아올 데이터갯수
    var delay = divide * 1000; //차트 새로고침 타이머 설정

    var oPost = {
        "node_id"   : node_ids,
        "divide"    : divide,
        "limit"     : limit,
		"select_only_number" : true
    };
    $.ajax({
        "url"      : "/api/selectDataByTimestamp?" + serializeParam(oPost, "utf-8"),
        "type"     : "GET",
        "dataType" : "json",
        "success"  : function(jData) {
            // console.log(jData);
            if(jData["status"] == "success") { //정상적으로 데이터를 가져온 경우
                var aNodeList = jData["node"];
                var aDataList = jData["data"];
                var aTimeGroup = jData["time"]["group"];

                if(aNodeList.length > 0) { //노드 데이터가 존재하는 경우의 처리
                    var oNodeIdx = {};
                    var arrData = [];
                    
                    row[0].push("Time");

                    //범례 세팅
                    for(var i=0; i<aNodeList.length; i++) {
                        var sNodeID = aNodeList[i];

                        row[0].push(sNodeID);
                        oNodeIdx[sNodeID] = i;
                    };

                    //모든데이터 기본값(0)으로 초기화
                    for(var i=0; i<aTimeGroup.length; i++) { //시간범위만큼 데이터체크
                        var arrTmp = [];
                        arrTmp.push(aTimeGroup[i].substr(11)); //시분초만 표시되면된다 ex) "16:31:20" => "16:31:20"
                        for(j=0; j<aNodeList.length; j++) {
                            arrTmp.push(0);
                        }
                        arrData.push(arrTmp); //각 시간마다 노드의 상태? 값을 주는 것 같다.
                    }

                    //실제로 출력된 데이터값만 배열에 다시 세팅
                    for(var i=0; i<aDataList.length; i++) {
                        var nNodeIdx = oNodeIdx[aDataList[i]["node_id"]] + 1;
                        var nDataIdx = aDataList[i]["TIME_GROUP"];

						if(isNumeric(aDataList[i]["node_value"])){
							var nCurData = Number(aDataList[i]["node_value"]);
							arrData[nDataIdx][nNodeIdx] = nCurData;
						}
                    }
                    
                    for(var i=0; i<arrData.length;i++){
                        row.push(arrData[i]);
                    }
                }
                else { //값이 존재하지 않는 경우에 대한 처리
                    row[0].push("");
                    row.push(limit);
                }

                oChart.load({
                    rows: row,
                    unload: row[0],
                    done: function() { // load가 완료된 경우
                        setTimeout(bb_RealTimeLoadData, delay, oChart, node_ids);
                    }
                });
                // oChart.chart.draw(oChart.data, oChart.option);
            }
            
            // oChart.timer = window.setTimeout(oChart.func, oChart.delay);
        },
        "error"    : function(oXhr) {
            console.dir(oXhr);
        }
    });
}
/****************************
 * 막대 차트
 * (현재 데이터만을 표시함)
 ****************************/
function bb_barInit(sEId){
    var oChartBar = bb.generate({
        bindto: sEId,
        data: {
            type: "bar",
            rows: []
        },
        transition: {
            duration: 100
        },
        bar: {
            width: {
                ratio: 0.2
            }
        },
        axis: {
            x: {
                show: false
            }
        }
    });

    return oChartBar;
}
/****************************
 * 도넛 차트
 * (현재 데이터만을 표시함)
 ****************************/
function bb_donutInit(sEId){
    var oChartDonut = bb.generate({
        bindto: sEId,
        data: {
            type: "donut",
            rows: []
        },
        transition: {
            duration: 100
        }
    });

    return oChartDonut;
}

/****************************
 * 버블 차트
 * (현재 데이터만을 표시함)
 ****************************/
function bb_bubbleInit(sEId){
    var oChartBubble = bb.generate({
        bindto: sEId,
        data: {
            type: "bubble",
            rows: []
        },
        transition: {
            duration: 100
        },
        grid: {
            x: {
                show: false
            },
            y: {
                show: true
            }
        },
        axis: {
            x: {
                show: false
            }
        }
    });

    return oChartBubble;
}

/****************************
 * 파이 차트
 * (현재 데이터만을 표시함)
 ****************************/
function bb_pieInit(sEId){
    var oChartPie = bb.generate({
        bindto: sEId,
        data: {
            type: "pie",
            rows: []
        },
        transition: {
            duration: 100
        },
    });

    return oChartPie;
}

/****************************
 * 게이지 차트
 * (현재 데이터만을 표시함)
 ****************************/
function bb_gaugeInit(sEId){
    var oChart = bb.generate({
        bindto: sEId,
        data: {
            type: "gauge",
            rows: []
        },
        transition: {
            duration: 100
        }
    });

    return oChart;
}

/****************************
 * 레이더 차트
 * (현재 데이터만을 표시함)
 ****************************/
function bb_radarInit(sEId){
    var oChartRadar = bb.generate({
        bindto: sEId,
        data: {
            type: "scatter",
            rows: []
        },
        transition: {
            duration: 100
        }
    });

    return oChartRadar;
}

/****************************
 * 현재 데이터 불러오기
 ****************************/
function bb_CurrentLoadData(oChart, node_ids){
    var row = [[]]; //billboard.js 차트의 데이터
    var delay = 2000; //차트 새로고침 타이머 설정

    var oPost = {
        "node_id"   : node_ids,
		"select_only_number" : true
    };
    $.ajax({
        "url"      : "/api/selectDataByCurrentTime?" + serializeParam(oPost, "utf-8"),
        "type"     : "GET",
        "dataType" : "json",
        "success"  : function(jData) {
            // console.log(jData);
            if(jData["status"] == "success") {
                var aNodeList = jData["node"];
                var aDataList = jData["data"];

                //범례 세팅
                if(aNodeList.length > 0) { //노드 데이터가 존재하는 경우의 처리
                    var arrData = new Array(aNodeList.length).fill(0);
                    for(var i=0; i<aNodeList.length; i++) {
                        var sNodeID = aNodeList[i];

                        row[0].push(sNodeID);
                    };

                    //실제로 출력된 데이터값만 배열에 다시 세팅
                    for(var i=0; i<aDataList.length; i++) {
                        var nIndex = row[0].indexOf(aDataList[i]["node_id"]);
						if(isNumeric(aDataList[i]["node_value"])){
							arrData[nIndex] = Number(aDataList[i]["node_value"]);
						}
						// else{
						// 	arrData[nIndex] = 1;
						// }
                    }

                    row.push(arrData);
                }

                oChart.load({
                    rows: row,
                    done: function() { // load가 완료된 경우
                        setTimeout(bb_CurrentLoadData, delay, oChart, node_ids);
                    }
                });
            }
        },
        "error"    : function(oXhr) {
            console.dir(oXhr);
        }
    });
}

/****************************
 * 현재 데이터를 테이블 형식으로 가져오기
 ****************************/
function bb_CurrentLoadTableData(sEId, node_ids){
    var row = [[]]; //billboard.js 차트의 데이터
    var delay = 1000; //차트 새로고침 타이머 설정

    var oPost = {
        "node_id"   : node_ids
    };
    $.ajax({
        "url"      : "/api/selectDataByCurrentTime?" + serializeParam(oPost, "utf-8"),
        "type"     : "GET",
        "dataType" : "json",
        "success"  : function(jData) {
            // console.log(jData);
            if(jData["status"] == "success") {
                var aNodeList = jData["node"];
                var aDataList = jData["data"];

                var sHTML = "";
                sHTML += `<div class='dvTable1'>`;
                sHTML += `    <table summary="Node name, VALUE, Time" class="normal_table">`;
                sHTML += `        <colgroup>`;
                sHTML += `            <col style="width:20%;" />`;
                sHTML += `            <col style="width:40%;" />`;
                sHTML += `            <col style="width:40%;" />`;
                sHTML += `        </colgroup>`;
                sHTML += `        <thead>`;
                sHTML += `            <tr>`;
                sHTML += `                <th>Node ID</th>`;
                sHTML += `                <th>VALUE</th>`;
                sHTML += `                <th>Time</th>`;
                sHTML += `            </tr>`;
                sHTML += `        </thead>`;
                sHTML += `    </table>`;
                sHTML += `</div>`;
                sHTML += `<div class='dvTable2'>`;
				sHTML += `    <table class='write_table'>`;
                sHTML += `        <colgroup>`;
                sHTML += `            <col style="width:20%;" />`;
                sHTML += `            <col style="width:40%;" />`;
                sHTML += `            <col style="width:40%;" />`;
                sHTML += `        </colgroup>`;
                sHTML += `        <tbody>`;

				if(aNodeList.length > 0) { //노드 데이터가 존재하는 경우의 처리
                    //실제로 출력된 데이터값만 배열에 다시 세팅
                    for(var i=0; i<aDataList.length; i++) {
                        sHTML += "<tr>";
                        sHTML += "<td align='center'>" + aDataList[i]["node_id"] + "</td>";
                        sHTML += "<td align='center'>" + aDataList[i]["node_value"] + "</td>";
                        sHTML += "<td align='center'>" + aDataList[i]["node_time"] + "</td>";
                        sHTML += "</tr>";
                    }
                }
                else{
                    //데이터가 없을 경우 표시
                    sHTML += "<tr><td colspan='3'>No data found.</td></tr>";
                }

                sHTML += `        </tbody>`;
				sHTML += `    </table>`;
				sHTML += `</div>`;

				table_element = $(sEId).find(".dvTable2")[0];
				scrollTop = (table_element == undefined)?0:table_element.scrollTop;
                $(sEId).html(sHTML);
				$(sEId).find(".dvTable2")[0].scrollTop = scrollTop

				setTimeout(bb_CurrentLoadTableData, delay, sEId, node_ids);
            }
        },
        "error"    : function(oXhr) {
            console.dir(oXhr);
        }
    });
}

/****************************
 * 현재 데이터를 테이블 형식으로 가져오기
 ****************************/
function bb_sendControlData(node_name, node_value){
    var oPost = {
        "node_id"    : node_name,
		"node_value" : node_value
    };
    $.ajax({
        "url"      : "/api/appendData?" + serializeParam(oPost, "utf-8"),
        "type"     : "GET",
        "dataType" : "json",
        "error"    : function(oXhr) {
            console.dir(oXhr);
        }
    });
}

function bb_controlInit(sEId){
    var oControl = $(sEId)[0];

	var sHTML = "";
	sHTML += `<div class='dvTable1'>`;
	sHTML += `    <table summary="Node Name, VALUE, CONTROL" class="normal_table">`;
	sHTML += `        <colgroup>`;
	sHTML += `            <col style="width:40%;" />`;
	sHTML += `            <col style="width:40%;" />`;
	sHTML += `            <col style="width:20%;" />`;
	sHTML += `        </colgroup>`;
	sHTML += `        <thead>`;
	sHTML += `            <tr>`;
	sHTML += `                <th>Node ID</th>`;
	sHTML += `                <th>VALUE</th>`;
	sHTML += `                <th>Control</th>`;
	sHTML += `            </tr>`;
	sHTML += `        </thead>`;
	sHTML += `    </table>`;
	sHTML += `</div>`;
	sHTML += `<div class='dvTable2'>`;
	sHTML += `    <table class='write_table'>`;
	sHTML += `        <colgroup>`;
	sHTML += `            <col style="width:40%;" />`;
	sHTML += `            <col style="width:40%;" />`;
	sHTML += `            <col style="width:20%;" />`;
	sHTML += `        </colgroup>`;
	sHTML += `        <tbody>`;

	for(let i of Array(6)){
		sHTML += `<tr>`;
		sHTML += `<td align='center'><input type="text" name="name" class="tbControl" value="" placeholder="input control node mame"></td>`;
		sHTML += `<td align='center'><input type="text" name="value" class="tbControl" value="" placeholder="input node value"></td>`;
		sHTML += `<td align='center'><input type="button" class="btnControl" value="Send" onclick="`;
		sHTML += `    bb_sendControlData(`;
		sHTML += `        this.parentNode.parentNode.querySelector('[name=name]').value,`;
		sHTML += `        this.parentNode.parentNode.querySelector('[name=value]').value`;
		sHTML += `    )"`;
		sHTML += `</td>`;
		sHTML += `</tr>`;
	}

	oControl.innerHTML = sHTML;

    return oControl;
}
