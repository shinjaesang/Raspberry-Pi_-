# 웹 프레임워크
from flask import Flask

# 웹서버 객체 생성
app = Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True # 옵션

# http://(홈페이지 혹은 IP 주소):5000/ 주소로 접속하였을 때 호출
@app.route("/")
def base():
    return "<h1>Hello World!</h1>"

if __name__ == '__main__':
    # try-except 는 파이썬의 예외처리 구문으로 
    # 키보드로 Ctrl + C를 누르거나 에러가 발생했을 시 프로그램이 종료 된다.
    try:
        app.run(host="0.0.0.0",debug=True)

    # Ctrl + C로 프로그램 종료 시
    except KeyboardInterrupt:
        print("Shutting down..")
    # 에러가 발생했을 시
    except Exception as e:
        print(e)
    finally:
        pass
