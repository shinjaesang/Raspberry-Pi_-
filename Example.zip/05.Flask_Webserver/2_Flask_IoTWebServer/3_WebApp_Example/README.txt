/*******************************
 *  웹서버 예제 
*******************************/

 * 본 예제는 웹서버를 구축하고, 웹 API를 단계별로 구성해보는 예제입니다.
 * Python 기반이며 각각의 예제는 Terminal 과 Thonny Python IDE에서 수행 가능합니다.

 * 웹서버 실행 방법 (Windows PC 기준)
    - 윈도우 키를 누르고, CMD를 입력하여 명령프롬프트 창을 실행한다.
    - 현재 예제가 들어있는 디렉토리로 접근한다.
    - 다음 명령어로 예제 실행에 필요한 파이썬 패키지를 설치해준다.
    - python -m pip install requirements.txt
    - 실행하고자 하는 예제 폴더로 접근한다.
    - 해당 디렉토리에서 다음의 명령을 입력한다.
    - python app.py

 1. 웹서버 기초 예제
    - 1-1. Create_Webserver : 웹서버 구축하기
       => http://(홈페이지 혹은 IP 주소):5000/ 주소로 접속하여 페이지가 정상적으로 나오는 지 확인
    - 1-2. Web_API_Example : 클라이언트로부터 GET 혹은 POST 방식으로 받은 요청을 처리하기
       => 인터넷 브라우저에서 http://(IP 주소):5000/api/appendData?node_id=tempSensor&node_value=36 입력 후 결과 확인
    - 1-3. Index_Page_Example : 기본 페이지(index.html) 작성 방법에 대한 예제
       => 인터넷 브라우저에서 http://(IP 주소):5000 입력 후 결과 확인

 2. 웹서버 + DB + 센서 디바이스 연동 예제
    * 동작 확인을 위해, 각 예제별 웹서버를 먼저 실행하고, 라즈베리파이 장비에서 "2. Communication/2-1. Send_Node_Data.py" 예제를 실행한다. (센서 데이터를 서버에 저장해야 하기 때문)
    - 2-1. DB_Select_Append_API_Example : 데이터베이스로부터 센서 데이터를 추가(Append) 및 조회(Select) 할 수 있는 API를 만드는 예제
      => 브라우저에서 http://127.0.0.1:5000/api/selectData?node_id=CDS 페이지로 접속하여 센서 데이터 조회
    - 2-2. DB_Select_By_CurrentTime_API_Example : 데이터베이스로부터 가장 최근에 들어온 센서 데이터를 조회(Select) 할 수 있는 API를 만드는 예제
      => 브라우저에서 http://127.0.0.1:5000/api/selectDataByCurrentTime?node_id=CDS 페이지로 접속하여 센서 데이터 조회
    - 2-3. DB_Select_By_Timestamp_API_Example : 데이터베이스로부터 최근 10초 이내 센서 데이터를 1초 단위로 조회(Select) 할 수 있는 API를 만드는 예제
      => 브라우저에서 http://127.0.0.1:5000/api/selectDataByTimestamp?node_id=CDS 페이지로 접속하여 센서 데이터 조회

 3. 대시보드 예제
    - 3-1. Basic_Dashboard : 기본 대시보드 예제 (index.html을 수정하여 직접 차트를 구성, 3-2부터는 이 과정 없이 chart_functions.js 파일을 불러와서 사용)
    - 3-2. Sensor_Monitoring : 센서값을 받아와서 실시간으로 차트를 통해 모니터링 하는 예제
       => 라즈베리파이 장비에서는 "2. Communication/2-1. Send_Node_Data.py" 예제를 실행
    - 3-3. Control_Data : 대시보드에서 버튼 클릭 시 라즈베리파이 장비의 LED를 ON/OFF 하는 예제
       => 라즈베리파이 장비에서는 "2. Communication/2-3. Receive_Control_Data_2.py" 예제를 실행
    - 3-4. All_Dashboard : 최종 예제 (대시보드 확장)

 
