# 웹 프레임워크
from flask import Flask
# Flask에 포함되어있는 기능
from flask import request, jsonify

# 웹서버 객체 생성
app = Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True # 옵션

# http://(홈페이지 혹은 IP 주소):5000/ 주소로 접속하였을 때 호출
@app.route("/")
def base():
    return "<h1>Hello World!</h1>"

# http://(홈페이지 혹은 IP 주소):5000/api/appendData 주소로 접속하였을 때 호출
# ex) http://127.0.0.1:5000/api/appendData?node_id=tempSensor&node_value=36
# 파라미터값)
#   node_id : 센서 ID
#   node_value : 센서값
#   node_time : 센서값 발생 날짜/시간 (기본값은 현재 시간이므로 값을 주지 않아도 무관)
@app.route("/api/appendData", methods=['GET', 'POST'])
def appendData():
    # GET 방식으로 요청을 받았을 때 처리
    if(request.method == "GET"):
        node_id = request.args.get("node_id")
        node_value = request.args.get("node_value")
        node_time = request.args.get("node_time")
    # POST 방식으로 요청을 받았을 때 처리
    elif(request.method == "POST"):
        node_id = request.form.get("node_id")
        node_value = request.form.get("node_value")
        node_time = request.form.get("node_time")

    # 누락된 값이 있을 경우 예외처리 (node_time은 데이터 발생 시간이므로 제외)
    if(node_id is None or node_value is None):
        response_data = jsonify({
            "status" : "failed",
            "message": "data send failed (node_id : {0}, node_value : {1})".format(node_id, node_value)
        })
    else:
        response_data = jsonify({
            "status" : "success",
            "message": "data send success (node_id : {0}, node_value : {1})".format(node_id, node_value)
        })

    return response_data

if __name__ == '__main__':
    # try-except 는 파이썬의 예외처리 구문으로 
    # 키보드로 Ctrl + C를 누르거나 에러가 발생했을 시 프로그램이 종료 된다.
    try:
        app.run(host="0.0.0.0",debug=True)

    # Ctrl + C로 프로그램 종료 시
    except KeyboardInterrupt:
        print("Shutting down..")
    # 에러가 발생했을 시
    except Exception as e:
        print(e)
    finally:
        pass
