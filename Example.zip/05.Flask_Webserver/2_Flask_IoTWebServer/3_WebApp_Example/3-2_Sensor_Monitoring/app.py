import os, sys

# 웹 프레임워크
from flask import Flask
# Flask 웹서버를 상용화할 때 사용하는 모듈
import waitress
# Flask에 포함되어있는 기능
from flask import request, jsonify, render_template

# 웹서버 객체 생성
app = Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True # 옵션


# 파이썬 스크립트가 실행 중인 현재 경로 가져오기
cur_script_dir_path = os.path.dirname(os.path.realpath(sys.argv[0]))

# DB 관련 클래스
from db_classes import SensorDB
# DB 로드 (현재 예제가 들어있는 폴더 내 database/data.db 경로로 저장됨)
sensorDB = SensorDB(os.path.join(cur_script_dir_path, "database", "data.db"))


# http://(홈페이지 혹은 IP 주소):5000/ 주소로 접속하였을 때 호출
# 대시보드가 보여지는 메인 페이지
@app.route("/")
def base():
    return render_template("index.html")

# http://(홈페이지 혹은 IP 주소):5000/api/appendData 주소로 접속하였을 때 호출
# INSERT 쿼리로 센서 데이터를 추가할 수 있음
# ex) http://127.0.0.1:5000/api/appendData?node_id=tempSensor&node_type=0&node_value=36&node_time=2021-09-28 18:00:38
# 파라미터값)
#   node_id : 센서 ID
#   node_value : 센서값
#   node_time : 센서값 발생 날짜/시간 (기본값은 현재 시간이므로 값을 주지 않아도 무관)
@app.route("/api/appendData", methods=['GET', 'POST'])
def appendData():
    if(request.method == "GET"):
        node_id = request.args.get("node_id")
        node_value = request.args.get("node_value")
        node_time = request.args.get("node_time")
    elif(request.method == "POST"):
        node_id = request.form.get("node_id")
        node_value = request.form.get("node_value")
        node_time = request.form.get("node_time")

    # 누락된 값이 있을 경우 예외처리 (node_time은 데이터 발생 시간이므로 제외)
    if(node_id is None or node_value is None):
        response_data = jsonify({
            "status" : "failed",
            "message": "data send failed (node_id : {0}, node_value : {1})".format(node_id, node_value)
        })
    else:
        # DB에 데이터 append
        sensorDB.insert(
            node_id,
            node_value,
            node_time
        )

        response_data = jsonify({
            "status" : "success",
            "message": "data send success (node_id : {0}, node_value : {1})".format(node_id, node_value)
        })

    return response_data

# http://(홈페이지 혹은 IP 주소):5000/api/selectData 주소로 접속하였을 때 호출
# SELECT 쿼리로 센서 데이터를 조회할 수 있음
# ex) http://127.0.0.1:5000/api/selectData <= 다른 조건 없이 모든 센서에 대한 데이터를 조회하는 경우
# ex) http://127.0.0.1:5000/api/selectData?node_id=tempSensor <= 다른 조건 없이 특정 센서에 대한 전체 데이터만 조회하는 경우
# ex) http://127.0.0.1:5000/api/selectData?node_id=tempSensor&node_time_start=2021-09-28 18:00:00&node_time_end=2021-09-28 20:00:00 <= 특정 센서, 특정 기간 동안에 수집된 데이터만 조회하는 경우
# 파라미터값)
#   node_id : 센서 ID
#   node_value_start : 검색할 센서값 범위의 최소값
#   node_value_end : 검색할 센서값 범위의 최대값
#   node_time_start : 검색할 센서값의 최소 발생 날짜/시간
#   node_time_end : 검색할 센서값의 최대 발생 날짜/시간
#   select_only_number : 숫자형 데이터만 검색하려면 1, 문자형 데이터만 검색하려면 0
@app.route("/api/selectData", methods=['GET', 'POST'])
def selectData():
    if(request.method == "GET"):
        node_id = request.args.get("node_id")
        node_value_start = request.args.get("node_value_start")
        node_value_end = request.args.get("node_value_end")
        node_time_start = request.args.get("node_time_start")
        node_time_end = request.args.get("node_time_end")
        select_only_number = request.args.get("select_only_number")
    elif(request.method == "POST"):
        node_id = request.form.get("node_id")
        node_value_start = request.form.get("node_value_start")
        node_value_end = request.form.get("node_value_end")
        node_time_start = request.form.get("node_time_start")
        node_time_end = request.form.get("node_time_end")
        select_only_number = request.form.get("select_only_number")

    # DB로부터 데이터 조회
    sensor_data = sensorDB.select(
        node_id,
        node_value_start,
        node_value_end,
        node_time_start,
        node_time_end,
        select_only_number
    )

    response_data = jsonify({
        "status": "success",
        "message": "data select success",
        "data": sensor_data
    })

    return response_data

# http://(홈페이지 혹은 IP 주소):5000/api/selectDataByCurrentTime 주소로 접속하였을 때 호출
# 각 센서별로 가장 최근에 발생한 데이터 1개만을 가져온다.
# 대시보드에서 실시간으로 현재 데이터를 조회할 때 사용함 (원형 차트, 도넛 차트, 테이블 등)
# 파라미터값)
#   node_id : 센서 ID
#   node_value_start : 검색할 센서값 범위의 최소값
#   node_value_end : 검색할 센서값 범위의 최대값
#   select_only_number : 숫자형 데이터만 검색하려면 1, 문자형 데이터만 검색하려면 0
@app.route("/api/selectDataByCurrentTime", methods=['GET', 'POST'])
def selectDataByCurrentTime():
    if(request.method == "GET"):
        node_id = request.args.get("node_id")
        node_value_start = request.args.get("node_value_start")
        node_value_end = request.args.get("node_value_end")
        select_only_number = request.args.get("select_only_number")
    elif(request.method == "POST"):
        node_id = request.form.get("node_id")
        node_value_start = request.form.get("node_value_start")
        node_value_end = request.form.get("node_value_end")
        select_only_number = request.form.get("select_only_number")

    node_id = None if node_id == "undefined" else node_id
        
    sensor_data = sensorDB.select_by_current_time(
        node_id,
        node_value_start,
        node_value_end,
        select_only_number
    )

    response_data = jsonify({
        "status": "success",
        "message": "data select success",
        "data": sensor_data["datalist"],
        "node": sensor_data["nodelist"]
    })

    return response_data

# http://(홈페이지 혹은 IP 주소):5000/api/selectDataByTimestamp 주소로 접속하였을 때 호출
# 각 센서별로 지난 몇 일간의 데이터를 특정 초 단위로 나눠 가져온다.
# 대시보드에서 실시간으로 초 단위의 데이터를 조회할 때 사용함 (라인 차트 등)
# 파라미터값)
#   node_id : 센서 ID
#   node_value_start : 검색할 센서값 범위의 최소값
#   node_value_end : 검색할 센서값 범위의 최대값
#   nDivide : 가져올 시계열 데이터를 몇 초 단위로 나눌 지
#   nLimit : 지난 몇 초간 데이터를 가져올 것인지
#   select_only_number : 숫자형 데이터만 검색하려면 1, 문자형 데이터만 검색하려면 0
@app.route("/api/selectDataByTimestamp", methods=['GET', 'POST'])
def selectDataByTimestamp():
    if(request.method == "GET"):
        node_id = request.args.get("node_id")
        node_value_start = request.args.get("node_value_start")
        node_value_end = request.args.get("node_value_end")
        nDivide = request.args.get("divide")
        nLimit = request.args.get("limit")
        select_only_number = request.args.get("select_only_number")
    elif(request.method == "POST"):
        node_id = request.form.get("node_id")
        node_value_start = request.form.get("node_value_start")
        node_value_end = request.form.get("node_value_end")
        nDivide = request.form.get("divide")
        nLimit = request.form.get("limit")
        select_only_number = request.form.get("select_only_number")

    node_id = None if node_id == "undefined" else node_id
    nDivide = 1 if nDivide is None else nDivide
    nLimit = 10 if nLimit is None else nLimit

    sensor_data = sensorDB.select_by_timestamp(
        node_id,
        node_value_start,
        node_value_end,
        select_only_number,
        nDivide,
        nLimit
    )

    response_data = jsonify({
        "status": "success",
        "message": "data select success",
        "data": sensor_data["datalist"],
        "node": sensor_data["nodelist"],
        "time": sensor_data["time"]
    })

    return response_data


if __name__ == '__main__':
    # try-except 는 파이썬의 예외처리 구문으로 
    # 키보드로 Ctrl + C를 누르거나 에러가 발생했을 시 프로그램이 종료 된다.
    try:        
        app.run(host="0.0.0.0",debug=True)

    # Ctrl + C로 프로그램 종료 시
    except KeyboardInterrupt:
        print("Shutting down..")
    # 에러가 발생했을 시
    except Exception as e:
        print(e)
    finally:
        pass
