/*******************************
 *  HTTP 통신 예제 
*******************************/

 * 본 예제는 웹서버와 HTTP 통신을 하는 방법에 대해 다룹니다.
 * GET과 POST 요청을 통해 웹서버에 값을 보내거나 받아올 수 있고,
 * 최종적으로 센서 디바이스와 연동하여 센서값을 서버로 보내거나 LED와 같은 모듈들을 제어할 수 있습니다.
 * Python 기반이며 각각의 예제는 Terminal 과 Thonny Python IDE에서 수행 가능합니다.
 * HTTP 통신을 하려면 웹서버가 있어야하기 때문에 PC에서 웹서버 데모를 실행해줍니다.

 * 웹서버 실행 방법 (PC)
    - 윈도우 키를 누르고, CMD를 입력하여 명령프롬프트 창을 실행한다.
    - 실행하고자 하는 디렉토리로 접근한다. (본 예제 폴더 내 Web Server Sample 폴더)
    - 다음 명령어로 예제 실행에 필요한 파이썬 패키지를 설치해준다.
    - python -m pip install requirements.txt
    - 해당 디렉토리에서 다음의 명령을 입력한다.
    - python app.py --port=8000

 1. HTTP 통신 기초 예제
    - 1-1. Request_GET_Example_1.py : GET 프로토콜 사용 방법 1
    - 1-2. Request_GET_Example_2.py : GET 프로토콜 사용 방법 2
    - 1-3. Request_GET_Example_3.py : 잘못된 주소로 HTTP 요청 시 응답 코드 확인
    - 1-4. Request_POST_Example.py  : POST 프로토콜 사용 방법

 2. HTTP 통신 & 센서 디바이스 응용 예제
    - 2-1. Send_Node_Data.py : 조도 센서 값을 서버로 보내는 예제
    - 2-2. Receive_Control_Data1.py : 서버로부터 제어 데이터를 받아와서 데이터 형식을 확인하는 예제
    - 2-3. Receive_Control_Data2.py : 받아온 제어 데이터를 가지고 실제로 LED를 제어해보는 예제
