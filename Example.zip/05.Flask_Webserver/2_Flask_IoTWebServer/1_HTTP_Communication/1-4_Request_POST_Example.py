import requests

URL = 'http://127.0.0.1:5000/api/appendData'

data = {
    "node_id":"tempSensor",
    "node_value":"36"
}

response = requests.post(URL, data=data)

print("웹서버 POST 요청 결과 (주소 : {0})".format(URL))
print("상태 코드 : {0}".format(response.status_code))
