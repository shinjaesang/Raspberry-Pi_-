# HTTP 요청을 위한 모듈 requests
import requests

# 지연시간 제어를 위해 time 모듈을 사용한다.
import time

# 복잡한 데이터 형식을 보기 좋게 출력해주는 모듈
import pprint

# HTTP 요청을 전달할 대상 웹페이지 주소
URL = 'http://127.0.0.1:5000/api/selectData'

# 노드 식별자
node_id = "LED"

# try-except 는 파이썬의 예외처리 구문으로 
# 키보드로 Ctrl + C를 누를시 프로그램이 종료 된다.
try:
    while(True):
        # 수신 요청
        response = requests.get(URL, params={
            "node_id": node_id,
             # 선택 사항 (현재 시간의 데이터 값만 가져오도록 한다.)
            "node_time_start": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time() - 1))
        })

        # HTTP 요청이 정상적으로 처리된 경우
        if(response.status_code == 200):
            # 응답된 데이터는 JSON 형태이기 때문에 json() 함수를 통해 사전(dictionary) 타입으로 데이터를 얻을 수 있다.
            json_data = response.json()
            # 응답된 데이터를 출력하여 JSON 데이터 구조를 확인
            pprint.pprint(json_data)

        # 0.5초 대기
        time.sleep(1)
        
# 종료 등의 키보드 인터럽트 발생시 처리 동작
except KeyboardInterrupt:
    pass
