# HTTP 요청을 위한 모듈 requests
import requests

# 지연시간 제어를 위해 time 모듈을 사용한다.
import time

# 복잡한 데이터 형식을 보기 좋게 출력해주는 모듈
import pprint

# LED 제어를 위한 모듈
from pcf8574 import PCF8574
i2c_port_num = 1 # i2c 통신 번호
pcf_address = 0x20 # i2c 모듈 주소
pcf = PCF8574(i2c_port_num, pcf_address) # PCF8574 객체 생성

# HTTP 요청을 전달할 대상 웹페이지 주소
URL = 'http://127.0.0.1:5000/api/selectData'

# 노드 식별자
node_id = "LED"

# try-except 는 파이썬의 예외처리 구문으로 
# 키보드로 Ctrl + C를 누를시 프로그램이 종료 된다.
try:
    while(True):
        # 수신 요청
        response = requests.get(URL, params={
            "node_id": node_id,
             # 선택 사항 (현재 시간의 데이터 값만 가져오도록 한다.)
            "node_time_start": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time() - 1))
        })

        # HTTP 요청이 정상적으로 처리된 경우
        if(response.status_code == 200):
            # 응답된 데이터는 JSON 형태이기 때문에 json() 함수를 통해 사전(dictionary) 타입으로 데이터를 얻을 수 있다.
            json_data = response.json()
            # 응답된 데이터를 출력하여 JSON 데이터 구조를 확인
            pprint.pprint(json_data)

            # JSON 데이터를 파싱
            control_data = json_data["data"]

            # 제어 데이터가 있는 지 확인
            if(len(control_data) > 0):
                # 제어 데이터가 여러 개일 수 있기 때문에 for문으로 순차 제어
                for i in range(len(control_data)):
                    node_id = control_data[i]["node_id"]
                    node_value = control_data[i]["node_value"]

                    # 본 예제는 LED를 제어하는 예제이기 때문에 제어 데이터의 node_id가 LED인 경우에만 아래 과정을 수행하도록 함
                    if(node_id == "LED"):
                        # node_value가 OFF면 LED를 끄고, ON이면 LED를 킨다.
                        if (node_value == "OFF"):
                            for j in range(0, 8):
                                pcf.port[j] = False
                        elif(node_value == "ON"):
                            for j in range(0, 8):
                                pcf.port[j] = True

        # 0.5초 대기
        time.sleep(0.5)
        
# 종료 등의 키보드 인터럽트 발생시 처리 동작
except KeyboardInterrupt:
    pass
