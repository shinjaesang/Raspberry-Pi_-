# HTTP 요청을 위한 모듈 requests
import requests

# 지연시간 제어를 위해 time 모듈을 사용한다.
import time
# I2C 사용을 위한 모듈 smbus
import smbus

# HTTP 요청을 전달할 대상 웹페이지 주소
URL = 'http://127.0.0.1:5000/api/appendData'

bus = smbus.SMBus(1)
i2c_address = 0x48
Cds_channel = 0x01

# 노드 식별자
node_id = "CDS"

# try-except 는 파이썬의 예외처리 구문으로 
# 키보드로 Ctrl + C를 누를시 프로그램이 종료 된다.
try:
    while(1) :
        # i2c의 주소와 센서의 채널을 설정한다
        bus.write_byte(i2c_address, Cds_channel)
        time.sleep(0.1)

        # I2C로 부터 센서 값을 읽어온다
        CdsValue = bus.read_byte(i2c_address)
        CdsValue = CdsValue * 100 / 255

        # 소수점 둘 째 자리까지만 표시한다
        CdsValue = round(CdsValue,2)

        print("CdS : " + str(CdsValue) + " %")

        # CDS 값을 서버로 송신한다.
        response = requests.get(URL, params={
            "node_id": node_id,
            "node_value": CdsValue
        })

        # 요청 결과와 서버로부터 수신 받은 데이터를 출력한다.
        print("상태 코드 : {0}, 수신 받은 데이터 : {1}".format(response.status_code, response.text))

        # 0.5초 대기
        time.sleep(0.5)
        
# 종료 등의 키보드 인터럽트 발생시 처리 동작
except KeyboardInterrupt:
    pass
