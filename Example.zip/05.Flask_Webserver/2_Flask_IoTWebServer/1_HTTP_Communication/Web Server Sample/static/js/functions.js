/********************************
    트림함수
********************************/
String.prototype.trim = function() 
{
    return this.replace(/(^\s*)|(\s*$)/gi, '');
}

String.prototype.toDateFormat = function(a)
{
    if(this.length < 6)
        return this;
        
    if(a == undefined)
        a = "/";
        
    var sReturn = ""
    sReturn += this.substr(0, 4) + a;
    sReturn += this.substr(4, 2) + a;
    sReturn += this.substr(6, 2)
    return sReturn;
}
String.prototype.toTimeFormat = function(a)
{
    if(this.length < 6)
        return this;

    if(a == undefined)
        a = ":";

    var sReturn = ""
    return this.substr(0, 2) + a + this.substr(2, 2) + a + this.substr(4, 2);;
}

String.prototype.toRegno = function()
{
    var sReturn = ""
    sReturn += this.substr(0, 3) + "-";
    sReturn += this.substr(3, 2) + "-";
    sReturn += this.substr(5, 5)
    return sReturn;
}

String.prototype.toZip = function()
{
    return this.substr(0, 3) + "-" + this.substr(3, 3);
}
String.prototype.toCorpno = function()
{
    return this.substr(0,6) + "-" + this.substr(6, 7);
}
String.prototype.toCost = function()
{
    return this.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}



/********************************
    문자,숫자,특문 갯수체크
---------------------------------
.number : 숫자갯수
.string : 문자갯수
.etc    : 특문갯수
********************************/
String.prototype.getInfo = function() 
{
    var nTmp;
    var nNumber = 0
    var nString = 0
    var nEtc = 0;
    for(var i=0; i<this.length; i++)
    {
        nTmp = parseInt(this.charCodeAt(i));
        if((nTmp>=48) && (nTmp<=57))
        {//숫자
            nNumber++;
        }
        else if(((nTmp>=97)&&(nTmp<=122)) || ((nTmp>=65)&&(nTmp<=90)))
        {//영문자
            nString++;
        }
        else
        {//특수기호
            nEtc++;
        }
    }
    return { "number" : nNumber,
             "string" : nString,
             "etc"    : nEtc};
}





/********************************
    파일확장자 가져오기
********************************/
function getFileExt(strFileName)
{
    var arrTmp;
    var strFileExt = "";
        
    if(strFileName.indexOf(".") > -1)
    {
        arrTmp = strFileName.split(".", -1);
        strFileExt = arrTmp[arrTmp.length - 1];
    }
    
    return strFileExt;
}


/********************************
    쿠키설정
********************************/
function setCookie(name, value, expiredays){ 
        var todayDate = new Date(); 
        todayDate.setDate(todayDate.getDate() + expiredays); 
        document.cookie = name + "=" + escape(value) + "; path=/; expires=" + todayDate.toGMTString() + ";" 
} 

/********************************
    쿠키가져오기
********************************/
function cookieVal(cookieName){ 
        var thisCookie = document.cookie.split("; "); 
        for(i=0; i<thisCookie.length; i++){ 
                if(cookieName == thisCookie[i].split("=")[0]){ 
                        return thisCookie[i].split("=")[1]; 
                } 
        } 
        return ""; 
}

/********************************
    브라우져 종류가져오기
---------------------------------
********************************/
function getBrowserType()
{
    var struserAgent = navigator.userAgent.toLowerCase();
    
    if(struserAgent.indexOf("msie 9.0")>-1)//ie9.0
    {
        return "ie9";
    }
    if(struserAgent.indexOf("msie 8.0")>-1)//ie8.0
    {
        return "ie8";
    }
    else if(struserAgent.indexOf("msie 7.0")>-1)//ie7.0
    {
        if(struserAgent.indexOf("trident/4.0")>-1)//ie 8.0에서 7.0으로 호환성보기
            return "ie8_7";
        else
            return "ie7";
    }
    else if(struserAgent.indexOf("msie 6.0")>-1)//ie 6.0
    {
        return "ie6";
    }
    else if(struserAgent.indexOf("firefox")>-1)//파이어폭스
    {
        return "firefox";
    }
    if(struserAgent.indexOf("safari")>-1)
    {
        if(struserAgent.indexOf("chrome")>-1)
            return "chrome";
        else
            return "safari";
    }
    else if(struserAgent.indexOf("opera")>-1)
        return "opera";
    
    return "etc";

}



/**********************************
    부족한자릿수만큼 0으로채우기
----------------------------------
1. 검렬할문자
2. 자릿수
3. 0을 채울 방향(안넣으면 좌측으로넣는다)
 l : 좌측(기본값)
 r : 우측
**********************************/
function fillZeroNum(strInput, nSize, sDirection)
{
    var strTmp = String(strInput);
    var strAdd = "";
    var returnValue = "";
    if(strTmp.length < nSize)
    {
        for(i=0; i<nSize - strTmp.length; i++)
        {
            strAdd += "0";
        }
    }
    
    if(sDirection == undefined)
        sDirection = "l";

    switch(sDirection.toLowerCase())
    {
        case "l"://좌측으로추가
            returnValue = strAdd + strTmp;
            break;
        default: //우측으로추가
            returnValue = strTmp + strAdd;
            break;
    }
    
    return returnValue;
}

/**********************************
    SELECT 객체생성
----------------------------------
1. 선택사항명(array)
2. 선택사항값(array)
3. 선택된값
4. 기본으로들어갈값(value="")
**********************************/
function createSelectObject(arrName, arrValue, selectedValue, defaultString)
{
    var oSelect;
    var i;
    
    oSelect = document.createElement("SELECT");
    if(defaultString != undefined) {
        var oOptionBase = document.createElement("OPTION");
        oOptionBase.value = "";
        oOptionBase.appendChild(document.createTextNode(defaultString));
        oSelect.appendChild(oOptionBase);
    }
    
    
    for(i=0; i<arrName.length; i++) {
        var oOption = document.createElement("OPTION");
        oOption.value = arrValue[i];
        if(String(selectedValue) == String(arrValue[i])) {
            oOption.selected = true;
        }
        oOption.appendChild(document.createTextNode(arrName[i]));
        oSelect.appendChild(oOption);
    }
    return oSelect;
}

/**********************************
    Ajax 객체생후 리턴
----------------------------------
**********************************/
function createXMLHttpRequest()
{
    var oXml;
    if(window.ActiveXObject != undefined)
    {
        oXml = new ActiveXObject("Microsoft.XMLHTTP");
    }    
    else if(window.XMLHttpRequest != undefined)
    {
        oXml = new XMLHttpRequest();
    }
    return oXml;
}


/**********************************
    이벤트리스너 추가
    (attachEvent, addEventListener함수 둘다모두 지원하지않으면 이벤트등록실패됨)
----------------------------------
1. 이벤트 추가할 객체
2. 이벤트명(onload, onclick 등등)
3. 이벤트발생시 작동될 함수
**********************************/
function appendEvent(objSrc, strEventName, objMethod)
{
    var strEvent = strEventName.toLowerCase();
    var returnValue = true;;
    
    if(strEvent.substr(0,2) == "on")
        strEvent = strEvent.substr(2, strEvent.length);
        
        
    if(objSrc.attachEvent != undefined)//IE일경우
        objSrc.attachEvent("on" + strEvent, objMethod);
    else if(objSrc.addEventListener != undefined)//addEventListener 지원브라우져
        objSrc.addEventListener(strEvent, objMethod, false);
    else
        returnValue = false;
    
    return returnValue;
}



/**********************************
    스타일시트 제어
----------------------------------
1. 변경할 스타일명(. or # 붙여야함)
2. 속성명
3. 값
**********************************/
function ModifyStyle(sSelector, sProperty, strValue)
{
    var oStyleSheets = document.styleSheets;
    var bChanged    = false;
    
    if(oStyleSheets.length <= 0)
    {
        var newStyle = document.createElement("STYLE");
        newStyle.type = "text/css";
        document.getElementByTagName("HEAD")[0].appendChild(newStyle);
    }
    
    if(sProperty == undefined)
    {
        sProperty = "cssText";
    }
    
    for(var i = 0; i < oStyleSheets.length; i++)
    {
        var oRules = (oStyleSheets[i].cssRules != undefined ? oStyleSheets[i].cssRules : oStyleSheets[i].rules);

        for(var j = 0; j < oRules.length; j++)
        {
            if(oRules[j].selectorText.toLowerCase() == sSelector.toLowerCase())
            {
                oRules[j].style[sProperty] = strValue;
            }
            
            bChanged = true;
        }
    }
    //변경되지 않았을경우에는
    //룰을 추가한다.
    if(bChanged == false)
    {
        var oStyle = document.styleSheets[0];
        var sCssText;
        if(sProperty == "cssText")
            sCssText = strValue;
        else
            sCssText = sProperty + ":" + strValue;
        
        if(oStyle.insertRule != undefined)
        {
            oStyle.insertRule(sSelector + "{"+cssText+"}", oStyle.cssRules.length);
        }
        else if(oStyle.addRule != undefined)
        {
            oStyle.addRule(sSelector, cssText);
        }
        else
            return false;
    }
}


/**********************************
    URL 쿼리스트링전체 가져오기
----------------------------------
**********************************/
function getQueryUrl()
{
    var sQueryString = window.location.search;
    if(sQueryString.length > 0)
        sQueryString = sQueryString.substr(1, sQueryString.length);
    return sQueryString;
}

/**********************************
    URL 쿼리스트링 값 가져오기
-----------------------------------
 sItem : 키
 sUrl  : 주소[없으면 현재주소]
**********************************/
function getQueryString(sItem, sUrl)
{
    sUrl = sUrl || window.location.href;
    var sReturn = "";
    
    if(sUrl.indexOf("?") >= 0)
    {
        var sSearch = sUrl.substr(sUrl.indexOf("?") + 1, sUrl.length);
        var aItems = sSearch.split("&");
        for(var i=0; i<aItems.length; i++)
        {
            var aTmp = aItems[i].split("=");
            if(aTmp[0] == sItem)
            {
                sReturn = aTmp[1];
                break;
            }
        }
    }
    return sReturn;
}


/**********************************
    엘리먼트의 브라우저상 top구하기
----------------------------------
**********************************/
function jsFindoffsetTop(obj)
{
    var vTop = 0;
    if(obj.offsetParent) {
        do {
            vTop += obj.offsetTop;
        } while(obj = obj.offsetParent);
    }
    return vTop;
}

/**********************************
    엘리먼트의 브라우저상 left구하기
----------------------------------
**********************************/
function jsFindoffsetLeft(obj)
{
    var vLeft = 0;
    if(obj.offsetParent)
    {
        do
        {
            vLeft += obj.offsetLeft;
        }while(obj = obj.offsetParent);
    }
    return vLeft;
}

/**********************************
    텍스트에 포함된 HTML태그 삭제하기
----------------------------------
**********************************/
function stripHTML(strData)
{
    return strData.replace(new RegExp("<(/)?([a-zA-Z]*)(\\s*[a-zA-Z]*=[^>]*)?(\\s)*(/)?>", "gi"), "");
}


/**********************************
    텍스트에 포함된 HTML특수기호들
    원래대로치환
----------------------------------
**********************************/
function restoreSpecialChars(strData)
{
    var oSpan = document.createElement("SPAN");
    oSpan.innerHTML = strData;
    return oSpan.innerText;
}

/**********************************
    문자열 잘라내기
----------------------------------
**********************************/
function cutString(str, limit, sDot)
{
    var tmpStr = str;
    var byte_count = 0;
    var len = str.length;
    var bDot = false;
    var i;
    
    sDot = sDot || "...";
    
    
    for(i=0; i<len; i++)
    {
        byte_count += chr_byte(str.charAt(i));
        if(byte_count == limit-1)
        {
            if(chr_byte(str.charAt(i+1)) == 2)
            {
                tmpStr = str.substring(0, i+1);
                bDot = true;
            }
            else
            {
                if(i+2 != len)
                    bDot = true;
                tmpStr = str.substring(0, i+2);
            }
            break;
        }
        else if(byte_count == limit)
        {
            if(i+1 != len)
                bDot = true;
            tmpStr = str.substring(0, i+1);
            break;
        }
    }
    return tmpStr + (bDot == true ? sDot : "");
}

function chr_byte(chr)
{
    if(escape(chr).length > 4)
        return 2;
    else
        return 1;
}

/**************************
    클래스추가하기
---------------------------
 해당클래스명이
 정의되있지 않은경우에만 추가
**************************/
function addClass(oElement, sClassName)
{
    if(oElement.className.indexOf(sClassName) < 0)
        oElement.className += " " + sClassName;
}


/**************************
    클래스제거하기
---------------------------
**************************/
function removeClass(oElement, sClassName)
{
    oElement.className = oElement.className.replace(sClassName, "").replace(/(^\s*)|(\s*$)/gi, "");;
}


/**************************************
 하위노드 1 Depth를 소유한 Xml데이터를
 object형태로 반환

 !!주의!!
 - Xml 각 노드명이름으로 Property를 생성함
---------------------------------------
oXmlData      : 파싱할XMl데이터
bUseLowerCase : 각각의 Property를
                소문자로 강제치환여부
bUnescape     : unescape 이용여부
**************************************/
function convertXmlToObject(oXmlData, bUseLowerCase, bUnescape)
{
    var oData = {};
    var i;
    
    for(i=0; i<oXmlData.childNodes.length; i++)
    {
        var strData    = oXmlData.childNodes[i].childNodes[0].nodeValue;
        var strTagName = oXmlData.childNodes[i].tagName;
        oData[(bUseLowerCase == true ? strTagName.toLowerCase() : strTagName)] = (bUnescape == true ? unescape(strData) : strData);
    }
    return oData;
}


/**************************************
  지정된 TAG의 상위태그를 구해옴
  
---------------------------------------
oSrc     : 시작엘리먼트
sTagName : 태그명
**************************************/
function getParentElement(oSrc, sTagName)
{
    var oTmp = oSrc;
    if(oTmp.tagName.toLowerCase() == sTagName.toLowerCase())
        return oTmp;
    
    while((oTmp = oTmp.parentElement) != undefined)
    {
        if(oTmp.tagName.toLowerCase() == sTagName.toLowerCase())
            break;
    }
    return oTmp;
}


function showDebug(sMsg)
{
    var oDiv = document.getElementById("dDebug");
    var oUl;
    if(!oDiv)
    {
        oDiv      = document.createElement("DIV");
        oDiv.id   = "dDebug";
        oDiv.style.position = "absolute";
        oDiv.style.left = "0px";
        oDiv.style.top  = "0px";
        oDiv.style.padding = "4px";
        oDiv.style.border = "2px solid black";
        oDiv.style.backgroundColor = "#FFF";
        document.body.appendChild(oDiv);
        
        oUl = document.createElement("UL");
        oDiv.appendChild(oDiv);
    }
    
    oUl = oDiv.getElementsByTagName("UL");
    
    oDiv.innerText += "\n" + sMsg;

}

/**************************
 오늘날짜구하기 yyyymmdd
**************************/
function getNowDate()
{
    var oDate = new Date();
    var sYear = fillZeroNum(oDate.getFullYear(), 4, "l");
    var sMonth = fillZeroNum(oDate.getMonth() + 1, 2, "l");
    var sDay  = fillZeroNum(oDate.getDate(), 2, "l");
    return String(sYear) + String(sMonth) + String(sDay);
    
}


/***************************
 현재시간구하기 hhmmss
***************************/
function getNowTime()
{
    var oDate = new Date();
    var sHour = fillZeroNum(oDate.getHours(), 2, "l");
    var sMinute = fillZeroNum(oDate.getMinutes(), 2, "l");
    var sSecond = fillZeroNum(oDate.getSeconds(), 2, "l");
    return String(sHour) + String(sMinute) + String(sSecond);
}



/*****************************
 yyyymmdd데이터를
 yyyy/mm/dd 형태의 데이터로 변환
*****************************/
function convertDateFormat(sInput, sSpliter)
{
    if(sSpliter == undefined)
        sSpliter = "/";
    
    var sReturn;
    
    sReturn = ""
    sReturn += sInput.substr(0, 4) + sSpliter;
    sReturn += sInput.substr(4, 2) + sSpliter;
    sReturn += sInput.substr(6, 2)
    return sReturn;
}


/*****************************
 hhmmss데이터를
 hh/mm/ss 형태의 데이터로 변환
*****************************/
function convertTimeFormat(sInput, sSpliter)
{
    if(sSpliter == undefined)
        sSpliter = ":";
    
    var sReturn;
    
    sReturn = ""
    sReturn += sInput.substr(0, 2) + sSpliter;
    sReturn += sInput.substr(2, 2) + sSpliter;
    sReturn += sInput.substr(4, 2)
    return sReturn;
}

/*****************************
 ajax호출
------------------------------
 bPost : 포스트전송여부
 sSend : 포스트전송지 전송할데이타
*****************************/
function requestAjax(sUrl, bPost, sSend)
{
    var oXmlHttp = createXMLHttpRequest();

    oXmlHttp.open((bPost ? "POST" : "GET"), sUrl, false);
    oXmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
    oXmlHttp.setRequestHeader("Cache-Control", "no-cache, must-revalidate");
    oXmlHttp.setRequestHeader("Pragma", "no-cache");
    
    if(canDebug() == true)
    {
        showDebug("ajax_url = " + sUrl);
        if(bPost)
            showDebug("post=" + sPost);
    }

    oXmlHttp.send((bPost ? sSend : null));
    if(oXmlHttp.readyState == 4)
    {
        if(oXmlHttp.status == 200)
        {
            return {"state"  : 0,
                    "data"   : oXmlHttp.responseXML,
                    "data2"  : oXmlHttp.responseText,
                    "status" : oXmlHttp.status};
        }
        else
        {
            return { "state"  : 1,
                     "status" : oXmlHttp.status,
                     "data2"  : oXmlHttp.responseText};
        }
    }
    else
    {
        return { "state"  : 2,
                 "status" : oXmlHttp.status,
                 "data2"  : oXmlHttp.responseText};
    }
}



function getAjaxError(oAjax)
{
    var sMsg = "[오류발생]";
    sMsg += "\nstate=" + oAjax.state;
    sMsg += "\nstatus=" + oAjax.status;
    sMsg += "\ndata=" + oAjax.data2;
    return sMsg;
}





/*************************
  관리자이메일가져오기
*************************/
function getAdminMail()
{
    var sUrl = "/sub09/xml/xml_getadminmail.asp";
    var oReturn = requestAjax(sUrl);
    var sReturnValue = oReturn.data.getElementsByTagName("result")[0].getElementsByTagName("adminmail")[0].childNodes[0].nodeValue;
    return sReturnValue;
}

/***********************
  숫자 ,붙이기
------------------------
 1 : 입력값
***********************/
function addComma(strInput)
{
    /*
    var sRealValue = String(strInput);
    
    //앞에0제거
    while((sRealValue.length>0) && (sRealValue.substr(0, 1)=="0"))
        sRealValue = sRealValue.substr(1, sRealValue.length);
    
    var sReturn = "";
    var nCnt = 0;
    for(var i=sRealValue.length-1; i>=0; i--)
    {
        if((nCnt != 0) && (nCnt%3 == 0))
            sReturn = "," + sReturn;
        sReturn = sRealValue.substr(i, 1) + "" + sReturn;
        nCnt++;
    }
    return sReturn;
    */    
    
    return strInput.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}





/*************************
IE6에서 PNG투명구현
ex)
<style>
.png24{tmp:expression(setPng24(this));}
</style>
**************************/
function setPng24(oElement)
{
    oElement.width = oElement.height = 1;
    oElement.className = oElement.className.replace(/\bpng24\b/i,"");
    oElement.style.filer = "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + oElement.src + "', sizingMethod='image')";
    oElement.src = "";
    return "";
}

function pngTransparent()
{
    if(getBrowserType() == "ie6")
    {
        var oImages = document.getElementsByTagName("IMG");
        for(var i=0; i<oImages.length; i++)
        {
            //png파일에만 적용
            if(GetFileExt(oImages[i].src) == "png")
            {
                addClass(oImages[i], "png24");
            }
        }
    }
}

/************************************
x번째 자리까지에서 반올림하기.
-------------------------------------
nNum : 반올림할숫자
nPos : 반올림할 자릿수(1  : 1의자리
                       2  : 10의자리..
                       0  : 소수1자리
                       -1 : 소수2자리
                       .)
************************************/
function round2(nNum, nPos)
{
    var nTmp = nNum;
    nPos = -nPos;
    nTmp = nTmp * Math.pow(10, nPos);
    nTmp = Math.round(nTmp);
    nTmp = nTmp / Math.pow(10, nPos);
    return nTmp;
}


/************************************
자식노드삭제하기
-------------------------------------
oParent : 부모노드
nDepth  : 남겨둘 자식노드
************************************/
function clearChild(oParent, nDepth)
{
    try
    {
        while(oParent.childNodes.length > nDepth)
            oParent.removeChild(oParent.childNodes[nDepth]);
    }
    catch(er)
    { }
}



/************************************
이메일입력 SELECT박스 이벤트헨들러함수
(onchange로 설정)
-------------------------------------
1. 변경시킬 txt박스 ID
2. 이메일선택시 직접입력 불가능하도록 할건지여부
************************************/
function emailChanged(sTxtId, bVal, oEvent)
{
    oEvent = oEvent || window.event;
    var oEl = oEvent.target || oEvent.srcElement;
    var oTxt = document.getElementById(sTxtId);
    
    if(oEl.value == "")
    {
        oTxt.readOnly = false;
        oTxt.select();
        oTxt.focus();
    }
    else
    {
        oTxt.readOnly = (bVal == true ? bVal : false);
        oTxt.value = oEl.value;
    }
}
    


/************************************
    키입력 체크하기
-------------------------------------
 bIsReturn : 엔터키 입력했을 시
             리턴값 리턴시킬지 여부
             true일 경우
             'bReturn'값 리턴함
*************************************
1. 숫자가능여부
<키 : 문자값>
0 : 48
1 : 49
~
9 : 57


0(커서) : 96
~
9(커서) : 105


백스페이스 : 8
커서키 : 33, 34, 35, 36, 37, 38, 39, 40
DEL키  : 46 

하이픈(-) : 45
************************************/
function onlyNumber(bIsReturn, oEvent)
{
    oEvent = oEvent || window.event;
    var nKey = oEvent.keyCode
    var bReturn = false;

    //커서키, 백스페이스체크, 탭키, 엔터키, 하이픈(-)키
    if(((nKey >= 33) && (nKey <= 40)) || (nKey == 46) || (nKey == 8) || (nKey == 9) || (nKey == 13) || (nKey == 45)) {
        bReturn = true;
    }
    //숫자입력체크
    else if((((nKey >= 48) && (nKey <= 57)) || ((nKey >= 96) && (nKey <= 105))) && (event.shiftKey == false)) {
        bReturn = true;
    }

    if(bReturn == false) {
        if(oEvent.preventDefault)
            oEvent.preventDefault();
        else
            oEvent.returnValue = false;
    }
    
    if(nKey == 13 && bIsReturn == true)
        return bReturn;
}


/************************************
    엔터키 눌렸는지 체크
************************************/
function isEnter(oEvent)
{
    oEvent = oEvent || window.event;
    if(oEvent.keyCode == 13)
        return true;
    return false;
}


/************************************
    해당 엘리먼트(input-text)의 입력값의
    문자열 길이 체크후,
    만족시 다음위치로 포커스시키기
    (onkeyup이벤트에서 사용하는것이 좋다)
-------------------------------------
    1. 이동시킬 문자열 길이
    2. 이동시킬 포커스 ID
    3. 커서키, 탭키에도 반응을 시킬것인가 여부
       (일반적으로 false를 주는게 좋다)
************************************/
function checkAndFocus(nNum, sId, bCursor, oEvent)
{
    oEvent = oEvent || window.event;
    var oEl = oEvent.target || oEvent.srcElement;
    var nKey = oEvent.keyCode;
    //var nError = new Array(8, 9, 15, 17, 18, 20 ,91, 144);

    //커서키, 백스페이스체크
    if(((nKey >= 33) && (nKey <= 40)) || (nKey == 46) || (nKey == 8) || (nKey == 9) || (nKey == 16) || (nKey == 17) || (nKey == 18) || (nKey == 91))
    {
        if(bCursor == false)
            return;
    }
    
    if(oEl.value.length >= nNum)
        document.getElementById(sId).focus();
}


/************************************
    사업자등록번호 정상체크
    (오류검증을위해 일단 무조건 통과로)
-------------------------------------
    1. 1자리
    2. 2자리
    3. 3자리
************************************/
function checkRegno(sNo1, sNo2, sNo3)
{
    var sRegno = String(sNo1) + String(sNo2) + String(sNo3);
    if(sRegno.length < 10)
        return false;

    var sMask  = "137137135";//마스크(사업자등록번호보다 1자리 적다)
    var sSum = 0;
    var bVal = false;

    //1. 마스크에 해당하는 값을 사업자등록번호의 각 자릿수마다 곱해서 더한다.
    for(var i=0; i<sMask.length; i++)
        sSum += parseInt(sMask.substr(i, 1)) * parseInt(sRegno.substr(i, 1));
        
    //2. 사업자등록번호의 9번째자리에 5를 곱하고 10으로 나누어 나온 값의 몫을 1과 더한다
    sSum += parseInt((parseInt(sRegno.substr(sMask.length-1, 1)) * 5) / 10);
    
    //3. 2까지의 합을 10으로 나누어 나머지만 취한다
    sSum = sSum % 10;
    
    //4. 10에서 3번의값을 뺀 결과가 사업자등록번호 10번째자리와 일치해야 정상적인 사업자등록번호이다.
    //   (단 3의 값이 0인경우는 끝자리가 0인지와 비교한다
    if(sSum > 0)
    {
        if((10-sSum) == parseInt(sRegno.substr(sRegno.length-1, 1)))
            bVal = true;
    }
    else if(parseInt(sRegno.substr(sRegno.length-1, 1)) == 0)
        bVal = true;
    
    
    return bVal;
}


/******************************************
    form의 elements 빈값검증
-------------------------------------------
 1. form 객체
 2. 검증할 엘리먼트명
 3. 빈값일시 출력메세지
 4. focus 무시여부
 5. trim 무시여부
 6. 최대길이
******************************************/
function formCheckEmpty(oForm, sElName, sMsg, bIgnoreFocus, bIgnoreTrim, nMaxLength)
{
    bIgnoreTrim  = bIgnoreTrim  || false;
    bIgnoreFocus = bIgnoreFocus || false;
    var bVal = true;

    if(bIgnoreTrim != true)
        oForm.elements[sElName].value = oForm.elements[sElName].value.trim();

    if(oForm.elements[sElName].value == "")
    {
        if(sMsg)
            alert(sMsg);
        if(bIgnoreFocus != true)
            oForm.elements[sElName].focus();
        bVal = false;
    }
    else if(nMaxLength != undefined)
    {
        if(oForm.elements[sElName].value.length < nMaxLength)
        {
            alert(sMsg);
            if(bIgnoreFocus != true)
                oForm.elements[sElName].focus();
            bVal = false;
        }
    }
    
    return bVal;
}


/******************************************
    우편번호조회 팝업창열기
-------------------------------------------
1. 폼명(아이디)
2. 우편번호1
3. 우편번호2
4. 주소1
5. 주소2
6. 주소타입
7. 주소타입(0:지번, 1:도로명)
******************************************/
function openZip(sForm, sZip1, sZip2, sAddr1, sAddr2, sType, sZipType)
{
    var sUrl = "/zip/zip.asp?ziptype=" + sZipType + "&form=" + sForm + "&zip1=" + sZip1 + "&zip2=" + sZip2 + "&addr1=" + sAddr1 + "&addr2=" + sAddr2 + "&type=" + sType;
    
    window.open(sUrl, "zip", "width=535,height=500,scrollbars=yes,resizable=no");
}

function convertZip(sZip)
{
    return sZip.substr(0,3) + "-" + sZip.substr(3,3);
}




/*******************************************
 1. 최소길이
 2. 최대길이(0일경우 사용안함)
 3. 숫자영문자모두사용해야하는지여부
 4. 특수문자사용가능여부
-------------------------------------------
리턴값
0 : 정상
1 : 최소길이 만족안함
2 : 최대길이 만족안함
3 : 숫자영문자조합 만족안함
4 : 특수문자 만족안함
*******************************************/
function checkPassword(sInput, nMinLength, nMaxLength, bCheckBoth, bEtcEnable)
{
    if(sInput.length < nMinLength)
        return 1 
    
    if((nMaxLength > 0) && (sInput.length > nMaxLength))
        return 2;
    
    var nTmp;
    var nNumber = 0;
    var nString = 0;
    var nEtc    = 0;
    
    //숫자,영문자, 특수기호 갯수체크
    for(var i=0; i<sInput.length; i++)
    {
        nTmp = parseInt(sInput.charCodeAt(i));
        if((nTmp>=48) && (nTmp<=57))
        {//숫자
            nNumber++;
        }
        else if(((nTmp>=97)&&(nTmp<=122)) || ((nTmp>=65)&&(nTmp<=90)))
        {//영문자
            nString++;
        }
        else
        {//특수기호
            nEtc++;
        }
    }
    
    //특수문자 체크
    if((bEtcEnable==false) && (nEtc>0))
        return 4;
    
    //숫자영문자조건체크
    if(bCheckBoth==true)
    {
        if((nNumber==0) || (nString==0))
            return 3;
    }
    return 0;
}


/***********************************
    input 라디오 선택값 가져오기
***********************************/
function getRadioValue(oElement)
{
    var sValue = "";
    for(var i=0; i<oElement.length; i++)
    {
        if(oElement[i].checked == true)
        {
            sValue = oElement[i].value;
            break;
        }
    }
    return sValue;
}


/***********************************
    input 라디오 값 선택하기
***********************************/
function setRadioValue(oElement, sValue)
{
    for(var i=0; i<oElement.length; i++)
    {
        if((String)(oElement[i].value) == (String)(sValue))
            oElement[i].checked = true;
        else
            oElement[i].checked = false;
    }
}




/***********************************
    HTTPS보안(SSL) url호스트값 구하기
-----------------------------------
 SSL포트를 443이외에 다른포트를 사용할 경우
 sExtraHTTPSPort 에 포트값을 입력해준다.
***********************************/
var sExtraHTTPSPort = "";
function getHTTPSHost()
{
    
    var aHost = window.location.hostname.split(":");
    
    //임시로 SSL인증서 사용하기 전까지 http로 사용
    //var sUrl = "https://" + window.location.hostname + (sExtraHTTPSPort != "" ? ":"+sExtraHTTPSPort : "");
    
    var sUrl = "https://" + aHost[0] + (sExtraHTTPSPort != "" ? ":"+sExtraHTTPSPort : "");
    return sUrl;
}

/***********************************
    HTTP url호스트값 구하기
-----------------------------------
 포트를 80이외에 다른포트를 사용할 경우
 sExtraPort 에 포트값을 입력해준다.
***********************************/
var sExtraHTTPPort = "";
function getHTTPHost()
{
    var aHost = window.location.hostname.split(":");

    //var sUrl = "http://" + window.location.hostname + (sExtraHTTPPort != "" ? ":"+sExtraHTTPPort : "");
    var sUrl = "http://" + aHost[0] + (sExtraHTTPPort != "" ? ":"+sExtraHTTPPort : "");
    return sUrl;
}


/*********************************
  G-PIN 인증창 띄우기
**********************************/
/*
function requestGPIN(nCertType)
{
    var sParam;
    switch(parseInt(nCertType))
    {
        case 1://회원가입 (기존공공 I-PIN 비전환회원)
            sParam = "flag=1";
            break;
        case 2://아이디찾기
            sParam = "flag=2";
            break;
        case 3://비밀번호찾기
            sParam = "flag=3";
            break;
        case 4://회원가입확인(신규가입)
            sParam = "flag=4";
            break;
    }
    window.open("/G-PIN/gpin_AuthRequest.asp?" + sParam);
}
*/


/*********************************
  확장자로 이미지파일인지 확인하기
----------------------------------
 sExt : 파일확장자명
**********************************/
function isImageExt(sExt)
{
    sExt = sExt.toLowerCase();
    var aExt = String("jpg,jpeg,jpe,gif,png,pcx,bmp").split(",");
    for(var i=0; i<aExt.length; i++)
    {
        if(sExt == aExt[i])
            return true;
    }
    return false;
}


/*********************************
  이벤트 얻어오기
----------------------------------
 obj.event   : 이벤트객체
 obj.element : 이벤트발생 엘리먼트
**********************************/
function getEvent(oEvent)
{
    oEvent = oEvent || window.event;
    return {"event"   : oEvent,
            "element" : oEvent.target || oEvent.srcElement};
}



/*********************************
  자바스크립트로 페이지이동
----------------------------------
    location.href로 페이지이동시
    REFERER를 남겨야하는 경우
    이 함수로 이동
**********************************/
function moveTo(sUrl, sTarget)
{
    var oA = document.createElement("A");
    if(!oA.click)//Providing a logic form Non IE
    {
        window.location.href = sUrl;
        return;
    }
    oA.setAttribute("href", sUrl);
    oA.style.display = "none";
    oA.target = (sTarget != undefined ? sTarget : "_self");
    
    document.documentElement.appendChild(oA);
    oA.click();
    
}




/************************************
 getElementsByClassName(클래스명 [,부모태그명])
-------------------------------------
 getElementsByClassName 미지원브라우져(ie 등)
 추가용
************************************/
if(!document.getElementsByClassName)
{
    document.getElementsByClassName = function(sClassName, sParentTag)
    {
        if(sParentTag != undefined)
            sParentTag = sParentTag.toUpperCase();
        var oAll = document.getElementsByTagName("*");
        var oRtn = [];
        for(var i=0; i<oAll.length; i++)
        {
            if(oAll[i].className == sClassName)
            {
                if(sParentTag == undefined)
                {
                    oRtn.push(oAll[i]);
                }
                else
                {
                    if((oAll[i].parentElement != undefined) && (oAll[i].parentElement.tagName == sParentTag))
                        oRtn.push(oAll[i]);
                }
            }
        }
        return oRtn;
    }
}


/************************************
 동적 자바스크립트 import
-------------------------------------
 sSrc    : 경로
 [sType] : 타입(미입력시 기본값  text/javascript)
************************************/
function importScript(sSrc, sType)
{
    var oSc = document.createElement("SCRIPT");
    oSc.type = (sType != undefined ? sType :"text/javascript");
    oSc.src  = sSrc;
    
    document.getElementsByTagName("HEAD")[0].appendChild(oSc);
}



/************************************
  IFRAME_ACTION 생성
-------------------------------------
************************************/
function createActionIframe()
{
    //var oIfrm = document.getElementById("ifrmAction");
    var oIfrm = getIfrmAction();
    if(oIfrm == undefined)
    {
        oIfrm = document.createElement("IFRAME");
        oIfrm.name = "ifrmAction";
        oIfrm.id = "ifrmAction";
        oIfrm.className = "ifrmAction";
        oIfrm.title = "빈프레임";
        oIfrm.src = "about:blank;";
        document.documentElement.appendChild(oIfrm);
    }
    return oIfrm;
}

function getIfrmAction()
{
    return document.getElementById("ifrmAction");
}

function createActionIframeForDebug()
{
    var oIfrm = document.getElementById("ifrmActionForDebug");
    if(oIfrm == undefined)
    {
        oIfrm = document.createElement("IFRAME");
        oIfrm.name = "ifrmActionForDebug";
        oIfrm.id = "ifrmActionForDebug";
        oIfrm.className = "ifrmActionForDebug";
        oIfrm.title = "빈프레임";
        oIfrm.src = "about:blank;";
        document.documentElement.appendChild(oIfrm);
    }
    return oIfrm;
}

function createActionForm()
{
    var oFrm = getFrmAction();
    if(oFrm == undefined)
    {
        oFrm = document.createElement("FORM");
        oFrm.name = "frmAction";
        oFrm.id = "frmAction";
        oFrm.src = "about:blank;";
        document.documentElement.appendChild(oFrm);
    }
    return oFrm;
}

function getFrmAction()
{
    return document.getElementById("frmAction");
}

/************************************
 ETC첨부파일 다운로드하기
************************************/
function getEtcFile(nEtcKey)
{
    createActionIframe();
    
    var oA = document.getElementById("anchorAction");
    if(oA == undefined)
    {
        oA = document.createElement("A");
        oA.id = "anchorAction";
        oA.target = "ifrmAction";
        
        document.documentElement.appendChild(oA);
    }
    
    oA.href = "/upload/getetc.asp?ekey=" + nEtcKey;
    oA.click();
}

function canDebug()
{
    try
    {
        if(bCanDebug == "true")
            return true;
    }
    catch(er)
    { }
    return false;
}



function getCookieJASON() 
{
    var sCookie = document.cookie;
    alert(sCookie);
    var aTmp = sCookie.split(";");
    var oReturn = {};
    for(var i=0; i<aTmp.length; i++)
    {
        //하나의 쿠키에 = 표시가 2개이상 들어가있으면 2depth쿠키로 간주
        if(aTmp[i].split("=").length > 2)
        {
            var nSplPos = aTmp[i].indexOf("=");
            var sName = aTmp[i].substr(0, nSplPos);
            var sChilds = aTmp[i].substr(nSplPos + 1);

            var aTmp2 = sChilds.split("&");
            var oTmp = {};
            
            for(var j=0; j<aTmp2.length; j++) 
            {
                var aTmp3 = aTmp2[j].split("=");
                oTmp[aTmp3[0]] = aTmp3[1];
            }
            oReturn[sName] = oTmp;
        }
        else
        {
            var aTmp2 = aTmp[i].split("=");
            oReturn[aTmp2[0]] = aTmp2[1];
        }
    }
    return oReturn;
    
}


function openPop(sUrl, sOpenName, nWidth, nHeight, sOption) {
    window.open(sUrl, sOpenName, "width=" + nWidth + ",  height=" + nHeight + (sOption ? "," + sOption : ""));
}

/*****************************************
 객체형 데이터를 serialize함(url 키=값 쌍)
 -----------------------------------------
 기본값 : encodeuriComponent
*****************************************/
function serializeParam(oParam, sEncodeType) {
    var sStr = "";
    for(var v in oParam) {
        var sValue = oParam[v];
        if(sStr != "")
            sStr += "&";
        sStr = sStr + v + "=";
        switch(sEncodeType)
        {
            case "escape":
                sStr += escape(oParam[v]);
                break;
            case "utf-8":
                sStr += encodeURIComponent(oParam[v]);
                break;
            default: //인코딩안함
                sStr += oParam[v];
                break;
        }
    }
    return sStr;
}

/*****************************************
 객체형 데이터를 parallel함(url 키=값 쌍)
*****************************************/
function parallelizeParam(sString, sEncodeType) {
    var oReturn = {};
    var aParams = sString.split("&");//&문자열로 쪼갬
    for(var i=0; i<aParams.length; i++) {
        var aTmp = aParams[i].split("=");
        switch(sEncodeType) {
            case "escape":
                aTmp[1] = unescape(aTmp[1]);
                break;
            case "utf-8":
                aTmp[1] = decodeURIComponent(aTmp[1]);
                break;
            default: //인코딩안함
                aTmp[1] = aTmp[1];
                break;
        }
        oReturn[aTmp[0]] = aTmp[1];
    }
    return oReturn;
}

/**********************
 날짜 유효성검사
-----------------------
 1.yyyymmdd 형식의 날짜만 허용
 2.리턴값(에러넘버)
  0 : 정상
  1 : yyyymmdd 잘못됨
  2 : 유효하지 않은 날짜
***********************/
function validateDate(sDateString, bMsg) {
    
    //날짜 유효성검사
    //1. 숫자형 길이체크
    var oRegEx = /([0-9]){8}/gi;
    if(oRegEx.test(sDateString) == false) {
        if(bMsg)
            alert("날짜 형식이 잘못되었습니다.\nyyyymmdd 형태의 8자리숫자로 입력해주세요");
        return 1;
    }
    //2. 날짜범위체크
    var sYear = parseInt(sDateString.substr(0, 4));
    var sMon  = parseInt(sDateString.substr(4, 2));
    var sDay  = parseInt(sDateString.substr(6, 2));
    if(!(sMon > 0 && sMon < 13)
        || !(sDay > 0 && sDay <= getLastDay(sYear, sMon))) {
        if(bMsg)
            alert("날짜가 유효하지 않습니다.");
        return 2;
    }
    return 0;
}

/**********************
 달력형식으로맞추가
-----------------------
sId : 변환대상 아이디
***********************/
function setCalendar(sId) {
    $("#" + sId).datepicker(
    {
        inline: true,
        dateFormat: "yy-mm-dd",    /* 날짜 포맷 */ 
        prevText: 'prev', 
        nextText: 'next', 
        showButtonPanel: true,    /* 버튼 패널 사용 */ 
        changeMonth: true,        /* 월 선택박스 사용 */ 
        changeYear: true,        /* 년 선택박스 사용 */ 
        showOtherMonths: true,    /* 이전/다음 달 일수 보이기 */ 
        selectOtherMonths: true,    /* 이전/다음 달 일 선택하기 */ 
        showOn: "button", 
        buttonImage: "/images/calendar.png", 
        buttonImageOnly: true, 
        minDate: '-30y', 
        closeText: '닫기', 
        currentText: '오늘', 
        showMonthAfterYear: true,        /* 년과 달의 위치 바꾸기 */ 
        /* 한글화 */ 
        monthNames : ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'], 
        monthNamesShort : ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'], 
        dayNames : ['일', '월', '화', '수', '목', '금', '토'],
        dayNamesShort : ['일', '월', '화', '수', '목', '금', '토'],
        dayNamesMin : ['일', '월', '화', '수', '목', '금', '토'],
        showAnim: 'slideDown'
        /* 날짜 유효성 체크 */ 
        /*
        onClose: function( selectedDate ) {
        $('#fromDate').datepicker("option","minDate", selectedDate); 
        }
        */    
    });
}
/**********************
 달의 마지막날 구하기
**********************/
function getLastDay(nYear, nMonth)
{
    var nLastDay;
    switch(nMonth)
    {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            nLastDay = 31;
            break;
        case 4:
        case 6:
        case 9:
        case 11:
            nLastDay = 30;
            break;
        case 2:
            if(isLeafYear(nYear) == true)
                nLastDay = 29;
            else
                nLastDay = 28;
            break;
    }
    return nLastDay;
}
/**********************
 윤년인지 여부 구하기
**********************/
function isLeafYear(nYear)
{
    if(((nYear % 4) == 0) && ((nYear % 100 != 0) || (nYear % 400) == 0))
        return true;
    return false;
}
//2018.11.22~ 추가함(유지보수)
/**********************
 숫자만 입력하기
**********************/
function onlyNumber(event){
    event = event || window.event;
    var keyID = (event.which) ? event.which : event.keyCode;
    if ( (keyID >= 48 && keyID <= 57) || keyID == 8 || event.ctrlKey || event.altKey || keyID === 9 || keyID === 36 || keyID === 35 || keyID === 37 ||
    keyID === 39 || keyID === 8 || keyID === 46) 
        return;
    else
        return false;
}
function removeChar(event) {
    event = event || window.event;
    var keyID = (event.which) ? event.which : event.keyCode;
    if ( keyID == 8 )
      return;
    else
      event.target.value = event.target.value.replace(/[^0-9\-]/g, "");
  }
//2018.11.22~ 추가함(유지보수)
/**********************
 숫자 비교하기
 1. 두 숫자가 같으면 0, 첫 번째 숫자가 크면 1, 두 번째 숫자가 크면 2
 2. nAnswer와 비교값이 일치하면 nMsg를 출력하고 true 반환, 아니면 false 반환
**********************/
function compareNumbers(nOne, nTwo, nAnswer, sMsg) {
    var n1 = parseInt(nOne);
    var n2 = parseInt(nTwo);
    
    if(n1 == n2){
        if(nAnswer == 0) {
            alert(sMsg);
            return 1;
        }
    }
    else if(n1 > n2){
        if(nAnswer == 1) {
            alert(sMsg);
            return 1;
        }
    }
    else if(n1 < n2){
        if(nAnswer == -1) {
            alert(sMsg);
            return 1;
        }
    }

    return 0;
}
//2018.12.10~ 추가함
/**********************
아이디 정규식 검사
-----------------
sTarget: 대상 타겟 (아이디, 디바이스 아이디, 모델명 등)
**********************/
function checkID(sId, nMinLength, nMaxLength, bAllowWhiteSpace=false, sTarget="ID") {
    //영문, 숫자 포함
    var pattern = new RegExp('^[a-zA-Z0-9]{' + nMinLength + ',' + nMaxLength + '}$');

    //아무런 값이 없을 경우
    if(bAllowWhiteSpace && sId == ""){
        return true;
    }
    if(!pattern.test(sId)) {
        alert("The " + sTarget + " can be from " + nMinLength + " to " + nMaxLength + " characters in alphanumeric character");
        return false;
    }
    return true;
}
//2018.12.10~ 추가함
/**********************
비밀번호 정규식 검사 
**********************/
function checkPW(sPw, nMinLength, nMaxLength, bAllowWhiteSpace=false) {
    //영문, 숫자, 특수문자 포함
    var pattern = new RegExp('^[0-9a-zA-Z!@#$%^&*?]{' + nMinLength + ',' + nMaxLength + '}$');

    //아무런 값이 없을 경우
    if(bAllowWhiteSpace && sPw == ""){
        return true;
    }
    if(!pattern.test(sPw)) {
        alert("The password can be from " + nMinLength + " to " + nMaxLength + " characters in alphanumeric and special character combinations.")
        return false;
    }
    return true;
}
//2018.12.10~ 추가함
/**********************
휴대폰 번호 정규식 검사 
**********************/
function checkPhoneNumber(sPN, nMinLength, nMaxLength, bAllowWhiteSpace=false) {
    //숫자, 하이픈(-) 포함
    var pattern = new RegExp('^[0-9\-]{' + nMinLength + ',' + nMaxLength + '}$');

    //아무런 값이 없을 경우
    if(bAllowWhiteSpace && sPN == ""){
        return true;
    }
    if(!pattern.test(sPN)) {
        alert("Phone Numbers can be from " + nMinLength + " to " + nMaxLength + " characters in combination of numbers and hyphens.");
        return false;
    }
    return true;
}
//2018.12.10~ 추가함
/**********************
메일 주소 정규식 검사 
**********************/
function checkMailAddress(sMail, nMinLength, nMaxLength, bAllowWhiteSpace=false) {
    //아무런 값이 없을 경우
    if(bAllowWhiteSpace && sMail == ""){
        return true;
    }
    //영문, 숫자, 골뱅이(@) 포함
    var pattern = new RegExp('^[0-9a-zA-Z@.]{' + nMinLength + ',' + nMaxLength + '}$');

    if(!pattern.test(sMail)) {
        alert("E-mail addresses can be from " + nMinLength + " to " + nMaxLength + " characters in number and '@' combination.");
        return false;
    }
    return true;
}

//2018.11.23~ 추가함(유지보수)
/**********************
길이 검사
**********************/
function checkLength(sName, nStartLength, nEndLength, bAllowWhiteSpace=false, sTarget="Target") {
    //아무런 값이 없을 경우
    if(bAllowWhiteSpace && sName == ""){
        return true;
    }
    //길이 검사
    if(nStartLength > sName.length || sName.length > nEndLength) {
        alert(sTarget + " can be a maximum of " + nStartLength + " to " + nEndLength + " characters.");
        return false;
    }
    return true;
}
//2018.12.18~ 추가함(유지보수)
/**********************
숫자 검사
**********************/
function checkNumber(sNumber, bAllowWhiteSpace=false, sTarget="Target") {
    //아무런 값이 없을 경우
    if(bAllowWhiteSpace && sNumber == ""){
        return true;
    }
    //숫자만 포함
    var pattern = new RegExp('^\\d+$');

    if(!pattern.test(sNumber)) {
        alert("Only numbers can be entered in the " + sTarget);
        return false;
    }
    return true;
}

//2018.12.15~ 추가함(유지보수)
/**********************
날짜를 yyyy-mm-dd 형식으로 바꿔줌
**********************/
function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [year, month, day].join('-');
}

// 2021-09-30
/**********************
숫자형 문자열인지 검사
**********************/
function isNumeric(str) {
    if (!["string", "number"].includes(typeof str)) return false // we only process strings!
    return !isNaN(str) && // use type coercion to parse the _entirety_ of the string (`parseFloat` alone does not do this)...
           !isNaN(parseFloat(str)) // ...and ensure strings of whitespace fail
}
