import sqlite3
import time
import threading

# https://stackoverflow.com/questions/22739590/how-to-share-single-sqlite-connection-in-multi-threaded-python-application

class SensorDB:
    # path : DB 파일이 저장되는 위치
    def __init__(self, path):
        # DB 접속하기
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.cursor = self.conn.cursor()
        self.lock = threading.Lock()

        self.create_table()
    
    # DB 내에 센서 정보를 저장할 테이블 생성하기 (센서 데이터 구조는 아래와 같음)
    def create_table(self):
        # id : 고유 index
        # node_id : 노드 이름
        # node_value : 노드 값
        # node_time : 데이터 생성 시간 (날짜형)
        
        try:
            self.lock.acquire()

            self.cursor.execute('''
                CREATE TABLE IF NOT EXISTS RPI_NodeData(
                    `ID` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    `node_id` TEXT NOT NULL,
                    `node_value` INT NOT NULL DEFAULT 0,
                    `node_time` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                )
            ''')
        finally:
            self.lock.release()
        self.conn.commit()
    
    # 쿼리 조건문(WHERE) 가져오기
    # 검색할 node_id가 한 개일 때는 "node_id", 여러 개일 때는 "node_id1,node_id2,node_id3..." 과 같은 형식으로 입력해주어야함
    def getWhereQuery(self, node_id=None, node_value_start=None, node_value_end=None, node_time_start=None, node_time_end=None, select_only_number=False):
        conditions = []

        # 노드 이름으로 검색
        if(node_id is not None):
            # 검색할 노드가 여러 개일 때
            node_ids = node_id.split(",")
            if(type(node_id) == str and len(node_ids) > 1):
                conditions.append("node_id in {0}".format(tuple(node_ids)))
            # 검색할 노드가 1개일 때
            else:
                conditions.append("node_id='{0}'".format(node_id))

        # 노드값으로 검색
        if(node_value_start is not None):
            conditions.append("node_value >= {0}".format(node_value_start))
        if(node_value_end is not None):
            conditions.append("node_value <= {0}".format(node_value_end))
        # 데이터 생성 날짜로 검색
        if(node_time_start is not None):
            conditions.append("node_time >= '{0}'".format(node_time_start))
        if(node_time_end is not None):
            conditions.append("node_time <= '{0}'".format(node_time_end))
        
        # 숫자 데이터만 검색할 지 여부
        if(select_only_number):
            conditions.append("typeof(node_value) in ('integer', 'real', 'numeric')")

        # 만약 조건이 하나라도 있으면 쿼리에 WHERE 절을 붙임
        query = ""
        if(len(conditions) > 0):
            query += " WHERE "
        # 쿼리에 조건 추가
        for i in range(len(conditions)):
            query += conditions[i]
            # 마지막 조건인 경우 뒤에 AND를 붙이지 않음
            if(i + 1 != len(conditions)):
                query += " AND "
        
        return query

    # 데이터 검색
    # node_id : 검색 조건 - 노드 이름 (None일 경우, 모든 노드 데이터를 가져옴)
    # node_value_start : 검색 조건 - 노드값 (숫자형, 몇 이상인지)
    # node_value_end : 검색 조건 - 노드값 (숫자형, 몇 이하인지)
    # node_stime : 검색 조건 - 데이터 생성 시작 시간
    # node_etime : 검색 조건 - 데이터 생성 마지막 시간
    def select(self, node_id=None, node_value_start=None, node_value_end=None, node_time_start=None, node_time_end=None, select_only_number=False, using_json=True):
        # 쿼리 조건 가져오기
        where_query = self.getWhereQuery(
            node_id = node_id,
            node_value_start = node_value_start,
            node_value_end = node_value_end,
            node_time_start = node_time_start,
            node_time_end = node_time_end,
            select_only_number = select_only_number
        )

        # 쿼리 조합하기
        query = "SELECT * FROM RPI_NodeData" + where_query

        try:
            self.lock.acquire()

            self.cursor.execute(query)
            
            # 결과를 JSON 형태로 받아오도록 함
            if(using_json):
                result = []
                for row in self.cursor.fetchall():
                    info = dict({})
                    for i, value in enumerate(row):
                        info[self.cursor.description[i][0]] = value
                    result.append(info)
            else:
                result = self.cursor.fetchall()
        
        finally:
            self.lock.release()
        
        return result

    # 데이터 검색 (현재 데이터만 가져오도록 함)
    def select_by_current_time(self, node_id=None, node_value_start=None, node_value_end=None, select_only_number=False, using_json=True):
        # 쿼리 조합하기
        nNow = int(time.time()) # 현재 시간
        sTimeStamp = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(nNow)) # 검색할 시간
        
        # 쿼리 조건 가져오기
        # where_query = self.getWhereQuery(node_id, node_value_start, node_value_end, node_time_start=sTimeStamp, node_time_end=sTimeStamp)
        where_query = self.getWhereQuery(
            node_id = node_id,
            node_value_start = node_value_start,
            node_value_end = node_value_end,
            select_only_number = select_only_number
        )

        # GROUP BY node id, max(id)를 줌으로써 각 노드별로 가장 마지막에 들어온 데이터만 가져오도록 함
        query = '''
            SELECT MAX(ID) AS ID, node_id, node_value, node_time
            FROM RPI_NodeData {0}
            GROUP BY node_id
        '''.format(where_query)

        try:
            self.lock.acquire()

            self.cursor.execute(query)

            # 결과를 JSON 형태로 받아오도록 함
            if(using_json):
                data = []
                for row in self.cursor.fetchall():
                    info = dict({})
                    for i, value in enumerate(row):
                        info[self.cursor.description[i][0]] = value
                    data.append(info)
            else:
                data = self.cursor.fetchall()

            if(node_id == None):
                self.cursor.execute("select node_id from RPI_NodeData group by node_id")
                nodelist = [i[0] for i in self.cursor.fetchall()]
            else:
                nodelist = node_id.split(",")

        finally:
            self.lock.release()
        
        result = {
            'nodelist': nodelist,
            'datalist': data
        }

        return result

    # 데이터 검색 (일정 시간 단위로 데이터를 자를 수 있음)
    # node_id : 검색 조건 - 노드 이름 (None일 경우, 모든 노드 데이터를 가져옴)
    # nDivide = 2 # 데이터를 쪼갤 초 단위
    # nLimit = 10 # 최대 출력 개수
    def select_by_timestamp(self, node_id=None, node_value_start=None, node_value_end=None, select_only_number=False, nDivide=1, nLimit=10, using_json=True):
        # 쿼리 조합하기
        nNow = int(time.time()) # 현재 시간
        nDivide = int(nDivide)
        nLimit = int(nLimit)
        nStartTime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(nNow - (nDivide * nLimit))) # 시작 시간

        # 쿼리 조건 가져오기
        # where_query = self.getWhereQuery(node_id, node_value_start, node_value_end, node_time_start=nStartTime)
        where_query = self.getWhereQuery(
            node_id = node_id,
            node_value_start = node_value_start,
            node_value_end = node_value_end,
            select_only_number = select_only_number
        )

        if(where_query == ""):
            where_query = " WHERE "
        else:
            where_query += " AND "
        # where_query += '''({0} - strftime("%s", node_time)) % {1} = 0'''.format(nNow, nDivide)

        # query = '''
        #     SELECT MAX(ID) AS ID, node_id, node_value, node_time FROM (
        #         SELECT *, strftime("%s", node_time) AS G
        #         FROM RPI_NodeData
        #         {0}
        #     ) GROUP BY(G);
        # '''.format(where_query)

        nEndTime = nNow - (nNow % nDivide)
        nStartTime = nEndTime - (nDivide * nLimit)

        sCase = ""
        aTimeGroup = []
        for i in range(nLimit):
            sCase += " WHEN node_time >= '" + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(nStartTime + (nDivide * i))) + "' AND node_time < '" + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(nStartTime + (nDivide * i + 1))) + "' THEN " + str(i)
            # 시간 그룹을 배열에 담는다.
            aTimeGroup.append(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(nStartTime + (nDivide * i))))

        query = '''
            SELECT MAX(ID) AS ID, node_id, node_value, node_time, TIME_GROUP FROM (
                SELECT *, CASE {0} END AS TIME_GROUP
                FROM RPI_NodeData
                {1} TIME_GROUP IS NOT NULL
            ) GROUP BY node_id, TIME_GROUP
        '''.format(sCase, where_query)
        
        try:
            self.lock.acquire()
            
            self.cursor.execute(query)

            # 결과를 JSON 형태로 받아오도록 함
            if(using_json):
                data = []
                for row in self.cursor.fetchall():
                    info = dict({})
                    for i, value in enumerate(row):
                        info[self.cursor.description[i][0]] = value
                    data.append(info)
            else:
                data = self.cursor.fetchall()

            if(node_id == None):
                self.cursor.execute("select node_id from RPI_NodeData group by node_id")
                nodelist = [i[0] for i in self.cursor.fetchall()]
            else:
                nodelist = node_id.split(",")
        
        finally:
            self.lock.release()
        
        result = {
            'time': {
                'start': aTimeGroup[0],
                'group': aTimeGroup
            },
            'nodelist': nodelist,
            'datalist': data
        }

        return result

    # 데이터 삽입
    def insert(self, node_id, node_value, node_time=None):
        conditions = []
        
        # 별도로 날짜를 기입하지 않는 경우 기본값은 현재 시간이 된다.
        if(node_time is None):
            node_time = "datetime('now', 'localtime')"
        else:
            node_time = '"{0}"'.format(node_time)

        try:
            self.lock.acquire()
            
            self.cursor.execute('''
                INSERT INTO RPI_NodeData(
                    node_id, node_value, node_time
                ) VALUES (
                    "{0}", "{1}", {2}
                )
            '''.format(
                node_id, node_value, node_time, 
            ))

        finally:
            self.lock.release()
        
        self.conn.commit()

    # 데이터 수정 (필요가 없을 것 같아 기능을 추가하지 않음)
    def update(self):
        pass

    # 데이터 삭제
    # node_id : 삭제 조건 - 노드 이름 (None일 경우, 모든 노드 데이터를 삭제함)
    # node_stime : 검색 조건 - 데이터 생성 시작 시간
    # node_etime : 검색 조건 - 데이터 생성 마지막 시간
    def delete(self, node_id=None, node_value_start=None, node_value_end=None, node_time_start=None, node_time_end=None, select_only_number=False):
        # 쿼리 조건 가져오기
        where_query = self.getWhereQuery(
            node_id = node_id,
            node_value_start = node_value_start,
            node_value_end = node_value_end,
            node_time_start = node_time_start,
            node_time_end = node_time_end,
            select_only_number=select_only_number
        )

        # 쿼리 조합하기
        query = "DELETE FROM RPI_NodeData" + where_query

        try:
            self.lock.acquire()

            self.cursor.execute(query)
        finally:
            self.lock.release()
        self.conn.commit()

    # 초기화 (현재 DB에 저장된 센서 테이블을 삭제하고 새로 만듬)
    def reset(self):
        try:
            self.lock.acquire()

            self.cursor.execute("DROP TABLE IF EXISTS RPI_NodeData")
        finally:
            self.lock.release()

        self.create_table()
        self.conn.commit()
