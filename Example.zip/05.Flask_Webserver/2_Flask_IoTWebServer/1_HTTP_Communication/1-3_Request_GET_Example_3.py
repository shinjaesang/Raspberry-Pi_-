import requests


URL = 'http://127.0.0.1:5000/api/its_wrong_page'

response = requests.get(URL)

print("웹서버 GET 요청 결과-3 (주소 : {0})".format(URL))
print("상태 코드 : {0}".format(response.status_code))
