import os, sys

# database 종류는 SQLite3을 사용
import sqlite3

# 파이썬 스크립트가 실행 중인 현재 경로 가져오기
cur_script_dir_path = os.path.dirname(os.path.realpath(sys.argv[0]))

# database 파일 경로 (없으면 자동으로 생성됨)
database_path = os.path.join(cur_script_dir_path, "./data.db")

# database 접속하기
conn = sqlite3.connect(database_path, check_same_thread=False)

# database에서는 보통 SQL 구문을 호출해서 데이터를 조작하게 되는데 SQL 구문을 호출하려면 Cursor 객체가 필요하다.
cursor = conn.cursor()

# database 테이블에 모든 CDS 데이터를 삭제
node_id = "CDS"

cursor.execute('''
    DELETE FROM RPI_NodeData
    WHERE node_id="{0}"
'''.format(
    node_id
))

cursor.execute('''
    SELECT * FROM RPI_NodeData
    WHERE node_id="{0}"
'''.format(
    node_id
))

# 지금까지 작업한 내용을 실제로 데이터베이스에 반영하기 위해서는 commit 메서드를 호출해야 한다.
conn.commit()

# 데이터 조회 결과를 받아옴
result = cursor.fetchall()

# 받아온 모든 데이터를 한 줄씩 출력
for i in result:
    print(i)

# database 연결 종료
conn.close()
