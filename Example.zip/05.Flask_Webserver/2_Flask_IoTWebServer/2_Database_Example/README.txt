/*******************************
 *  SQLite3 Database 예제
*******************************/

 * 본 예제는 Database 사용법에 대한 예제입니다.
 * Database를 생성하고, 데이터를 삽입/조회/수정/삭제하기 위해 어떻게 명령어(쿼리)를 전달해야하는 지에 대한 부분을 다룹니다.
 * Database 종류는 Python 내장 모듈인 SQLite3을 사용합니다.
 * 이후 웹서버 구축(4번) 예제부터는 database query 구문에 대해 직접적으로 사용하지 않고, db_classes.py 파일에 함수로 정의하여 사용합니다.
 * Python 기반이며 각각의 예제는 Terminal 과 Thonny Python IDE에서 수행 가능합니다.

 1. create_database.py : Database 생성 방법 예제
 2. db_query_insert.py : 데이터 삽입(insert) 방법 예제
 3. db_query_update.py : 데이터 수정(update) 방법 예제
 4. db_query_delete.py : 데이터 삭제(delete) 방법 예제
 5. db_query_select.py : 데이터 조회(select) 방법 예제

