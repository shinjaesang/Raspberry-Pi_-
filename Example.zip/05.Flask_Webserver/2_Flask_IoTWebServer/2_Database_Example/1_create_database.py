import os, sys

# database 종류는 SQLite3을 사용
import sqlite3

# 파이썬 스크립트가 실행 중인 현재 경로 가져오기
cur_script_dir_path = os.path.dirname(os.path.realpath(sys.argv[0]))

# database 파일 경로 (없으면 자동으로 생성됨)
database_path = os.path.join(cur_script_dir_path, "./data.db")

# database 접속하기
conn = sqlite3.connect(database_path, check_same_thread=False)

# database에서는 보통 SQL 구문을 호출해서 데이터를 조작하게 되는데 SQL 구문을 호출하려면 Cursor 객체가 필요하다.
cursor = conn.cursor()

# database 내에 테이블 생성하기
cursor.execute('''
    CREATE TABLE IF NOT EXISTS RPI_NodeData(
        `ID` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
        `node_id` TEXT NOT NULL,
        `node_value` INT NOT NULL DEFAULT 0,
        `node_time` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    )
''')

# 만들어진 테이블의 구조를 출력
result = cursor.execute("PRAGMA table_info('RPI_NodeData')").fetchall()
print("┌──────────────────────────────┐")
for i in result:
    print("│ {0:02d} │ {1:>10s} │ {2:>10s} │".format(i[0], i[1], i[2]))
print("└──────────────────────────────┘")

# 지금까지 작업한 내용을 실제로 데이터베이스에 반영하기 위해서는 commit 메서드를 호출해야 한다.
conn.commit()

# database 연결 종료
conn.close()
