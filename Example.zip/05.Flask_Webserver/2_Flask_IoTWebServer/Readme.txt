/******************************
 *   IoT 서버 예제 (flask)
******************************/

1. HTTP_Communication : 
   - 1) HTTP 기초 예제 (GET, POST 등)
   - 2) HTTP 통신 & 센서 디바이스 연동 예제
2. Database_Example : 데이터베이스 예제
3. WebApp_Example : 
   - 1) 웹서버 기초 예제 (웹서버 구축, API 제작 등)
   - 2) 센서 디바이스 & DB 연동 예제
   - 3) 대시보드 연동 예제
