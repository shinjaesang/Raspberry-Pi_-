# -*- coding: utf-8 -*-
from flask import Flask,request, render_template, jsonify
import time
import socket

app = Flask(__name__)

def getIpAddress():
    # 할당된 IP를 보여주기 위한 코드
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(('8.8.8.8',1))
    # 가져온 IP를 넘겨 받아 추출한다 
    ipaddr = (s.getsockname()[0])
    # 공유기를 통해 분배된 IP를 얻는것이 목적이었으므로 연결을 끊어준다
    s.close()
    return ipaddr

@app.route("/")
def index():
    return render_template("index.html",ipaddr=getIpAddress())

if __name__ == "__main__":  
    app.run(host="0.0.0.0",debug=True)