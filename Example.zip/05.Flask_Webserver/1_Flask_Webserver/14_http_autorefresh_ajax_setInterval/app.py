from flask import Flask,request, render_template, jsonify
import time

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html")

# 업데이트를 수행할 주소 및 메서드 유형
@app.route('/update',methods=['POST'])
def udpate():
    # 요청시 반환할 데이터인 시간 값 
    currentTime = str(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())))
    # jsonify는 flask에 있으며, JSON 타입의 응답데이터를 생성한다.
    return jsonify({
        # currentTime을 키로하는 시간 값을 넘겨준다. (요청시)
        "currentTime":currentTime,
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0",debug=True)