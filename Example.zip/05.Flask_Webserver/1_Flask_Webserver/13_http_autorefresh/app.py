from flask import Flask,request, render_template
import time

app = Flask(__name__)


@app.route("/")
def index():
    currentTime = str(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())))
    return render_template("index.html",current_time=currentTime)

if __name__ == "__main__":
    app.run(host="0.0.0.0",debug=True)