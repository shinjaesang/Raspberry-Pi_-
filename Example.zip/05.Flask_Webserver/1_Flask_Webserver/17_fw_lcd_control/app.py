# -*- coding: utf-8 -*-
from flask import Flask,request, render_template, jsonify
import time
import socket
import I2C_LCD_driver

# I2C_LCD_Driver 모듈을 사용하는 예제
textLcd = I2C_LCD_driver.lcd()
app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route('/button', methods=['GET'])
def get():
    line1 = request.args.get("message1")
    line2 = request.args.get("message2")
    
    # LCD의 화면을 초기화한다.
    clearStr = "                "
    textLcd.lcd_display_string(clearStr, 1)
    textLcd.lcd_display_string(clearStr, 2)

    # 넘겨 받은 LCD의 값을 각각 기록한다.
    textLcd.lcd_display_string(line1, 1)
    textLcd.lcd_display_string(line2, 2)

    return render_template("index.html",line1_msg=line1, line2_msg=line2)

if __name__ == "__main__":
    app.run(host="0.0.0.0",debug=True)
