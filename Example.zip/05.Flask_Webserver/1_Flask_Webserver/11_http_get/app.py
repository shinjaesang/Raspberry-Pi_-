from flask import Flask,request, render_template

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route('/method', methods=['GET'])
def get():
    birth = request.args["birth"]
    name = request.args.get("name")
    return "[GET] 생년월일:{} 이름:{}".format(birth, name)

if __name__ == "__main__":
    app.run(host="0.0.0.0",debug=True)