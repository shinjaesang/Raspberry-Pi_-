# -*- coding: utf-8 -*-
from flask import Flask,request, render_template, jsonify
import time
import socket

# GPIO 제어를 위해 RPi.GPIO 모듈을 사용한다.
import RPi.GPIO as GPIO

BuzzerState = ""

# BCM 핀맵을 사용한다
GPIO.setmode(GPIO.BCM)

buzzer = 12

# 4옥타브 도레미~ 5옥타브 도
scale = [261, 294, 330, 349, 392, 440, 493, 523]

# Buzzer핀의 GPIO를 출력으로 설정
GPIO.setup(buzzer, GPIO.OUT) 

pwm = GPIO.PWM(buzzer, 100)

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route('/button', methods=['GET'])
def get():
    btn_clicked = request.args.get("control_button")
    if(btn_clicked):
        if btn_clicked == "ON":
            # Buzzer를 켠다
            # pwm 시작
            pwm.start(100) 
            pwm.ChangeDutyCycle(50) 
            pwm.ChangeFrequency(330) #주파수 변경   
            time.sleep(0.5)
            BuzzerState = "Buzzer ON"

        elif btn_clicked == "OFF":
            # Buzzer를 끈다
            pwm.ChangeDutyCycle(100) 
            BuzzerState = "Buzzer OFF"

    return render_template("index.html",devicestate=BuzzerState)

if __name__ == "__main__":
    app.run(host="0.0.0.0",debug=True)
    # Buzzer를 끈다
    GPIO.output(buzzer,GPIO.LOW)
    # GPIO를 초기화한다
    GPIO.cleanup()