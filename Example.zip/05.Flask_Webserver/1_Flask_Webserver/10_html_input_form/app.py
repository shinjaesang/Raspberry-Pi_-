from flask import Flask, render_template
from flask import request
from flask import redirect
from werkzeug.utils import secure_filename
import os

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = '/Users/zzubb/OneDrive/바탕 화면/umc/'

@app.route('/')
def index():
    select = None
    return render_template('index.html', select=select)

# 버튼 클릭에 대한 처리
@app.route('/button', methods=['GET'])
def button():
    msg = request.args.get('message')
    return "수신 메세지! => {}".format(msg)

# 이미지 버튼에 대한 리다이렉트
@app.route('/youtube', methods=['GET'])
def youtube():
    msg = request.args.get('message')
    return redirect("http://www.youtube.com")

# 체크 버튼 처리
@app.route('/checkbox', methods=['GET'])
def checkbox():
    checkVar = ["book","movie","photo","exercise","game"]
    print(request.args)
    msg = ""
    for i in request.args:
        if len(msg)==0:
            msg = i
        else:
            msg = "{},{}".format(msg,i)
    return "선택된 취미 : {}".format(msg)

# 체크 버튼 처리
@app.route('/radio', methods=['GET'])
def radiobutton():
    select = request.args.get('fruit')
    return render_template('index.html', select=select)

if __name__ == "__main__":
    app.run(host="0.0.0.0",debug=True)