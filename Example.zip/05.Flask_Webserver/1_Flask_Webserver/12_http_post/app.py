from flask import Flask,request, render_template

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route('/method', methods=['POST'])
def post():\
    # HTML로부터 전달된 데이터는 아래와 같은 딕셔너리 값으로 전달 받는다.
    # ImmutableMultiDict([('num', '891105'), ('name', 'hjlee')])
    birth = request.form["birth"]
    name = request.form["name"]
    return "POST로 전달된 데이터({}, {})".format(birth, name)

if __name__ == "__main__":
    app.run(host="0.0.0.0",debug=True)