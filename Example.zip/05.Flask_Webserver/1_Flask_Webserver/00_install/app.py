import subprocess

def install(name):
    subprocess.call(['pip3', 'install', name])

if __name__ == "__main__":
    install('flask')
