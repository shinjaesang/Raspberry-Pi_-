from flask import Flask

app = Flask(__name__)

@app.route("/")
def index():
    return "Hello World!"

@app.route("/home/")
def home():
    return "Hello, Home!"

# 동적 라우팅, 변수
@app.route("/user/<name>/")
def user(name):
    return "Hello, %s!" % (name)

# 동적 라우팅, 정수 타입 처리
@app.route("/type/<int:type>/")
def type_int(type):
    return "(int) user id is => %d" % (type)

# 동적 라우팅, 문자열 타입 처리
@app.route("/type/<string:type>/")
def type_str(type):
    return "(string) user id is => %s" % (type)

# 동적 라우팅, 실수 타입 처리
@app.route("/type/<float:type>/")
def type_float(type):
    return "(float) user id is => %f" % (type)

# 동적 라우팅, 경로형 처리
@app.route("/type/<path:type>/")
def type_path(type):
    return "(path) user id is => %s" % (type)

if __name__ == "__main__":
    app.run(host="0.0.0.0",debug=True)