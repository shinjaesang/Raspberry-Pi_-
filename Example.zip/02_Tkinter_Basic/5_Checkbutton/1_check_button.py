from tkinter import *
import time

# 프로그램의 창을 생성하는 MainFrame 클래스
class MainFrame(Frame):
    
    # MainFrame 클래스의 생성자.
    # self는 객체의 인스턴스를 의미하며, master는 부모 객체를 의미한다. 여기서는 Tk를 의미한다.
    def __init__(self, master):
        master.title('창')

        # 윈도우 크기 및 좌표를 속성으로 한다.
        master.geometry("320x240+10+10")
        
        self.checkbuttonvar = IntVar()

        checkbutton = Checkbutton(master, background="orange", text= "CheckButton", variable = self.checkbuttonvar)
        checkbutton.pack(side=LEFT, expand = 1)
        
# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    # GPIO_LED_init()
    root = Tk() # 창을 띄우기 위한 객체를 선언
    mainFrame = MainFrame(root) #창 객체를 인자로 클래스를 생성한다
    root.mainloop() # python의 창을 띄우고 이벤트 처리 수행 함수
    # GPIO_LED_cleanup() # 프로그램 종료 후 GPIO를 cleanup 한다