from tkinter import *

# 프로그램의 창을 생성하는 MainFrame 클래스
class MainFrame(Frame):
    
    # MainFrame 클래스의 생성자.
    # self는 객체의 인스턴스를 의미하며, master는 부모 객체를 의미한다. 여기서는 Tk를 의미한다.
    def __init__(self, master):
        master.title('창')

        # 윈도우 크기 및 좌표를 속성으로 한다.
        master.geometry("320x240+10+10")

        # 텍스트 출력하기
        label = Label(master, background="yellow", text="메세지가 출력 됩니다")
        label.pack(expand=1)

        # 텍스트 입력 위젯인 Entry 생성하기
        entry = Entry(master, background="magenta")
        entry.pack(expand=1)

        # 버튼 생성하기
        button = Button(master, background="cyan", text="버튼 위젯")
        button.pack(expand=1)

# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    root = Tk() # 창을 띄우기 위한 객체를 선언
    mainFrame = MainFrame(root) #창 객체를 인자로 클래스를 생성한다
    root.mainloop() # python의 창을 띄우고 이벤트 처리 수행 함수