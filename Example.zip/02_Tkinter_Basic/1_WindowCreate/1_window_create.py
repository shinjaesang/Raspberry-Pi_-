from tkinter import *

root = Tk() # 창을 띄우기 위한 객체를 선언
root.mainloop() # python의 창을 띄우고 이벤트 처리 수행 함수

