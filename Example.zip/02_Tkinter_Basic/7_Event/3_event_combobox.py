from tkinter import *
from tkinter import ttk
import time
import threading

# 프로그램의 창을 생성하는 MainFrame 클래스
class MainFrame(Frame):
    
    # MainFrame 클래스의 생성자.
    # self는 객체의 인스턴스를 의미하며, master는 부모 객체를 의미한다. 여기서는 Tk를 의미한다.
    def __init__(self, master):
        master.title('창')

        # 윈도우 크기 및 좌표를 속성으로 한다.
        master.geometry("320x240+10+10")

        # 텍스트 출력하기
        self.label = Label(master, background="yellow", text="콤보박스")
        self.label.pack(expand=1)

        values=['라면','짜장면','국수','냉면','짬뽕'] 
        
        # 콤보박스 생성하기
        combobox= ttk.Combobox(master, height=15, values=values)
        combobox.set("선택")

        # 콤보박스가 선택되었을때 호출될 콜백함수를 지정한다.
        combobox.bind("<<ComboboxSelected>>", self.callbackFunc)

        # pack() 함수를 사용해서 위젯을 배치한다.
        # expand 옵션은 master에 의해 제공되는 공간을 모두 사용할지 여부를 결정한다.
        combobox.pack(expand=1)

    def callbackFunc(self,event):
        country = event.widget.get()
        self.label.configure(text=country)
        print(country)

# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    root = Tk() # 창을 띄우기 위한 객체를 선언
    mainFrame = MainFrame(root) #창 객체를 인자로 클래스를 생성한다
    root.mainloop() # python의 창을 띄우고 이벤트 처리 수행 함수