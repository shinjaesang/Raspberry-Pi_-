from tkinter import *
from tkinter import ttk
import time
import threading

# 프로그램의 창을 생성하는 MainFrame 클래스
class MainFrame(Frame):
    
    # MainFrame 클래스의 생성자.
    # self는 객체의 인스턴스를 의미하며, master는 부모 객체를 의미한다. 여기서는 Tk를 의미한다.
    def __init__(self, master):
        master.title('창')

        # 윈도우 크기 및 좌표를 속성으로 한다.
        master.geometry("320x240+10+10")

        # 텍스트 출력하기
        label = Label(master, background="yellow", text="체크박스 상태")
        label.pack(expand=1)

        self.checkbuttonvar = IntVar()
        checkbutton = Checkbutton(master, 
                                  background="orange", 
                                  text= "CheckButton", 
                                  variable = self.checkbuttonvar, 
                                  command=lambda:self.onCheckbuttonClickEvent(label,))
        checkbutton.pack(expand=1)

    # label 객체를 받아 메세지를 출력하는 함수
    def onCheckbuttonClickEvent(self,label_widget):
        msg = None
        if self.checkbuttonvar.get() == 1:
            msg = "selected"
        else:
            msg = "not selected"
        print("Checkbutton : {}".format(msg))
        label_widget.configure(text=msg)

# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    root = Tk() # 창을 띄우기 위한 객체를 선언
    mainFrame = MainFrame(root) #창 객체를 인자로 클래스를 생성한다
    root.mainloop() # python의 창을 띄우고 이벤트 처리 수행 함수