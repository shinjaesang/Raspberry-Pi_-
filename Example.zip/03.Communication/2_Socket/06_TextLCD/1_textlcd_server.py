import socket
import sys
import threading
import time
import I2C_LCD_driver

# I2C_LCD_Driver 모듈을 사용하는 예제
textLcd = I2C_LCD_driver.lcd()
textLcd.lcd_clear()

# 채팅을 위한 서버 소켓 클래스
class ServerSocketClass():
    
    def __init__(self):
        while True :
            try:
                # TCP/IP 서버 소켓을 생성한다
                self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR,1)
                # 서버의 IP와 포트를 설정한다
                # 같은 네트워크에 있어야 한다
                server_address = ('', 10000)

                # 서버가 시작시 메세지가 출력된다.
                print("The Server is wating. IP: {0} PORT: {1}".format(server_address[0],server_address[1]))
                # 서버 IP와 포트 번호를 고정한다
                self.sock.bind(server_address)

                # 클라이언트의 연결을 받을 수 있는 상태를 시작한다
                self.sock.listen(1)

                # 클라이언트 대기 메세지를 출력한다
                print("Waiting for Client access..")

                # 클라이언트의 접속을 수용하고, 클라이언트로부터 소켓과 클라이언트 주소를 반환 받는다.
                self.connection, client_address = self.sock.accept()

                try:
                    # 접속 위치를 알린다
                    print("Connection from", client_address)
                    while True:
                        # 아래는 서버에 접속할시 처리할 동작을 기술한다
                        data = self.connection.recv(4096)
                        # data 값이 false 즉 들어오지 않을시 끊김으로 판단
                        if data:
                            # UTF-8로 디코딩하고 LF로 메세지를 자른다.
                            msgStr = data.decode("utf-8")
                            removeLf = msgStr.split('\n')[0]
                            # 값과 제어 값을 구분하기 위해 쉼표를 사용한다.
                            # 쉼표를 중심으로 배열이 만들어진다.
                            msg = removeLf.split(',')
                            # textlcd,1,message 형태로 들어올 시 길이는 3이다.
                            if len(msg) == 3:
                                # textlcd 가 아니면 동작하지 않는다.
                                if msg[0] == "textlcd":
                                    line = int(msg[1])
                                    if line >= 1 and line <= 2:
                                        textLcd.lcd_display_string("                ", line)
                                        # 16자 이내 아스키코드, 1은 첫 번째 줄이고 2는 두 번째 줄이다
                                        textLcd.lcd_display_string(msg[2], line)
                                        print(" line:{} / message:{}".format(msg[1],msg[2]))
                                        self.connection.sendall("OK.".encode('utf-8'))
                                    else:
                                        self.connection.sendall("fail!".encode('utf-8'))
                        else:
                            print("Disconnect")
                            break
                        time.sleep(1)
                except Exception as err:
                    # 접속을 종료한다
                    self.connection.close()
                    print(err)

            except Exception as err:
                print(err)

            finally:
                print("Closing socket END Prgorams")
                self.sock.close()

# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    try:
        ServerSocketClass = ServerSocketClass() # 창 객체를 인자로 클래스를 생성한다
    except KeyboardInterrupt:
        print("Program force quit")
        sys.exit()        
