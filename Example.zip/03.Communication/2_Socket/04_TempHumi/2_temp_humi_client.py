import socket
import sys
import threading
import time
from socket import error as socket_error

# 통신을 위한 클라이언 소켓 클래스
# 포트는 10000 이다
class ClientSocketClass():
    
    def __init__(self):
        while True :
            try:
                # 소켓을 생성한다
                self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

                # 서버의 IP와 포트를 설정한다
                server_address = ("127.0.0.1", 10000)

                # 현재 접속할 서버의 IP와 포트를 콘솔로 출력한다.
                print("This is Client. connecting IP: {0} PORT: {1}".format(server_address[0],server_address[1]))

                # 서버로 접속을 시도한다
                self.sock.connect(server_address)

                while True:
                    # 아래는 서버에 접속할시 처리할 동작을 기술한다
                    data = self.sock.recv(4096)
                    if(data):
                        # 수신 받은 데이터를 디코딩한다. 디코딩은 인코딩 했던것으로 한다.
                        msgStr = data.decode("utf-8")
                        # 메세지에 붙은 LF 를 자른다.
                        removeLf = msgStr.split('\n')[0]
                        # 센서명과 값을 구분해야하기 위해 쉼표로 잘라준다.
                        msg = removeLf.split(',')
                        # 쉼표로 구분해서 자를 경우 해당 패킷의 길이는 2의 배열이 된다.
                        if len(msg) == 2:
                            name = msg[0]
                            value = msg[1]
                            unit = ''
                            # 센서의 이름에 따라 단위를 구분해서 붙인다.
                            if msg[0] == 'Temperature':
                                unit = '°C'
                            elif msg[0] == 'Humidity':
                                unit = '%'
                            print("[Sensor]:{} [Value]:{}{}".format(name,value,unit))
                    else:
                        print("Disconnect")
                        break

            # 서버가 열려 있지 않을시 3초 동안 대기한다
            except socket_error as serr:
                time.sleep(3)
                print(serr)
                
            except Exception as err:
                print(err)

            finally:
                try:
                    # 접속을 종료한다
                    self.sock.close()
                    print("Closing socket")
                except Exception as sockerr:
                    pass

# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    try: 
        # 창 객체를 인자로 클래스를 생성한다
        ClientSocketClass = ClientSocketClass()
    except KeyboardInterrupt:
        print("Program force quit")
        sys.exit()
