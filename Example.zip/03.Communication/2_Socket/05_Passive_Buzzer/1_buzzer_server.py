import socket
import sys
import threading
import time
# GPIO 제어를 위해 RPi.GPIO 모듈을 사용한다. 라즈베리파이 기본 모듈이다.
import RPi.GPIO as GPIO

# BCM 핀맵을 사용한다
GPIO.setmode(GPIO.BCM)

buzzer = 12

# 4옥타브 도레미~ 5옥타브 도
SCALE = [261, 294, 330, 349, 392, 440, 493]
SCALE_STR = {'do':0, 're':1, 'mi':2, 'fa':3, 'sol':4, 'la':5, 'ti':6}

# Buzzer핀의 GPIO를 출력으로 설정
GPIO.setup(buzzer, GPIO.OUT) 

pwm = GPIO.PWM(buzzer, 100)

# 채팅을 위한 서버 소켓 클래스
class ServerSocketClass():
    
    def __init__(self):
        while True :
            try:
                # pwm 시작
                pwm.start(100) 
                pwm.ChangeDutyCycle(100) 

                # TCP/IP 서버 소켓을 생성한다
                self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR,1)
                # 서버의 IP와 포트를 설정한다
                # 같은 네트워크에 있어야 한다
                server_address = ('', 10000)

                # 서버가 시작시 메세지가 출력된다.
                print("The Server is wating. IP: {0} PORT: {1}".format(server_address[0],server_address[1]))
                # 서버 IP와 포트 번호를 고정한다
                self.sock.bind(server_address)

                # 클라이언트의 연결을 받을 수 있는 상태를 시작한다
                self.sock.listen(1)

                # 클라이언트 대기 메세지를 출력한다
                print("Waiting for Client access..")

                # 클라이언트의 접속을 수용하고, 클라이언트로부터 소켓과 클라이언트 주소를 반환 받는다.
                self.connection, client_address = self.sock.accept()

                try:
                    # 접속 위치를 알린다
                    print("Connection from", client_address)
                    while True:
                        # 아래는 서버에 접속할시 처리할 동작을 기술한다
                        data = self.connection.recv(4096)
                        # data 값이 false 즉 들어오지 않을시 끊김으로 판단
                        if data:
                            # UTF-8로 디코딩하고 LF로 메세지를 자른다.
                            msgStr = data.decode("utf-8")
                            removeLf = msgStr.split('\n')[0]
                            # 값과 제어 값을 구분하기 위해 쉼표를 사용한다.
                            # 쉼표를 중심으로 배열이 만들어진다.
                            msg = removeLf.split(',')
                            # buzzer,do 형태로 들어올 시 길이는 2이다.
                            if len(msg) == 2:
                                try:
                                    # buzzer 가 아니면 동작하지 않는다.
                                    if msg[0] == "buzzer":
                                        # dutycycle 50%
                                        pwm.ChangeDutyCycle(50)
                                        # 음계 명령문을 사용해서 주파수를 가져온다.
                                        pwm.ChangeFrequency(int(SCALE[SCALE_STR[msg[1]]])) 
                                        print("RECEIVE Message >> [Sensor]:{} [Value]:{}".format(msg[0],msg[1]))
                                        time.sleep(0.5)
                                except KeyError as err:
                                    print("invalid command : {}".format(err))
              
                            # dutycycle을 100% 로 만들어서 소리를 끈다.
                            pwm.ChangeDutyCycle(100) 
                        else:
                            print("Disconnect")
                            break
                        time.sleep(1)
                except Exception as err:
                    # 접속을 종료한다
                    self.connection.close()
                    print(err)

            except Exception as err:
                print(err)

            finally:
                print("Closing socket END Prgorams")
                self.sock.close()

# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    try:
        ServerSocketClass = ServerSocketClass() # 창 객체를 인자로 클래스를 생성한다
    except KeyboardInterrupt:
        print("Program force quit")
        sys.exit()        
    # Buzzer를 끈다
    GPIO.output(buzzer,GPIO.LOW)
    # GPIO를 초기화한다
    GPIO.cleanup()
