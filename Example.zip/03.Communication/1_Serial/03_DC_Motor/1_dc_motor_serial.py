import sys
import threading
import time
import serial
import RPi.GPIO as GPIO

# GPIO의 모드를 BCM으로 설정한다(GPIO번호 사용)
GPIO.setmode(GPIO.BCM)

# 모터와 연결된 GPIO 번호를 변수에 저장한다.
MOTOR_P = 19
MOTOR_M = 13

#  시리얼 통신을 위한 클래스
class SerialClass():
    
    def __init__(self):
        RecvMessage = ''
        try:
            print("Start DC Motor Control Program...")
            print("Send command 'DC,ON\\n' or 'DC,OFF\\n'")

            # /dev/ttyS0 포트를 115200 bps의 속도로 연다
            self.RaspSerial = serial.Serial('/dev/ttyS0',115200)
            
            # MOTOR_P, MOTOR_M 핀을 OUTPUT 으로 설정한다.
            GPIO.setup(MOTOR_P, GPIO.OUT)
            GPIO.setup(MOTOR_M, GPIO.OUT)

            # 메세지를 받는 루프문
            while True :
                # 시리얼로부터 1byte를 읽어온다
                aByte = self.RaspSerial.read(1) 

                # 현재 읽어온 byte에 LF 문이 있으면 분석을 시작한다.
                if( aByte == b'\n'):
                    # 현재 수신 데이터를 쉼표를 기준으로 구분한다.
                    msg = RecvMessage.split(',')
                    # DC,ON 형태로 수신시 길이를 체크한다.
                    if len(msg) == 2:
                        # 수신 된 제어 메세지가 DC일시 ON/OFF로 구분하여 각각 제어한다.
                        if msg[0] == "DC":
                            print("{},{}".format(msg[0],msg[1]))
                            # ON일시 DC모터 정방향 제어
                            if msg[1] == "ON":
                                GPIO.output(MOTOR_M, GPIO.LOW)
                                GPIO.output(MOTOR_P, GPIO.HIGH)
                                self.RaspSerial.write(bytes("OK\n".encode()))
                            # OFF일시 DC모터 정지
                            elif msg[1] == "OFF":
                                GPIO.output(MOTOR_M, GPIO.LOW)
                                GPIO.output(MOTOR_P, GPIO.LOW)
                                self.RaspSerial.write(bytes("OK\n".encode()))

                    RecvMessage = ""
                # LF 가 나올때까지 문자열에 현재 byte를 추가한다
                else :
                    RecvMessage += str(aByte.decode())

        except Exception as err:
            print(err)

# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    try:
        serialClass = SerialClass() # 창 객체를 인자로 클래스를 생성한다
    except KeyboardInterrupt:
        print("Program force quit")
        sys.exit()
