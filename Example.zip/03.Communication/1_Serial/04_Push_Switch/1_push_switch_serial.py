import sys
import threading
import time
import serial
import RPi.GPIO as GPIO

# GPIO의 모드를 BCM으로 설정한다(GPIO번호 사용)
GPIO.setmode(GPIO.BCM)

SW1_PIN = 4
SW2_PIN = 17
SW3_PIN = 18
SW4_PIN = 22

SW_PIN_LIST = [SW1_PIN, SW2_PIN, SW3_PIN, SW4_PIN]

#  시리얼 통신을 위한 클래스
class SerialClass():
    
    def __init__(self):
        RecvMessage = ''
        try:
            print("Start Switch Serial Receive Program...")

            # /dev/ttyS0 포트를 115200 bps의 속도로 연다
            self.RaspSerial = serial.Serial('/dev/ttyS0',115200)

            # GPIO 핀을 INPUT 으로 설정한다.
            GPIO.setup(SW_PIN_LIST, GPIO.IN)

            # 시리얼 메세지를 전송하는 스레드를 구동시킨다
            send = messageSendThread(self.RaspSerial)
            send.start()
            
            # 메세지를 받는 루프문 - 현재 사용하지 않음.
            while True :
                time.sleep(1)

        except Exception as err:
            print(err)

# 메세지를 보낸다.
class messageSendThread(threading.Thread):

    def __init__(self,RaspSerial):
        threading.Thread.__init__(self)
        self.RaspSerial = RaspSerial

    def run(self):

        buttonScore = [1,2,4,8]
        try :
            while True:
                # 버튼의 상태를 읽어온다
                button_state = []
                # 각 버튼의 누른 값을 저장할 변수
                # SW1(1) SW2(2) SW3(4) SW4(8)
                # 모든 버튼이 눌렸을때 15 1,2번이 눌렸을때는 3을 전송한다. 
                buttonValue = 0
                # 버튼의 수 만큼 순회하며 버튼의 상태를 읽고 계산한다.
                for i in range(0,len(SW_PIN_LIST)):
                    # 버튼이 눌렸을때는 1이 되도록 계산하고 정수화한다.
                    tempState = int(GPIO.input(SW_PIN_LIST[i])==0)
                    button_state.append(tempState)
                    # SW버튼의 숫자에 따라 가중치를 두어 눌린 버튼을 계산한다.
                    buttonValue = buttonValue + (tempState * buttonScore[i])
                message = "SW,{}\n".format(buttonValue)
                self.RaspSerial.write(bytes(message.encode()))
                time.sleep(0.3)
                

        except Exception as err:
            print(err)

# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    try:
        serialClass = SerialClass() # 창 객체를 인자로 클래스를 생성한다
    except KeyboardInterrupt:
        print("Program force quit")
        sys.exit()
