################################################################
# 시리얼 통신 데이터를 보내는 프로그램
#
# □ 라즈베리파이에서 시리얼을 동작 시키기
#  ○ 시리얼로 콘솔을 접속하는 서비스를 중지 시킨다  
#    - sudo systemctl stop serial-getty@ttyS0.service
#    - sudo systemctl disable serial-getty@ttyS0.service
#  ○ 시리얼 콘솔 접속 기능을 끈다 
#    - /boot/cmdline.txt 에서 console=serial0,115200 를 제거한다
#  ○ 관련 내용 참고ㅁ
#    - http://pinocc.tistory.com/185
#
# □ 필요 모듈 
#    - https://pythonhosted.org/pyserial/
#
################################################################
import sys
import threading
import time

import serial


#  시리얼 통신을 위한 클래스
class SerialClass():
    
    def __init__(self):
        RecvMessage = ''
        try:
            print("Start Serial Program...")

            # /dev/ttyS0 포트를 115200 bps의 속도로 연다
            self.RaspSerial = serial.Serial('/dev/ttyS0',115200)

            # 시리얼 메세지를 전송하는 스레드를 구동시킨다
            send = messageSendThread(self.RaspSerial)
            send.start()
            
            # 메세지를 받는 루프문
            while True :
                # 시리얼로부터 1byte를 읽어온다
                aByte = self.RaspSerial.read(1) 

                # 현재 읽어온 byte에 LF 문이 있으면 종결로 처리하고 반환한다
                if( aByte == b'\n'):
                    print("\n")
                    print("[Received] : " + RecvMessage) 
                    RecvMessage = ""
                # LF 가 나올때까지 문자열에 현재 byte를 추가한다
                else :
                    RecvMessage += str(aByte.decode())

        except Exception as err:
            print(err)

# 메세지를 보낸다.
class messageSendThread(threading.Thread):

    def __init__(self,RaspSerial):
        threading.Thread.__init__(self)
        self.RaspSerial = RaspSerial

    def run(self):
        try :
            while True:
                # 입력 받는 메세지
                message = input("[Send] : ")
                message += "\n"
                self.RaspSerial.write(bytes(message.encode()))
                time.sleep(0.3)
                

        except Exception as err:
            print(err)

# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    try:
        serialClass = SerialClass() # 창 객체를 인자로 클래스를 생성한다
    except KeyboardInterrupt:
        print("Program force quit")
        sys.exit()
