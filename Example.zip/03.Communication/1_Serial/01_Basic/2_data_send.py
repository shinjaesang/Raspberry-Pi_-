################################################################
# 시리얼 통신을 받는 프로그램
#
# □ 라즈베리파이에서 시리얼을 동작 시키기
#  ○ 시리얼로 콘솔을 접속하는 서비스를 중지 시킨다  
#    - sudo systemctl stop serial-getty@ttyS0.service
#    - sudo systemctl disable serial-getty@ttyS0.service
#  ○ 시리얼 콘솔 접속 기능을 끈다 
#    - /boot/cmdline.txt 에서 console=serial0,115200 를 제거한다
#  ○ 관련 내용 참고ㅁ
#    - http://pinocc.tistory.com/185
#
# □ 필요 모듈 
#    - https://pythonhosted.org/pyserial/
#
################################################################
import sys
import threading
import time

import serial


#  시리얼 통신을 위한 클래스
class SerialClass():
    
    def __init__(self):
        recvMessage = ''
        try:
            print("Start Serial Program...")

            # /dev/ttyS0 포트를 115200 bps의 속도로 연다
            self.RaspSerial = serial.Serial('/dev/ttyS0',115200)

            while True :
                # 입력 받는 메세지
                message = input("[Send] : ")
                self.RaspSerial.write(bytes(message.encode()))
                time.sleep(0.3)

        except Exception as err:
            print(err)

# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    try:
        serialClass = SerialClass() # 창 객체를 인자로 클래스를 생성한다
    except KeyboardInterrupt:
        print("Program force quit")
        sys.exit()
