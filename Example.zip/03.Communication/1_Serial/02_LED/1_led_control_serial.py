import sys
import threading
import time
import serial
import smbus

#######################
# LED를 제어하는 클래스
#######################
class LedControl:

    # LED 제어 비트
    RED_LED   = 0b00000001
    GREEN_LED = 0b00000010
    BLUE_LED  = 0b00000100

    state = None
    bus = None

    def __init__(self):
        pass

    ##########################
    #      LED 제어 함수
    ##########################
    # i2c를 사용하기 위해 smbus 모듈을 초기화한다.
    def ledInit(self):
        global state
        global bus
        state = 0b00000000
        bus = smbus.SMBus(1)

    def ledOn(self,cmd):
        global state
        # LED는 bit로 제어되기 때문에 논리 연산자를 사용한다. 
        # |는 OR를 의미한다.
        state = (state | cmd) 
        bus.write_byte(0x20, state)   
        
    def ledOff(self,cmd):
        global state
        # LED는 bit로 제어되기 때문에 논리 연산자를 사용한다. 
        # not cmd 를 만들고 state와 and하여 원하는 비트만 OFF시킨다.
        state = (state & (~cmd)) 
        bus.write_byte(0x20, state)

#  시리얼 통신을 위한 클래스
class SerialClass():
    
    def __init__(self):
        RecvMessage = ''
        try:
            print("Start Led Control Program...")
            print("Send command 'LED,ON\\n' or 'LED,OFF\\n'")

            # /dev/ttyS0 포트를 115200 bps의 속도로 연다
            self.RaspSerial = serial.Serial('/dev/ttyS0',115200)

            ControlLed = LedControl()
            ControlLed.ledInit()

            # 메세지를 받는 루프문
            while True :
                # 시리얼로부터 1byte를 읽어온다
                aByte = self.RaspSerial.read(1) 

                # 현재 읽어온 byte에 LF 문이 있으면 분석을 시작한다.
                if( aByte == b'\n'):
                    # 현재 수신 데이터를 쉼표를 기준으로 구분한다.
                    msg = RecvMessage.split(',')
                    # LED,ON 형태로 수신시 길이를 체크한다.
                    if len(msg) == 2:
                        # 수신 된 제어 메세지가 LED일시 ON/OFF로 구분하여 각각 제어한다.
                        if msg[0] == "LED":
                            print("{},{}".format(msg[0],msg[1]))
                            # ON일시 빨간 LED 켜기
                            if msg[1] == "ON":
                                ControlLed.ledOn(ControlLed.RED_LED)
                                self.RaspSerial.write(bytes("OK\n".encode()))
                            # OFF일시 빨간 LED 끄기
                            elif msg[1] == "OFF":
                                ControlLed.ledOff(ControlLed.RED_LED)
                                self.RaspSerial.write(bytes("OK\n".encode()))

                    RecvMessage = ""
                # LF 가 나올때까지 문자열에 현재 byte를 추가한다
                else :
                    RecvMessage += str(aByte.decode())

        except Exception as err:
            print(err)

# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    try:
        serialClass = SerialClass() # 창 객체를 인자로 클래스를 생성한다
    except KeyboardInterrupt:
        print("Program force quit")
        sys.exit()
