import sys
import threading
import time
import serial
import smbus
import RPi.GPIO as GPIO

# GPIO의 모드를 BCM으로 설정한다(GPIO번호 사용)
GPIO.setmode(GPIO.BCM)

SW1_PIN = 4
SW2_PIN = 17
SW3_PIN = 18
SW4_PIN = 22

SW_PIN_LIST = [SW1_PIN, SW2_PIN, SW3_PIN, SW4_PIN]

# LED 상태
ledstateArray = [0,0,0]

#######################
# LED를 제어하는 클래스
#######################
class LedControl:

    # LED 제어 비트
    RED_LED   = 0b00000001
    GREEN_LED = 0b00000010
    BLUE_LED  = 0b00000100

    state = None
    bus = None

    def __init__(self):
        pass

    ##########################
    #      LED 제어 함수
    ##########################
    # i2c를 사용하기 위해 smbus 모듈을 초기화한다.
    def ledInit(self):
        global state
        global bus
        state = 0b00000000
        bus = smbus.SMBus(1)

    def ledOn(self,cmd):
        global state
        # LED는 bit로 제어되기 때문에 논리 연산자를 사용한다. 
        # |는 OR를 의미한다.
        state = (state | cmd) 
        bus.write_byte(0x20, state)   
        
    def ledOff(self,cmd):
        global state
        # LED는 bit로 제어되기 때문에 논리 연산자를 사용한다. 
        # not cmd 를 만들고 state와 and하여 원하는 비트만 OFF시킨다.
        state = (state & (~cmd)) 
        bus.write_byte(0x20, state)

#  시리얼 통신을 위한 클래스
class SerialClass():
    
    def __init__(self):
        global ledstateArray
        RecvMessage = ''
        try:
            print("Start Led Control Program...")
            print("Send command 'LED,ON\\n' or 'LED,OFF\\n'")

            # /dev/ttyS0 포트를 115200 bps의 속도로 연다
            self.RaspSerial = serial.Serial('/dev/ttyS0',115200)

            # GPIO 핀을 INPUT 으로 설정한다.
            GPIO.setup(SW_PIN_LIST, GPIO.IN)

            self.ControlLed = LedControl()
            self.ControlLed.ledInit()

            # 시리얼 메세지를 전송하는 스레드를 구동시킨다
            send = messageSendThread(self.RaspSerial,self.ControlLed)
            send.start()
            
            self.ControlLed.ledOff(self.ControlLed.RED_LED)
            self.ControlLed.ledOff(self.ControlLed.GREEN_LED)
            self.ControlLed.ledOff(self.ControlLed.BLUE_LED)

            # 메세지를 받는 루프문
            while True :
                # 시리얼로부터 1byte를 읽어온다
                aByte = self.RaspSerial.read(1) 

                # 현재 읽어온 byte에 LF 문이 있으면 분석을 시작한다.
                if( aByte == b'\n'):
                    # 현재 수신 데이터를 쉼표를 기준으로 구분한다.
                    msg = RecvMessage.split(',')
                    # LED,ON,R 형태로 수신시 길이를 체크한다.
                    if len(msg) == 3:
                        # 수신 된 제어 메세지가 LED일시 ON/OFF로 구분하여 각각 제어한다.
                        if msg[0] == "LED":
                            print("{},{}".format(msg[0],msg[1]))
    
                            if msg[1] == "ON":
                                # 빨간색 ON 일때
                                if msg[2] == "R":
                                    self.ControlLed.ledOn(self.ControlLed.RED_LED)
                                    ledstateArray[0] = 1
                                
                                # 초록색 ON 일때
                                elif msg[2] == "G":
                                    self.ControlLed.ledOn(self.ControlLed.GREEN_LED)
                                    ledstateArray[1] = 1
                                    
                                # 파란색 ON 일때
                                elif msg[2] == "B":
                                    self.ControlLed.ledOn(self.ControlLed.BLUE_LED)
                                    ledstateArray[2] = 1
                            
                            elif msg[1] == "OFF":
                                # 빨간색 OFF 일때
                                if msg[2] == "R":
                                    self.ControlLed.ledOff(self.ControlLed.RED_LED)
                                    ledstateArray[0] = 0
                                    
                                # 초록색 OFF 일때
                                elif msg[2] == "G":
                                    self.ControlLed.ledOff(self.ControlLed.GREEN_LED)
                                    ledstateArray[1] = 0
                                    
                                # 파란색 OFF 일때
                                elif msg[2] == "B":
                                    self.ControlLed.ledOff(self.ControlLed.BLUE_LED)
                                    ledstateArray[2] = 0

                            self.RaspSerial.write(bytes("LED,OK\n".encode()))
                    RecvMessage = ""
                # LF 가 나올때까지 문자열에 현재 byte를 추가한다
                else :
                    RecvMessage += str(aByte.decode())

        except Exception as err:
            print(err)


# 메세지를 보낸다.
class messageSendThread(threading.Thread):

    def __init__(self,RaspSerial,ControlLed):
        threading.Thread.__init__(self)
        self.RaspSerial = RaspSerial
        self.ControlLed = ControlLed

    def run(self):
        global ledstateArray
        buttonScore = [1,2,4,8]
        ledStateScore = [1,2,4]
        try :
            while True:
                # 버튼의 상태를 읽어온다
                button_state = []
                # 각 버튼의 누른 값을 저장할 변수
                # SW1(1) SW2(2) SW3(4) SW4(8)
                # 모든 버튼이 눌렸을때 15 1,2번이 눌렸을때는 3을 전송한다. 
                buttonValue = 0
                # 버튼의 수 만큼 순회하며 버튼의 상태를 읽고 계산한다.
                for i in range(0,len(SW_PIN_LIST)):
                    # 버튼이 눌렸을때는 1이 되도록 계산하고 정수화한다.
                    tempState = int(GPIO.input(SW_PIN_LIST[i])==0)
                    button_state.append(tempState)
                    # SW버튼의 숫자에 따라 가중치를 두어 눌린 버튼을 계산한다.
                    buttonValue = buttonValue + (tempState * buttonScore[i])

                # SW-1이 눌렸을때 - RED ON 상태 어레이를 1
                if buttonValue == 1:
                    self.ControlLed.ledOn(self.ControlLed.RED_LED)
                    ledstateArray[0] = 1

                # SW-2이 눌렸을때 - GREEN ON 상태 어레이를 1
                elif buttonValue == 2:
                    self.ControlLed.ledOn(self.ControlLed.GREEN_LED)
                    ledstateArray[1] = 1

                # SW-3이 눌렸을때 - BLUE ON 상태 어레이를 1
                elif buttonValue == 4:
                    self.ControlLed.ledOn(self.ControlLed.BLUE_LED)
                    ledstateArray[2] = 1

                # SW-4이 눌렸을때 - 모든 LED를 끄고 상태 어레이를 모두 0으로 초기화.
                elif buttonValue == 8:
                    self.ControlLed.ledOff(self.ControlLed.RED_LED)
                    self.ControlLed.ledOff(self.ControlLed.GREEN_LED)
                    self.ControlLed.ledOff(self.ControlLed.BLUE_LED)
                    for i in range(0,len(ledstateArray)):
                        ledstateArray[i] = 0
    
                # LED 상태 값. RED:1 GREEN:2 BLUE:4 로 계산하여 켜져있는 LED를 모니터링한다.
                ledStaeValue = 0
                for i in range(0,len(ledstateArray)):
                    tempState = int(ledstateArray[i]) == 1
                    # SW버튼의 숫자에 따라 가중치를 두어 눌린 버튼을 계산한다.
                    ledStaeValue = ledStaeValue + (tempState * ledStateScore[i])

                message = "LED,{}\n".format(ledStaeValue)

                self.RaspSerial.write(bytes(message.encode()))
                time.sleep(0.1)
                

        except Exception as err:
            print(err)

# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    try:
        serialClass = SerialClass() # 창 객체를 인자로 클래스를 생성한다
    except KeyboardInterrupt:
        print("Program force quit")
        sys.exit()
