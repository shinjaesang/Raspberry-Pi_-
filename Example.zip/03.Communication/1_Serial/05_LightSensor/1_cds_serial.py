import sys
import threading
import time
import serial
# I2C 사용을 위한 모듈 smbus
import smbus
# 지연시간 제어를 위해 time 모듈을 사용한다.
import time

bus = smbus.SMBus(1)
i2c_address = 0x48

# PCF8591 칩에서 데이터를 받기위한 명령어다.
command = 0x44

#  시리얼 통신을 위한 클래스
class SerialClass():
    
    def __init__(self):
        RecvMessage = ''
        try:
            print("Start CdS Value Serial Receive Program...")

            # /dev/ttyS0 포트를 115200 bps의 속도로 연다
            self.RaspSerial = serial.Serial('/dev/ttyS0',115200)

            # 시리얼 메세지를 전송하는 스레드를 구동시킨다
            send = messageSendThread(self.RaspSerial)
            send.start()
            
            # 메세지를 받는 루프문 - 현재 사용하지 않음.
            while True :
                time.sleep(1)

        except Exception as err:
            print(err)

# 메세지를 보낸다.
class messageSendThread(threading.Thread):

    def __init__(self,RaspSerial):
        threading.Thread.__init__(self)
        self.RaspSerial = RaspSerial

    def run(self):
        try :
            while True:
                # i2c의 주소와 명령어를 전송하여 5Byte의 데이터를 읽어온다.
                # 맨 앞의 dummy data(index 0번 데이터)를 제외하고 뒤 4Byte가 4개의 ADC 포트 데이터이다.
                adc_data = bus.read_i2c_block_data(i2c_address, command, 5)
                
                # I2C로 부터 센서 값을 읽어온다 CdS 센서는 1번이다.
                CdsValue = adc_data[2]
                CdsValue = CdsValue * 100 / 255

                # 소수점 둘 째 자리까지만 표시한다
                CdsValue = round(CdsValue,2)

                message = "CdS,{}\n".format(CdsValue)
                self.RaspSerial.write(bytes(message.encode()))
                time.sleep(0.3)
                

        except Exception as err:
            print(err)

# 프로그램의 메인에 해당하는 최상위 구문
if (__name__ == '__main__'):
    try:
        serialClass = SerialClass() # 창 객체를 인자로 클래스를 생성한다
    except KeyboardInterrupt:
        print("Program force quit")
        sys.exit()
